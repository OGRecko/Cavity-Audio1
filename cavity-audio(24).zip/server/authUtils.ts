import crypto from "crypto";

// Everything here uses only Node's built-in `crypto` module — no external auth
// service, no paid plan, nothing to sign up for.

const SESSION_SECRET = process.env.SESSION_SECRET || "dev-insecure-secret-change-me";

if (process.env.NODE_ENV === "production" && SESSION_SECRET === "dev-insecure-secret-change-me") {
  console.error("FATAL: SESSION_SECRET is not set in production. Failing closed.");
  process.exit(1);
}
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

if (SESSION_SECRET === "dev-insecure-secret-change-me") {
  if (process.env.NODE_ENV === "production") {
    console.error("[error] SESSION_SECRET is not set! Production deployment requires a secure session secret.");
    process.exit(1);
  } else {
    console.warn("[warn] SESSION_SECRET is not set — using an insecure default. Set SESSION_SECRET in your .env before deploying.");
  }
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const hashBuffer = Buffer.from(hash, "hex");
  const suppliedBuffer = crypto.scryptSync(password, salt, 64);
  return hashBuffer.length === suppliedBuffer.length && crypto.timingSafeEqual(hashBuffer, suppliedBuffer);
}

export function generateCode(): string {
  // 6-digit numeric code, e.g. "042917"
  return crypto.randomInt(0, 1_000_000).toString().padStart(6, "0");
}

export function hashCode(code: string): string {
  return crypto.createHash("sha256").update(code).digest("hex");
}

export function createSessionToken(uid: string): string {
  const expiresAt = Date.now() + SESSION_TTL_MS;
  const payload = `${uid}.${expiresAt}`;
  const sig = crypto.createHmac("sha256", SESSION_SECRET).update(payload).digest("hex");
  return `${payload}.${sig}`;
}

export function verifySessionToken(token: string | undefined): string | null {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [uid, expiresAtStr, sig] = parts;
  const payload = `${uid}.${expiresAtStr}`;
  const expectedSig = crypto.createHmac("sha256", SESSION_SECRET).update(payload).digest("hex");
  const sigBuffer = Buffer.from(sig);
  const expectedBuffer = Buffer.from(expectedSig);
  if (sigBuffer.length !== expectedBuffer.length || !crypto.timingSafeEqual(sigBuffer, expectedBuffer)) return null;
  if (Number(expiresAtStr) < Date.now()) return null;
  return uid;
}

export const SESSION_COOKIE_NAME = "cavity_session";
export const SESSION_COOKIE_MAX_AGE = SESSION_TTL_MS;
