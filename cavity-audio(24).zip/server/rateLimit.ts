// ---------------------------------------------------------------------------
// Lightweight in-memory rate limiting for authentication endpoints.
//
// This intentionally avoids adding a new npm dependency (express-rate-limit)
// since it can't be installed/verified in every environment this project is
// built in. It implements a simple fixed-window counter per key.
//
// LIMITATION (documented, see item 19 in the project brief): counters are
// per-process. In a multi-instance deployment each instance enforces its own
// limits independently, so the effective global limit is
// (limit x instance count). For a single-instance deployment (the current
// recommended architecture) this is a real, functioning protection. If/when
// this app is scaled horizontally, replace the Map below with a shared store
// (e.g. Redis) — see server/README notes on multi-instance limitations.
// ---------------------------------------------------------------------------

interface Bucket {
  count: number;
  resetAt: number;
}

const buckets = new Map<string, Bucket>();

// Periodic cleanup so the Map doesn't grow unboundedly over a long-running
// process. Not security-critical, just hygiene.
setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt <= now) buckets.delete(key);
  }
}, 5 * 60 * 1000).unref?.();

/**
 * Checks and increments a rate-limit counter for `key`.
 * Returns { allowed, retryAfterSeconds }.
 */
function hit(key: string, windowMs: number, max: number): { allowed: boolean; retryAfterSeconds: number } {
  const now = Date.now();
  const existing = buckets.get(key);

  if (!existing || existing.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, retryAfterSeconds: 0 };
  }

  existing.count += 1;
  if (existing.count > max) {
    return { allowed: false, retryAfterSeconds: Math.ceil((existing.resetAt - now) / 1000) };
  }
  return { allowed: true, retryAfterSeconds: 0 };
}

function clientIp(req: any): string {
  // Trust X-Forwarded-For only if the app is explicitly configured to sit
  // behind a proxy; otherwise req.ip / req.socket already reflects the real
  // peer. Falling back to a constant avoids ever throwing here.
  return req.ip || req.socket?.remoteAddress || "unknown";
}

export interface AuthRateLimitOptions {
  /** Requests allowed per IP within the window. */
  ipMax: number;
  /** Requests allowed per account-identifying key (e.g. email) within the window. */
  keyMax?: number;
  windowMs: number;
  /** Extracts the account-identifying value (email/username) from the request body, if any. */
  getKey?: (req: any) => string | undefined;
  /** Route name used as a namespace so different endpoints don't share buckets. */
  routeName: string;
}

/**
 * Express middleware combining IP-based throttling with optional
 * account/email-based throttling, per item 23 of the security brief.
 * Responds 429 with a generic message (never reveals which limit tripped,
 * or whether the account/email exists).
 */
export function authRateLimit(options: AuthRateLimitOptions) {
  const { ipMax, keyMax, windowMs, getKey, routeName } = options;

  return function rateLimitMiddleware(req: any, res: any, next: any) {
    const ip = clientIp(req);
    const ipResult = hit(`${routeName}:ip:${ip}`, windowMs, ipMax);

    if (!ipResult.allowed) {
      res.set("Retry-After", String(ipResult.retryAfterSeconds));
      return res.status(429).json({ error: "Too many requests. Please try again later." });
    }

    if (keyMax && getKey) {
      const rawKey = getKey(req);
      if (rawKey) {
        const normalizedKey = String(rawKey).trim().toLowerCase();
        const keyResult = hit(`${routeName}:key:${normalizedKey}`, windowMs, keyMax);
        if (!keyResult.allowed) {
          res.set("Retry-After", String(keyResult.retryAfterSeconds));
          return res.status(429).json({ error: "Too many requests. Please try again later." });
        }
      }
    }

    next();
  };
}
