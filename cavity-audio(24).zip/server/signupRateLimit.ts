import { signupAbuseCollection } from "./db";

export interface IpState {
  attempts: number; // number of violations/cooldowns applied
  allowedCount: number; // normal signups before cooldown kicks in
  cooldownUntil: number; // timestamp
}

const PENALTIES = [
  1 * 60 * 1000,       // 1 minute
  5 * 60 * 1000,       // 5 minutes
  10 * 60 * 1000,      // 10 minutes
  60 * 60 * 1000,      // 1 hour
  12 * 60 * 60 * 1000, // 12 hours
  24 * 60 * 60 * 1000, // 24 hours
  48 * 60 * 60 * 1000, // 48 hours
  72 * 60 * 60 * 1000, // 72 hours
  -1                   // Permanent
];

function normalizeIp(ip: string): string {
  if (!ip) return "unknown";
  if (ip.startsWith("::ffff:")) return ip.substring(7);
  return ip;
}

export async function checkAndRecordSignup(rawIp: string): Promise<{ allowed: boolean; waitMs?: number; permanent?: boolean }> {
  const ip = normalizeIp(rawIp);
  const ref = signupAbuseCollection.doc(ip);
  
  return await signupAbuseCollection.firestore.runTransaction(async (t) => {
    const doc = await t.get(ref);
    let ipState: IpState = { attempts: 0, allowedCount: 0, cooldownUntil: 0 };
    
    if (doc.exists) {
      ipState = doc.data() as IpState;
    }
    
    const now = Date.now();
    
    if (ipState.cooldownUntil > now || ipState.cooldownUntil === -1) {
      if (ipState.cooldownUntil === -1) {
        return { allowed: false, permanent: true };
      }
      return { allowed: false, waitMs: ipState.cooldownUntil - now };
    }
    
    if (ipState.allowedCount < 5) {
      ipState.allowedCount++;
      t.set(ref, ipState);
      return { allowed: true };
    }
    
    const penaltyIndex = Math.min(ipState.attempts, PENALTIES.length - 1);
    const penaltyMs = PENALTIES[penaltyIndex];
    
    ipState.cooldownUntil = penaltyMs === -1 ? -1 : now + penaltyMs;
    ipState.attempts++;
    t.set(ref, ipState);
    
    if (penaltyMs === -1) {
      return { allowed: false, permanent: true };
    }
    return { allowed: false, waitMs: penaltyMs };
  });
}
