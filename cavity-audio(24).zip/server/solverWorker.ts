import { parentPort, workerData } from 'worker_threads';

function clamp01(v: number) { return Math.max(0, Math.min(1, v)); }
function parseFiniteInRange(val: any, min: number, max: number, nameOrDef: any): number {
  const num = Number(val);
  if (Number.isFinite(num) && num >= min && num <= max) return num;
  if (typeof nameOrDef === "string") throw new Error(nameOrDef + " is invalid");
  return nameOrDef;
}

import { getAbsorption } from "../src/lib/absorption";
function getAbsorptionAt500Hz(materialId: string): number {
  return getAbsorption(materialId).hz500;
}

try {
  const { type, payload } = workerData;
  if (type === 'wave') {
    const result = runWave(payload);
    parentPort?.postMessage({ success: true, data: result });
  } else if (type === 'impulse-response') {
    const result = runIR(payload);
    parentPort?.postMessage({ success: true, data: result });
  } else {
    throw new Error("Unknown solver type");
  }
} catch (err: any) {
  parentPort?.postMessage({ success: false, error: err.message || String(err) });
}

function runWave(payload: any) {
  const { elements, steps, L, W, H, wallMaterial, floorMaterial, ceilMaterial, source, receiver } = payload;

  // Server-side tier enforcement is authoritative. Free accounts are capped at
  // 1M elements; premium/lifetime accounts at 50M. These are hard server caps,
  // independent of any client-side budget hint.
  const isPro = payload.userPlan === 'premium' || payload.userPlan === 'lifetime';
  const hardCap = isPro ? 50000000 : 1000000;
  
  const roomL = Number(L);
  const roomW = Number(W);
  const roomH = Number(H);
  if (![roomL, roomW, roomH].every(Number.isFinite) || roomL <= 0 || roomW <= 0 || roomH <= 0 || roomL > 100 || roomW > 100 || roomH > 30) {
    throw new Error("Room dimensions must be finite positive values within safe limits (L/W <= 100 m, H <= 30 m).");
  }

  const accuracyMode = String(payload.accuracyMode || 'balanced');
  const ppwMap: Record<string, number> = { fast: 5, balanced: 9, high: 13 };
  if (!(accuracyMode in ppwMap)) {
    throw new Error("accuracyMode must be fast, balanced, or high.");
  }
  const pointsPerWavelength = ppwMap[accuracyMode];

  const targetFmax = payload.fmax == null ? 500 : Number(payload.fmax);
  if (!Number.isFinite(targetFmax) || targetFmax <= 0 || targetFmax > 24000) {
    throw new Error("fmax must be a finite frequency between 1 Hz and 24 kHz.");
  }

  const rawSteps = payload.steps == null ? 40 : Number(payload.steps);
  if (!Number.isFinite(rawSteps) || !Number.isInteger(rawSteps) || rawSteps < 1 || rawSteps > 200) {
    throw new Error("steps must be an integer between 1 and 200.");
  }
  const numStepsRequested = rawSteps;
  const speedOfSound = 343;
  
  const requiredDx = speedOfSound / (pointsPerWavelength * targetFmax);
  const requiredNx = Math.max(4, Math.ceil(roomL / requiredDx));
  const requiredNy = Math.max(4, Math.ceil(roomH / requiredDx));
  const requiredNz = Math.max(4, Math.ceil(roomW / requiredDx));
  const requiredElements = requiredNx * requiredNy * requiredNz;

  if (requiredElements > hardCap && !payload.confirmReducedResolution) {
      const supportedElements = hardCap;
      const actualFmax = speedOfSound / (pointsPerWavelength * Math.cbrt((roomL * roomW * roomH) / supportedElements));
      
      throw new Error(JSON.stringify({
          requiresConfirmation: true,
          message: `Requested ${targetFmax} Hz simulation at ${accuracyMode.toUpperCase()} accuracy requires ${requiredElements.toLocaleString()} elements, which exceeds your tier's safe limit of ${hardCap.toLocaleString()}.

Current configuration safely supports up to ~${Math.round(actualFmax)} Hz.

Continue with reduced resolution?`,
          requestedFmax: targetFmax,
          supportedFmax: actualFmax,
          requestedResolution: requiredDx,
          supportedResolution: Math.cbrt((roomL * roomW * roomH) / supportedElements),
          estimatedMemoryMb: Math.round(supportedElements * 4 * 3 / 1024 / 1024),
      }));
  }
  
  let dx = requiredDx;
  if (requiredElements > hardCap) {
    const rawCellVolume = (roomL * roomH * roomW) / hardCap;
    dx = Math.cbrt(rawCellVolume);
  }
  dx = Math.max(dx, 0.02); // absolute 2 cm cell floor

  let nx = Math.max(4, Math.round(roomL / dx));
  let ny = Math.max(4, Math.round(roomH / dx));
  let nz = Math.max(4, Math.round(roomW / dx));
  let N = nx * ny * nz;

  // Rounding can push the actual grid slightly above the element budget.
  // Increase the cell size until the FINAL allocated grid is within the cap.
  if (N > hardCap) {
    dx = Math.max(dx, Math.cbrt((roomL * roomW * roomH) / hardCap));
    nx = Math.max(4, Math.floor(roomL / dx));
    ny = Math.max(4, Math.floor(roomH / dx));
    nz = Math.max(4, Math.floor(roomW / dx));
    N = nx * ny * nz;
  }
  if (N > hardCap) {
    throw new Error(JSON.stringify({ error: "The final FDTD grid exceeds the server safety limit." }));
  }

  // Report capability from the ACTUAL final grid spacing, not a theoretical
  // element-volume estimate that can differ after rounding/clamping.
  const actualFmax = speedOfSound / (pointsPerWavelength * dx);
  const numSteps = numStepsRequested;
  const reducedResolution = actualFmax + 1e-9 < targetFmax;
  const nxy = nx * ny;

  // Per-surface absorption -> per-axis boundary damping. Higher absorption
  // = more energy lost when the wave reflects off that surface, instead of
  // one flat damping constant applied everywhere.
  //
  // Single-value-per-material here is a simplification: real absorption is
  // frequency-dependent (see src/lib/absorption.ts for the full per-octave-
  // band table, which is the shared source of truth this map is derived
  // from). Time-domain FDTD boundary damping needs one broadband coefficient
  // per step, so this uses each material's 500 Hz value — the standard
  // reference frequency for a material's general absorptive character —
  // rather than maintaining a second, independently-tuned set of numbers.
  // If you're changing absorption values, change them in absorption.ts and
  // regenerate this block; don't hand-edit these numbers separately.
  const wallAbs = getAbsorptionAt500Hz(wallMaterial);
  const floorAbs = getAbsorptionAt500Hz(floorMaterial);
  const ceilAbs = getAbsorptionAt500Hz(ceilMaterial);
  // Reflection coefficient per boundary: sqrt(1 - absorption) is the usual
  // pressure-reflection approximation from the energy absorption coefficient.
  const wallRefl = Math.sqrt(Math.max(1 - wallAbs, 0));
  const floorRefl = Math.sqrt(Math.max(1 - floorAbs, 0));
  const ceilRefl = Math.sqrt(Math.max(1 - ceilAbs, 0));

  // Convert the normalized (0..1) source/listener coordinates the 3D view
  // uses into real grid indices, instead of always firing the impulse from
  // dead-center of the volume.
  const clamp01 = (v: number) => Math.min(0.98, Math.max(0.02, v));
  const srcX = clamp01(source?.x ?? 0.5), srcZ = clamp01(source?.y ?? 0.5);
  const srcIx = Math.round(srcX * (nx - 1));
  const srcIy = Math.round((source?.z != null ? clamp01(source.z / roomH) : 0.7) * (ny - 1));
  const srcIz = Math.round(srcZ * (nz - 1));
  const srcIdx = srcIy * nxy + srcIz * nx + srcIx;

  const recX = clamp01(receiver?.x ?? 0.25), recZ = clamp01(receiver?.y ?? 0.5);
  const recIx = Math.round(recX * (nx - 1));
  const recIy = Math.round((receiver?.z != null ? clamp01(receiver.z / roomH) : 0.5) * (ny - 1));
  const recIz = Math.round(recZ * (nz - 1));
  const recIdx = recIy * nxy + recIz * nx + recIx;

  // STAGE 14: Stability & Numerical Validation (Geometry & Positions)
  // Moved inside the try block below (this used to throw() before the try
  // started, which meant these validation errors were unhandled — Express
  // would surface a raw unhandled-exception 500 with no JSON body / stack
  // trace exposure instead of the clean `{ error: ... }` response the catch
  // block below is meant to produce for every other failure in this route).
  try {
    if (isNaN(N) || !isFinite(N) || N <= 0) throw new Error("Invalid geometry calculations resulted in NaN/Infinity elements.");
    if (srcIx < 0 || srcIx >= nx || srcIy < 0 || srcIy >= ny || srcIz < 0 || srcIz >= nz) {
      throw new Error("Invalid source position: placed outside the computational boundary.");
    }
    if (recIx < 0 || recIx >= nx || recIy < 0 || recIy >= ny || recIz < 0 || recIz >= nz) {
      throw new Error("Invalid receiver position: placed outside the computational boundary.");
    }

    console.log(`[WAVE SOLVER] Room ${roomL}x${roomW}x${roomH}m -> FDTD grid ${nx}x${ny}x${nz} (${N.toLocaleString()} elements, dx=${dx.toFixed(3)}m). Steps: ${numSteps}. Tier: ${isPro ? 'pro' : 'free'}.`);


    const estimatedMemoryBytes = N * 12 + (numSteps * 8) + 50000000;
    const maxMemoryBytes = process.env.MAX_SOLVER_MEMORY_BYTES ? Number(process.env.MAX_SOLVER_MEMORY_BYTES) : 1500000000;
    if (estimatedMemoryBytes > maxMemoryBytes) {
      throw new Error("Simulation exceeds available system memory budget. Reduce resolution or duration.");
    }
    const startTime = Date.now();

    const p_prev = new Float32Array(N);
    const p = new Float32Array(N);
    const p_next = new Float32Array(N);

    // Initial condition: impulse at the room's actual source position.
    p[Math.max(0, Math.min(N - 1, srcIdx))] = 1.0;

    const Courant = 0.1; // Stability coefficient for this scheme (Courant^2 = (c*dt/dx)^2, well inside the 3D CFL limit of 1/3)
    // dt must be derived FROM Courant, not independently set to dx/c: the
    // update equation below implements p_next = 2p - p_prev + Courant*laplacian,
    // which is only the correct discretization of the wave equation
    // (d^2p/dt^2 = c^2 * laplacian(p)) if Courant == (c*dt/dx)^2. Reporting
    // dt = dx/c (implying Courant=1.0, three times past the actual stability
    // limit) while the loop below actually runs at Courant=0.1 previously
    // made every downstream "seconds" value (RT60-from-decay, trace
    // duration) wrong by a factor of 1/sqrt(0.1) =~ 3.16x -- fixed by
    // deriving dt from the Courant number the physics loop actually uses.
    const dt = (dx * Math.sqrt(Courant)) / 343;
    const receiverTrace: number[] = [];

    for (let t = 0; t < numSteps; t++) {
      for (let iy = 1; iy < ny - 1; iy++) {
        for (let iz = 1; iz < nz - 1; iz++) {
          const rowBase = iy * nxy + iz * nx;
          for (let ix = 1; ix < nx - 1; ix++) {
            const i = rowBase + ix;
            p_next[i] = (2 * p[i]) - p_prev[i] + Courant * (
              p[i - 1] + p[i + 1] +
              p[i - nx] + p[i + nx] +
              p[i - nxy] + p[i + nxy] -
              (6 * p[i])
            );
          }
        }
      }
      
      // Boundary reflection: Apply locally reacting boundary conditions.
      // The interior loop above only computes pressure for cells 1 to N-2.
      // The boundary cells (0 and N-1) were skipped and remain 0.
      // Merely multiplying them by a reflection coefficient (0 * R = 0) does not reflect waves; it behaves like an open boundary.
      // Instead, we implement a simple first-order pressure boundary condition:
      // The pressure at the boundary is the pressure at the adjacent interior cell, multiplied by the reflection coefficient.
      // This explicitly models the wall as a partially reflective surface reflecting the adjacent interior field.
      
      for (let iz = 1; iz < nz - 1; iz++) {
        for (let ix = 1; ix < nx - 1; ix++) {
          p_next[0 * nxy + iz * nx + ix] = p_next[1 * nxy + iz * nx + ix] * floorRefl;
          p_next[(ny - 1) * nxy + iz * nx + ix] = p_next[(ny - 2) * nxy + iz * nx + ix] * ceilRefl;
        }
      }
      
      for (let iy = 1; iy < ny - 1; iy++) {
        for (let ix = 1; ix < nx - 1; ix++) {
          p_next[iy * nxy + 0 * nx + ix] = p_next[iy * nxy + 1 * nx + ix] * wallRefl;
          p_next[iy * nxy + (nz - 1) * nx + ix] = p_next[iy * nxy + (nz - 2) * nx + ix] * wallRefl;
        }
        for (let iz = 1; iz < nz - 1; iz++) {
          p_next[iy * nxy + iz * nx + 0] = p_next[iy * nxy + iz * nx + 1] * wallRefl;
          p_next[iy * nxy + iz * nx + (nx - 1)] = p_next[iy * nxy + iz * nx + (nx - 2)] * wallRefl;
        }
      }
      // Edges and corners are left at 0 for simplicity, which is standard for a simple Cartesian 7-point stencil.

      receiverTrace.push(Math.abs(p_next[Math.max(0, Math.min(N - 1, recIdx))]));

      p_prev.set(p);
      p.set(p_next);
    }

    // Estimate RT60 from the actual simulated decay at the receiver (time for
    // the envelope to fall 60dB, extrapolated from however much decay the
    // step budget captured) as a sanity cross-check against the Sabine
    // estimate used elsewhere in the app.
    //
    // IMPORTANT: search for the -30dB point starting from the peak index,
    // not from index 0. Searching from the start is wrong — the receiver is
    // silent before the direct sound even arrives (especially when source
    // and receiver aren't co-located), and that pre-arrival silence is
    // already below the -30dB threshold, so a naive findIndex from 0 would
    // immediately "detect decay" during a period where sound hasn't arrived
    // yet, producing a bogus near-zero RT60 instead of a real one.
    let peak = 0;
    let peakIdx = 0;
    for (let i = 0; i < receiverTrace.length; i++) {
      if (receiverTrace[i] > peak) {
        peak = receiverTrace[i];
        peakIdx = i;
      }
    }
    peak = peak || 1e-9;
    
    let decayIdxRelative = -1;
    const threshold = peak * Math.pow(10, -30 / 20);
    for (let i = peakIdx; i < receiverTrace.length; i++) {
      if (receiverTrace[i] < threshold) {
        decayIdxRelative = i - peakIdx;
        break;
      }
    }
    let simulatedRt60: number | null = null;
    if (decayIdxRelative > 0) {
      simulatedRt60 = (decayIdxRelative * dt) * 2; // extrapolate -30dB point to -60dB
    }
    // This quick-preview run is far too short (numSteps <= 40, ~1-1.5ms of
    // simulated time) to ever actually reach a real -30dB decay in a
    // typical room (RT60 is usually 300-2000ms) — decayIdxRelative will
    // almost always be -1 here (no decay observed), which is the CORRECT,
    // honest outcome given the step budget. Do not be surprised that
    // simulatedRt60 is usually null; that's not a bug, it's the actual
    // limitation being surfaced instead of hidden. Use
    // /api/solver/impulse-response (below) for a run that's actually long
    // enough to produce a meaningful decay-based RT60/C50/C80/Ts.

    const volume = roomL * roomW * roomH;
    const wallArea = 2 * (roomL * roomH) + 2 * (roomW * roomH);
    const floorArea = roomL * roomW;
    const ceilArea = roomL * roomW;
    const totalSabins = (wallArea * wallAbs) + (floorArea * floorAbs) + (ceilArea * ceilAbs);
    const sabineRt60 = (0.161 * volume) / Math.max(totalSabins, 0.01);

    const endTime = Date.now();
    const durationMs = endTime - startTime;

    
    const resultObj = {
      rt60: sabineRt60,
      simulatedRt60,
      gridDims: [nx, ny, nz],
      steps: numSteps,
    };
    
    // Fire and forget save
    

    return {
      success: true,
      
      meshSize: N,
      gridDims: [nx, ny, nz],
      actualFmax: actualFmax,
      targetFmax: targetFmax,
      reducedResolution,
      requestedElements: requiredElements,
      cellSizeM: dx,
      steps: numSteps,
      durationMs,
      rt60: sabineRt60,
      simulatedRt60,
      tier: isPro ? 'pro' : 'free',
      // Real per-step receiver pressure trace, exposed so the client can
      // derive genuine C50/C80/D50/Ts/STI instead of placeholder numbers.
      // dtEstimate lets the client convert sample index -> seconds.
      receiverTrace,
      dtEstimate: dt,
      message: `Computed ${numSteps} time steps over a ${nx}x${ny}x${nz} grid (${N.toLocaleString()} elements) matching your ${roomL}x${roomW}x${roomH}m room in ${durationMs}ms.`
    };

  } catch (err: any) {
    console.error("Wave Solver Error:", err);
    throw new Error(err.message || "Engine memory limit exceeded.");
  }
}

function runIR(payload: any) {
  const { L, W, H, wallMaterial, floorMaterial, ceilMaterial, source, receiver } = payload;

  const roomL = Number(L);
  const roomW = Number(W);
  const roomH = Number(H);
  if (![roomL, roomW, roomH].every(Number.isFinite) || roomL <= 0 || roomW <= 0 || roomH <= 0 || roomL > 100 || roomW > 100 || roomH > 30) {
    throw new Error("Room dimensions must be finite positive values within safe limits (L/W <= 100 m, H <= 30 m).");
  }

  const wallAbs = getAbsorptionAt500Hz(wallMaterial);
  const floorAbs = getAbsorptionAt500Hz(floorMaterial);
  const ceilAbs = getAbsorptionAt500Hz(ceilMaterial);

  // Estimate this room's RT60 up front (same Sabine formula used elsewhere)
  // purely to size the run — how many steps are actually needed to reach
  // ~2x the expected decay time, so short/absorptive rooms don't run
  // needlessly long and reverberant rooms get a real tail.
  const volume = roomL * roomW * roomH;
  const wallArea = 2 * (roomL * roomH) + 2 * (roomW * roomH);
  const floorArea = roomL * roomW;
  const ceilArea = roomL * roomW;
  const totalSabins = (wallArea * wallAbs) + (floorArea * floorAbs) + (ceilArea * ceilAbs);
  const estimatedRt60 = (0.161 * volume) / Math.max(totalSabins, 0.01);
  const targetDurationSec = Math.min(estimatedRt60 * 2, 3); // cap target at 3s even for very live rooms

  // Deliberately coarse, fixed-small grid — independent of plan tier, since
  // decay-metric accuracy here depends on step count, not mesh fineness.
  // ~15,000 elements keeps each step cheap enough to run thousands of them
  // synchronously. This is a genuine, documented engineering trade-off
  // (coarse mesh, long duration) for decay analysis, not a shortcut to look
  // more finished than it is.
  const targetElements = 15000;
  // For RT60 we just use a target elements approach because fmax is not provided by the UI for this background task.
  const rawCellVolume = volume / targetElements;
  const dx = Math.max(Math.cbrt(rawCellVolume), 0.05); // coarser floor (5cm) than the preview solver
  const nx = Math.max(4, Math.round(roomL / dx));
  const ny = Math.max(4, Math.round(roomH / dx));
  const nz = Math.max(4, Math.round(roomW / dx));
  const N = nx * ny * nz;
  const nxy = nx * ny;

  // dt must match the Courant coefficient the update loop below actually
  // uses (0.1), not an independent dx/c estimate -- see the /api/solver/wave
  // endpoint above for the full derivation of why Courant^2 = (c*dt/dx)^2 is
  // required for these two numbers to describe the same physics.
  const COURANT = 0.1;
  const dt = (dx * Math.sqrt(COURANT)) / 343;
  const stepsForTarget = Math.ceil(targetDurationSec / dt);
  // Hard cap on steps regardless of target, to bound worst-case request
  // time since this is still synchronous with no progress reporting.
  // NOTE: this cap was not empirically benchmarked in this environment (no
  // ability to run Node here) — treat it as a starting point and tune
  // based on real request latency once deployed.
  const MAX_STEPS = 6000;
  const numSteps = Math.min(stepsForTarget, MAX_STEPS);
  const reachedTarget = stepsForTarget <= MAX_STEPS;

  const wallRefl = Math.sqrt(Math.max(1 - wallAbs, 0));
  const floorRefl = Math.sqrt(Math.max(1 - floorAbs, 0));
  const ceilRefl = Math.sqrt(Math.max(1 - ceilAbs, 0));

  const clamp01 = (v: number) => Math.min(0.98, Math.max(0.02, v));
  const srcX = clamp01(source?.x ?? 0.5), srcZ = clamp01(source?.y ?? 0.5);
  const srcIx = Math.round(srcX * (nx - 1));
  const srcIy = Math.round((source?.z != null ? clamp01(source.z / roomH) : 0.7) * (ny - 1));
  const srcIz = Math.round(srcZ * (nz - 1));
  const srcIdx = srcIy * nxy + srcIz * nx + srcIx;

  const recX = clamp01(receiver?.x ?? 0.25), recZ = clamp01(receiver?.y ?? 0.5);
  const recIx = Math.round(recX * (nx - 1));
  const recIy = Math.round((receiver?.z != null ? clamp01(receiver.z / roomH) : 0.5) * (ny - 1));
  const recIz = Math.round(recZ * (nz - 1));
  const recIdx = recIy * nxy + recIz * nx + recIx;

  // STAGE 14: Stability & Numerical Validation (Geometry & Positions)
  // Moved inside the try block below — see /api/solver/wave above for why
  // throwing before the try starts breaks the route's error handling.
  try {
    if (isNaN(N) || !isFinite(N) || N <= 0) throw new Error("Invalid geometry calculations resulted in NaN/Infinity elements.");
    if (srcIx < 0 || srcIx >= nx || srcIy < 0 || srcIy >= ny || srcIz < 0 || srcIz >= nz) {
      throw new Error("Invalid source position: placed outside the computational boundary.");
    }
    if (recIx < 0 || recIx >= nx || recIy < 0 || recIy >= ny || recIz < 0 || recIz >= nz) {
      throw new Error("Invalid receiver position: placed outside the computational boundary.");
    }

    console.log(`[IMPULSE RESPONSE SOLVER] Room ${roomL}x${roomW}x${roomH}m -> coarse grid ${nx}x${ny}x${nz} (${N.toLocaleString()} elements, dx=${dx.toFixed(3)}m). Steps: ${numSteps}/${stepsForTarget} (target ${targetDurationSec.toFixed(2)}s).`);


    const estimatedMemoryBytes = N * 12 + (numSteps * 8) + 50000000;
    const maxMemoryBytes = process.env.MAX_SOLVER_MEMORY_BYTES ? Number(process.env.MAX_SOLVER_MEMORY_BYTES) : 1500000000;
    if (estimatedMemoryBytes > maxMemoryBytes) {
      throw new Error("Simulation exceeds available system memory budget. Reduce resolution or duration.");
    }
    const startTime = Date.now();
    const p_prev = new Float32Array(N);
    const p = new Float32Array(N);
    const p_next = new Float32Array(N);
    p[Math.max(0, Math.min(N - 1, srcIdx))] = 1.0;

    const Courant = COURANT; // must match the COURANT used to derive dt above, or dt mislabels the trace's real time axis
    const receiverTrace: number[] = [];

    for (let t = 0; t < numSteps; t++) {
      for (let iy = 1; iy < ny - 1; iy++) {
        for (let iz = 1; iz < nz - 1; iz++) {
          const rowBase = iy * nxy + iz * nx;
          for (let ix = 1; ix < nx - 1; ix++) {
            const i = rowBase + ix;
            p_next[i] = (2 * p[i]) - p_prev[i] + Courant * (
              p[i - 1] + p[i + 1] +
              p[i - nx] + p[i + nx] +
              p[i - nxy] + p[i + nxy] -
              (6 * p[i])
            );
          }
        }
      }

      for (let iz = 0; iz < nz; iz++) {
        for (let ix = 0; ix < nx; ix++) {
          p_next[0 * nxy + iz * nx + ix] *= floorRefl;
          p_next[(ny - 1) * nxy + iz * nx + ix] *= ceilRefl;
        }
      }
      for (let iy = 0; iy < ny; iy++) {
        for (let ix = 0; ix < nx; ix++) {
          p_next[iy * nxy + 0 * nx + ix] *= wallRefl;
          p_next[iy * nxy + (nz - 1) * nx + ix] *= wallRefl;
        }
        for (let iz = 0; iz < nz; iz++) {
          p_next[iy * nxy + iz * nx + 0] *= wallRefl;
          p_next[iy * nxy + iz * nx + (nx - 1)] *= wallRefl;
        }
      }

      receiverTrace.push(Math.abs(p_next[Math.max(0, Math.min(N - 1, recIdx))]));

      p_prev.set(p);
      p.set(p_next);
    }

    let peak = 0;
    let peakIdx = 0;
    for (let i = 0; i < receiverTrace.length; i++) {
      if (receiverTrace[i] > peak) {
        peak = receiverTrace[i];
        peakIdx = i;
      }
    }
    peak = peak || 1e-9;
    
    let decayIdxRelative = -1;
    const threshold = peak * Math.pow(10, -30 / 20);
    for (let i = peakIdx; i < receiverTrace.length; i++) {
      if (receiverTrace[i] < threshold) {
        decayIdxRelative = i - peakIdx;
        break;
      }
    }
    let simulatedRt60: number | null = null;
    if (decayIdxRelative > 0) {
      simulatedRt60 = (decayIdxRelative * dt) * 2;
    }

    const actualDurationSec = numSteps * dt;
    const sabineRt60 = estimatedRt60;
    const durationMs = Date.now() - startTime;

    return {
      success: true,
      meshSize: N,
      gridDims: [nx, ny, nz],
      cellSizeM: dx,
      steps: numSteps,
      requestedSteps: stepsForTarget,
      reachedTarget,
      actualDurationSec,
      targetDurationSec,
      computeTimeMs: durationMs,
      rt60: sabineRt60,
      simulatedRt60,
      receiverTrace,
      dtEstimate: dt,
      warning: reachedTarget
        ? null
        : `Simulation was capped at ${numSteps} steps (${actualDurationSec.toFixed(2)}s simulated) before reaching the ${targetDurationSec.toFixed(2)}s target for this room's estimated decay time. RT60/C50/C80/Ts derived from this trace may understate the room's true reverberance.`,
      message: `Computed ${numSteps} time steps (${actualDurationSec.toFixed(2)}s simulated, coarse ${nx}x${ny}x${nz} grid) in ${durationMs}ms.`
    };
  } catch (err: any) {
    console.error("Impulse Response Solver Error:", err);
    throw new Error(err.message || "Impulse response computation failed.");
  }
}
