import type * as FirebaseFirestore from "@google-cloud/firestore";
import { adminDb } from "./firebase-admin";

export const firestoreDb = adminDb;

const lazyCollection = (name: string) => new Proxy({}, {
  get: (target, prop) => {
    const col = firestoreDb.collection(name);
    const value = col[prop as keyof typeof col];
    if (typeof value === 'function') {
      return value.bind(col);
    }
    return value;
  }
}) as unknown as FirebaseFirestore.CollectionReference<FirebaseFirestore.DocumentData>;

export const usersCollection = lazyCollection("users");
export const projectsCollection = lazyCollection("projects");
export const simulationsCollection = lazyCollection("simulations");
export const verificationCodesCollection = lazyCollection("verificationCodes");
export const passwordResetsCollection = lazyCollection("passwordResets");
export const signupAbuseCollection = lazyCollection("signupAbuse");
export const promoCodesCollection = lazyCollection("promoCodes");
export const uniqueEmailsCollection = lazyCollection("uniqueEmails");
export const uniqueUsernamesCollection = lazyCollection("uniqueUsernames");

export interface ProjectRecord {
  id: string;
  ownerId: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  archived?: boolean;
  schemaVersion?: number;
  appVersion?: string;
  data: any;
}
export interface UserRecord {
  uid: string;
  firstName: string;
  lastName: string;
  username: string;
  usernameLower: string;
  email: string;
  emailLower: string;
  passwordHash: string;
  emailVerified: boolean;
  createdAt: number;
  subscriptionStatus: string;
  plan?: string;
  trialStartsAt: number;
  trialEndsAt: number;
  trialUsedAt?: number;
  lemonSqueezyCustomerId?: string;
  polarCustomerId?: string;
  activeProjectId?: string;
  role?: string;
}
export interface SimulationRecord {
  id?: string;
  simulationId: string;
  ownerId: string;
  projectId: string;
  createdAt: number;
  completedAt?: number;
  status: string;
  appVersion?: string;
  solverVersion?: string;
  speakerDatabaseVersion?: string;
  room?: any;
  speakers?: any;
  receivers?: any;
  result?: any;
}
export interface VerificationRecord {
  codeHash: string;
  attempts: number;
  expiresAt: number;
  lastSentAt: number;
}
export interface PasswordResetRecord {
  codeHash: string;
  attempts: number;
  expiresAt: number;
  lastSentAt: number;
}
export interface PromoCodeRecord {
  code: string;
  grant: "lifetime";
  createdAt: number;
  createdBy: string;
  note?: string;
  redeemed: boolean;
  redeemedBy?: string;
  redeemedAt?: number;
  revoked?: boolean;
}
