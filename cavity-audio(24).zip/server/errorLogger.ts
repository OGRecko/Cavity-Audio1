import express from 'express';
import fs from 'fs';
export const errorLogger = express.Router();
errorLogger.post('/log-error', express.json(), (req, res) => {
  fs.appendFileSync('client-errors.log', JSON.stringify(req.body) + '\n');
  res.sendStatus(200);
});
