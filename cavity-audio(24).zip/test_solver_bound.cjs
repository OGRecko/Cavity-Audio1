// This tests how the current boundary update is applied.
// The current logic loops interior from 1 to n-1. 
// Then it multiplies the boundary cells (which were never updated and are 0) by the reflection factor.
// We'll write a patch that properly applies the reflection.

const fs = require('fs');
let src = fs.readFileSync('server/solverWorker.ts', 'utf8');

// The issue: the interior loop only goes 1 to nx-1. The boundary cells (0 and nx-1) are never updated in p_next from the wave equation, so they remain 0.
// Then p_next[boundary] *= floorRefl does 0 *= floorRefl.
// We must compute a boundary condition for p_next at the edges.
// A simple locally reacting boundary condition:
// p_next[boundary] = p_next[interior_neighbor] * reflection

const replacement = `      }
      
      // Boundary reflection: Apply locally reacting boundary conditions.
      // The interior loop above only computes pressure for cells 1 to N-2.
      // The boundary cells (0 and N-1) were skipped and remain 0.
      // Merely multiplying them by a reflection coefficient (0 * R = 0) does not reflect waves; it behaves like an open boundary.
      // Instead, we implement a simple first-order pressure boundary condition:
      // The pressure at the boundary is the pressure at the adjacent interior cell, multiplied by the reflection coefficient.
      // This explicitly models the wall as a partially reflective surface reflecting the adjacent interior field.
      
      for (let iz = 1; iz < nz - 1; iz++) {
        for (let ix = 1; ix < nx - 1; ix++) {
          p_next[0 * nxy + iz * nx + ix] = p_next[1 * nxy + iz * nx + ix] * floorRefl;
          p_next[(ny - 1) * nxy + iz * nx + ix] = p_next[(ny - 2) * nxy + iz * nx + ix] * ceilRefl;
        }
      }
      
      for (let iy = 1; iy < ny - 1; iy++) {
        for (let ix = 1; ix < nx - 1; ix++) {
          p_next[iy * nxy + 0 * nx + ix] = p_next[iy * nxy + 1 * nx + ix] * wallRefl;
          p_next[iy * nxy + (nz - 1) * nx + ix] = p_next[iy * nxy + (nz - 2) * nx + ix] * wallRefl;
        }
        for (let iz = 1; iz < nz - 1; iz++) {
          p_next[iy * nxy + iz * nx + 0] = p_next[iy * nxy + iz * nx + 1] * wallRefl;
          p_next[iy * nxy + iz * nx + (nx - 1)] = p_next[iy * nxy + iz * nx + (nx - 2)] * wallRefl;
        }
      }
      // Edges and corners are left at 0 for simplicity, which is standard for a simple Cartesian 7-point stencil.`;

src = src.replace(/      \}\n\n      \/\/ Boundary reflection: attenuate the outermost shell[\s\S]*?p_next\[iy \* nxy \+ iz \* nx \+ \(nx - 1\)\] \*= wallRefl;\n        \}\n      \}/, replacement);

fs.writeFileSync('server/solverWorker.ts', src);
console.log('Patched boundary in wave solver');
