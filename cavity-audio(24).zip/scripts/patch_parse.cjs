const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  /function parseFiniteInRange\(val: any, min: number, max: number, defaultVal: number\): number \{\s*const num = Number\(val\);\s*if \(Number\.isFinite\(num\) && num >= min && num <= max\) return num;\s*return defaultVal;\s*\}/,
  `function parseFiniteInRange(val: any, min: number, max: number, nameOrDef: any): number {
    const num = Number(val);
    if (Number.isFinite(num) && num >= min && num <= max) return num;
    if (typeof nameOrDef === "string") throw new Error(nameOrDef + " is invalid");
    return nameOrDef;
  }`
);

fs.writeFileSync('server.ts', code);
console.log('patched parseFiniteInRange');
