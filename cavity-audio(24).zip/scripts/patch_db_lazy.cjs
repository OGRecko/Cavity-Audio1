const fs = require('fs');
let code = fs.readFileSync('server/db.ts', 'utf8');

code = code.replace(
  'export const usersCollection = firestoreDb.collection("users");',
  `const lazyCollection = (name) => new Proxy({}, {
  get: (target, prop) => {
    return firestoreDb.collection(name)[prop];
  }
});

export const usersCollection = lazyCollection("users");`
);

code = code.replace(/export const (.*?)Collection = firestoreDb\.collection\("(.*?)"\);/g, 'export const $1Collection = lazyCollection("$2");');

fs.writeFileSync('server/db.ts', code);
console.log('patched db.ts to be lazy');
