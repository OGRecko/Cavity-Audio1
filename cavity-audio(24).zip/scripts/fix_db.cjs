const fs = require('fs');
let code = fs.readFileSync('server/db.ts', 'utf8');

code = code.replace(
  /const lazyCollection = \(name: string\) => new Proxy\(\{\}, \{\n  get: \(target, prop\) => \{\n    return firestoreDb\.collection\(name\)\[prop as any\];\n  \}\n\}\) as FirebaseFirestore\.CollectionReference;\n  \}\n\}\);/,
  'const lazyCollection = (name: string) => new Proxy({}, {\n  get: (target, prop) => {\n    return firestoreDb.collection(name)[prop as keyof typeof firestoreDb.collection];\n  }\n}) as unknown as FirebaseFirestore.CollectionReference<FirebaseFirestore.DocumentData>;'
);

fs.writeFileSync('server/db.ts', code);
console.log('fixed db.ts');
