const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'app.use(cookieParser());',
  `app.use(cookieParser());
app.use((req, res, next) => {
  if (req.originalUrl === '/api/webhooks/polar') {
    return next();
  }
  express.json({ limit: '5mb' })(req, res, next);
});`
);

code = code.replace(/express\.json\(\s*\{[^}]*\}\s*\),\s*/g, '');
code = code.replace(/express\.json\(\),\s*/g, '');

fs.writeFileSync('server.ts', code);
console.log('patched express json');
