const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const regex = /\/\/ The DB \(server\/db\.ts\) is a single JSON file on local disk[\s\S]*?console\.warn\([\s\S]*?\);\n\s*\}/g;

code = code.replace(regex, '');

fs.writeFileSync('server.ts', code);
console.log('patched warn');
