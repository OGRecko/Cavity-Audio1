const fs = require('fs');

// Patch useStore.ts
let storeCode = fs.readFileSync('src/store/useStore.ts', 'utf8');

// Inside saveProject, add schemaVersion and appVersion
storeCode = storeCode.replace(
  'const data = JSON.stringify({',
  `const data = JSON.stringify({
      schemaVersion: 1,
      appVersion: "1.0.0",`
);

// Inside loadProject, read file and applyProjectData
const loadSearch = `      const data = JSON.parse(e.target?.result as string);
      get().past.push({ ...get() });
      get().future = [];
      set({
        roomName: data.roomName || 'Studio',
        poly: data.poly || [{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
        L: data.L || 6, W: data.W || 4, H: data.H || 3,
        wallMaterial: data.wallMaterial || 'gypsum_board',
        wallSegMats: data.wallSegMats || [],
        wallOpenings: data.wallOpenings || [],
        floorMaterial: data.floorMaterial || 'concrete',
        ceilMaterial: data.ceilMaterial || 'gypsum_board',
        scatter: data.scatter || 0.1,
        sources: data.sources || [],
        receivers: data.receivers || [],
        simulations: data.simulations || [],
      });`;

const loadReplacement = `      let data;
      try {
        data = JSON.parse(e.target?.result as string);
      } catch (err) {
        alert("Invalid project file (not JSON).");
        return;
      }
      if (!data || typeof data !== "object") {
        alert("Invalid project file (not an object).");
        return;
      }
      
      // Migration logic
      let v = data.schemaVersion || 0;
      if (v === 0) {
        // v0 -> v1 migration
        data.schemaVersion = 1;
      }
      
      if (data.schemaVersion > 1) {
        alert("This project was saved in a newer version. Please update the application.");
        return;
      }
      
      get().past.push({ ...get() });
      get().future = [];
      set({
        roomName: data.roomName || 'Studio',
        poly: data.poly || [{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
        L: data.L || 6, W: data.W || 4, H: data.H || 3,
        wallMaterial: data.wallMaterial || 'gypsum_board',
        wallSegMats: data.wallSegMats || [],
        wallOpenings: data.wallOpenings || [],
        floorMaterial: data.floorMaterial || 'concrete',
        ceilMaterial: data.ceilMaterial || 'gypsum_board',
        scatter: data.scatter || 0.1,
        sources: data.sources || [],
        receivers: data.receivers || [],
        simulations: data.simulations || [],
      });`;

storeCode = storeCode.replace(loadSearch, loadReplacement);
fs.writeFileSync('src/store/useStore.ts', storeCode);
console.log('patched useStore.ts');

// Patch useProjectsStore.ts
let projCode = fs.readFileSync('src/store/useProjectsStore.ts', 'utf8');

projCode = projCode.replace(
  'function extractProjectData() {',
  `function extractProjectData() {
  const s = useStore.getState();
  return {
    schemaVersion: 1,
    appVersion: "1.0.0",
    roomName: s.roomName,
    poly: s.poly,
    L: s.L, W: s.W, H: s.H,
    wallMaterial: s.wallMaterial,
    wallSegMats: s.wallSegMats,
    wallOpenings: s.wallOpenings,
    floorMaterial: s.floorMaterial,
    ceilMaterial: s.ceilMaterial,
    scatter: s.scatter,
    sources: s.sources,
    receivers: s.receivers,
    simulations: s.simulations,
  };
}
function extractProjectDataOld() {`
);

const applySearch = `function applyProjectData(data: any) {
  if (!data) return;`;

const applyReplacement = `function applyProjectData(data: any) {
  if (!data || typeof data !== "object") return;
  
  let v = data.schemaVersion || 0;
  if (v === 0) {
    // v0 -> v1 migration
    data.schemaVersion = 1;
  }
  
  if (data.schemaVersion > 1) {
    console.error("This project was saved in a newer version. It may not load correctly.");
  }
`;

projCode = projCode.replace(applySearch, applyReplacement);

fs.writeFileSync('src/store/useProjectsStore.ts', projCode);
console.log('patched useProjectsStore.ts');
