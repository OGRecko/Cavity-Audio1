const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const regex = /const endTime = Date.now\(\);\s*const durationMs = endTime - startTime;\s*res.json\(\{(.*?)\}\);/s;

code = code.replace(regex, (match, inner) => {
  if (match.includes('simulationId')) return match; // Already patched
  return `const endTime = Date.now();
    const durationMs = endTime - startTime;
    const simulationId = crypto.randomUUID();
    
    const resultObj = {
      rt60: sabineRt60,
      simulatedRt60,
      gridDims: [nx, ny, nz],
      steps: numSteps,
      targetDurationSec,
      actualDurationSec,
      warning: reachedTarget ? null : "Simulation capped early",
    };

    simulationsCollection.doc(simulationId).set({
      simulationId,
      ownerId: req.user.uid,
      projectId: req.body.projectId || "unknown",
      createdAt: Date.now(),
      status: "completed",
      room: req.body,
      speakers: [source],
      receivers: [receiver],
      result: resultObj
    }).catch((e: any) => console.error("Failed to save simulation", e));

    res.json({
      simulationId,
${inner}});`
});

fs.writeFileSync('server.ts', code);
console.log('patched impulse save');
