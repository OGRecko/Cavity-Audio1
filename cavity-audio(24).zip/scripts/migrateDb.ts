import { adminDb as firestoreDb } from "../server/firebase-admin";

async function migrate() {
  console.log("Starting DB migration...");
  const snapshot = await firestoreDb.collection("system_store").doc("main").get();
  
  if (!snapshot.exists) {
    console.log("No legacy data found in system_store/main.");
    return;
  }

  const data = snapshot.data() as any;
  let dbShape: any;
  if (typeof data.payload === 'string') {
     dbShape = JSON.parse(data.payload);
  } else {
     dbShape = data.payload;
  }

  if (!dbShape) {
    console.log("No valid payload in system_store/main.");
    return;
  }

  const batchSize = 100;
  let batch = firestoreDb.batch();
  let count = 0;

  async function commitBatch() {
    if (count > 0) {
      await batch.commit();
      batch = firestoreDb.batch();
      count = 0;
    }
  }

  // Migrate Users
  if (dbShape.users) {
    for (const [uid, userEntry] of Object.entries(dbShape.users)) { const user = userEntry as any;
      const userRef = firestoreDb.collection("users").doc(uid);
      batch.set(userRef, user);
      count++;
      if (count >= batchSize) await commitBatch();
      
      // Migrate Projects inside User
      if (user.projects) {
        for (const [projectId, project] of Object.entries(user.projects)) {
          const projectRef = firestoreDb.collection("projects").doc(projectId);
          batch.set(projectRef, { ...(project as any), ownerId: uid });
          count++;
          if (count >= batchSize) await commitBatch();
        }
      }
    }
  }

  // Migrate Verification Codes
  if (dbShape.verificationCodes) {
    for (const [email, record] of Object.entries(dbShape.verificationCodes)) {
      const ref = firestoreDb.collection("verificationCodes").doc(email);
      batch.set(ref, record);
      count++;
      if (count >= batchSize) await commitBatch();
    }
  }

  // Migrate Password Resets
  if (dbShape.passwordResets) {
    for (const [email, record] of Object.entries(dbShape.passwordResets)) {
      const ref = firestoreDb.collection("passwordResets").doc(email);
      batch.set(ref, record);
      count++;
      if (count >= batchSize) await commitBatch();
    }
  }

  // Migrate Promo Codes
  if (dbShape.promoCodes) {
    for (const [code, record] of Object.entries(dbShape.promoCodes)) {
      const ref = firestoreDb.collection("promoCodes").doc(code);
      batch.set(ref, record);
      count++;
      if (count >= batchSize) await commitBatch();
    }
  }

  await commitBatch();
  console.log("Migration complete.");
}

migrate().catch(console.error);
