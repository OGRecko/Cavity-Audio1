const fs = require('fs');
let code = fs.readFileSync('server/db.ts', 'utf8');

code = code.replace(
  'const lazyCollection = (name) => new Proxy({}, {',
  'const lazyCollection = (name: string) => new Proxy({}, {\n  get: (target, prop) => {\n    return firestoreDb.collection(name)[prop as any];\n  }\n}) as FirebaseFirestore.CollectionReference;'
);

code = `import type * as FirebaseFirestore from "@google-cloud/firestore";\n` + code;

fs.writeFileSync('server/db.ts', code);
console.log('patched db types');
