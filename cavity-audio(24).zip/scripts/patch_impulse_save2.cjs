const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetStr = `    const endTime = Date.now();
    const durationMs = endTime - startTime;

    res.json({
      success: true,`;

const replacementStr = `    const endTime = Date.now();
    const durationMs = endTime - startTime;
    const simulationId = crypto.randomUUID();
    
    const resultObj = {
      rt60: sabineRt60,
      simulatedRt60,
      gridDims: [nx, ny, nz],
      steps: numSteps,
      targetDurationSec,
      actualDurationSec,
      warning: reachedTarget ? null : "Simulation capped early",
    };

    simulationsCollection.doc(simulationId).set({
      simulationId,
      ownerId: req.user.uid,
      projectId: req.body.projectId || "unknown",
      createdAt: Date.now(),
      status: "completed",
      room: req.body,
      speakers: [source],
      receivers: [receiver],
      result: resultObj
    }).catch((e: any) => console.error("Failed to save simulation", e));

    res.json({
      success: true,
      simulationId,`;

code = code.replace(targetStr, replacementStr);

fs.writeFileSync('server.ts', code);
console.log('patched impulse save 2');
