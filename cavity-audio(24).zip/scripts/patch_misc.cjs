const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'const session = await polar.checkouts.custom.create({',
  'const session = await polar.checkouts.create({'
);

code = code.replace(
  'import { OAuth2Client } from "google-auth-library";',
  ''
); // in case it was there

code = code.replace(
  'import express from "express";',
  'import express from "express";\nimport { OAuth2Client } from "google-auth-library";\nconst googleClient = new OAuth2Client();'
);

fs.writeFileSync('server.ts', code);
console.log('patched misc');
