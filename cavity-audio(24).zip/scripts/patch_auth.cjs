const fs = require('fs');
let code = fs.readFileSync('server_top.ts', 'utf-8');

code = code.replace(
`async function authMiddleware(req: any, res: any, next: any) {
  try {
  const uid = verifySessionToken(req.cookies?.[SESSION_COOKIE_NAME]);
  if (!uid) {
    return res.status(401).json({ error: "Not logged in." });
  }
  const db = await readDb();
  const user = db.users[uid];
  if (!user) {
    res.clearCookie(SESSION_COOKIE_NAME);
    return res.status(401).json({ error: "Not logged in." });
  }
  req.user = user;
  next();
  } catch (err) {
    console.error("Auth middleware error:", err);
    res.status(503).json({ error: "Service unavailable." });
  }
}`,
`async function authMiddleware(req: any, res: any, next: any) {
  try {
    const uid = verifySessionToken(req.cookies?.[SESSION_COOKIE_NAME]);
    if (!uid) {
      return res.status(401).json({ error: "Not logged in." });
    }
    const doc = await usersCollection.doc(uid).get();
    if (!doc.exists) {
      res.clearCookie(SESSION_COOKIE_NAME);
      return res.status(401).json({ error: "Not logged in." });
    }
    req.user = doc.data();
    next();
  } catch (err) {
    console.error("Auth middleware error:", err);
    res.status(503).json({ error: "Service unavailable." });
  }
}`
);

fs.writeFileSync('server_top.ts', code);
