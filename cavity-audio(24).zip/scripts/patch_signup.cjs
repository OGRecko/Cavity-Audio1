const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'import { checkSignupRateLimit, recordSignupAttempt } from "./server/signupRateLimit";',
  'import { checkAndRecordSignup } from "./server/signupRateLimit";'
);

const signupStart = 'app.post("/api/auth/signup", signupLimiter, async (req: any, res: any) => {';
const signupReplacement = `app.post("/api/auth/signup", express.json({ limit: "100kb" }), async (req: any, res: any) => {
  const ipStatus = await checkAndRecordSignup(req.ip || req.connection?.remoteAddress);
  if (!ipStatus.allowed) {
    if (ipStatus.permanent) {
      return res.status(429).json({ error: "Too many signups from this IP. Permanent ban." });
    } else {
      return res.status(429).json({ error: \`Too many signups from this IP. Try again in \${Math.ceil(ipStatus.waitMs / 60000)} minute(s).\` });
    }
  }
`;

code = code.replace(signupStart, signupReplacement);

fs.writeFileSync('server.ts', code);
console.log('patched signup route');
