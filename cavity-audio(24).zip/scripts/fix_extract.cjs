const fs = require('fs');
let code = fs.readFileSync('src/store/useProjectsStore.ts', 'utf8');

// Replace the extractProjectDataOld definition and the original return object
const start = code.indexOf('function extractProjectDataOld() {');
const end = code.indexOf('}', start);

code = code.substring(0, start) + code.substring(end + 1);

fs.writeFileSync('src/store/useProjectsStore.ts', code);
console.log('fixed extract');
