const fs = require('fs');
let code = fs.readFileSync('scripts/migrateDb.ts', 'utf8');
code = code.replace('{ ...project, ownerId: uid }', '{ ...(project as any), ownerId: uid }');
fs.writeFileSync('scripts/migrateDb.ts', code);
