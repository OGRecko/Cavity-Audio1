const fs = require('fs');
let speakers = JSON.parse(fs.readFileSync('src/data/speakers.json', 'utf8'));

for (let s of speakers) {
  // Fix 0 impedance
  if (s.impedance && s.impedance.value === 0) {
    s.impedance.value = null;
    s.impedance.status = s.active ? "NOT_APPLICABLE" : "UNAVAILABLE";
    s.impedance.source = null;
    s.impedance.sourceType = "NONE";
  }

  // Fix 0 woofer size
  if (s.woofer && s.woofer.value === 0) {
    s.woofer.value = null;
    s.woofer.status = "UNAVAILABLE";
    s.woofer.source = null;
    s.woofer.sourceType = "NONE";
  }
}

fs.writeFileSync('src/data/speakers.json', JSON.stringify(speakers, null, 2));
console.log('Fixed zero values in objects');
