const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'const doc = await generateAcousticReport(reportRoom, speakers || [], receivers || [], solverResult, parsedSnr, simSummary);',
  'const doc = await generateAcousticReport({ room: reportRoom, speakers: speakers || [], receivers: receivers || [], solverResult: solverResult as any, assumedSnrDb: parsedSnr, projectName: "Export", roomName: "Export" } as any);'
);

fs.writeFileSync('server.ts', code);
console.log('patched call');
