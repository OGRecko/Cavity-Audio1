const fs = require('fs');
let speakers = JSON.parse(fs.readFileSync('src/data/speakers.json', 'utf8'));

// "Invalid speaker values: Never use 0 to mean unknown/not available/not applicable."
// "Specifically inspect: Jensen P10R, Jensen P12N, JL Audio 12W7, JL Audio Fathom f113, Rockford Fosgate Punch P3 12, Kicker CompVR 12, Pioneer TS-A1670F, Celestion V30, Celestion Greenback, Celestion G12H30, Eminence Legend."

const inspectModels = [
  "P10R", "P12N", "12W7", "Fathom f113", "Punch P3 12", "CompVR 12", "TS-A1670F", 
  "Vintage 30", "V30", "G12M Greenback", "Greenback", "G12H-30", "G12H30", "Legend"
];

for (let s of speakers) {
  // Fix 0 impedance
  if (s.impedance === 0) {
    s.impedance = null;
    if (s.status) { // if status exists
      // Wait, is status per field or per speaker? 
      // The prompt says "if a value cannot be verified: downgrade it to ESTIMATED or UNAVAILABLE"
      // Also: "use null plus status: UNAVAILABLE or NOT_APPLICABLE"
      // Usually status is at the root.
    }
  }

  // Fix 0 woofer size
  if (s.woofer === 0) {
    s.woofer = null;
  }
}

fs.writeFileSync('src/data/speakers_fixed.json', JSON.stringify(speakers, null, 2));
console.log('Fixed basic 0s. Need to inspect models specifically.');
