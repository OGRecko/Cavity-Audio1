const fs = require('fs');
let code = fs.readFileSync('server/firebase-admin.ts', 'utf8');

const replacement = `import { initializeApp, cert, getApps, applicationDefault } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import firebaseConfig from '../firebase-applet-config.json';

if (getApps().length === 0) {
  try {
    if (process.env.FIREBASE_SERVICE_ACCOUNT) {
      initializeApp({ credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)), projectId: firebaseConfig.projectId });
    } else {
      initializeApp({ credential: applicationDefault(), projectId: firebaseConfig.projectId });
    }
  } catch(e) {
    console.error("Failed to initialize Firebase Admin:", e);
  }
}

const dbId = process.env.FIRESTORE_DATABASE_ID || firebaseConfig.firestoreDatabaseId;
export const adminDb = getFirestore(dbId);
`;

fs.writeFileSync('server/firebase-admin.ts', replacement);
console.log('patched firebase-admin');
