const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const firstPolarIdx = code.indexOf('app.post("/api/webhooks/polar"');
const signupIdx = code.indexOf('app.post("/api/auth/signup"');

if (firstPolarIdx !== -1 && signupIdx !== -1 && firstPolarIdx < signupIdx) {
  code = code.substring(0, firstPolarIdx) + code.substring(signupIdx);
}

// Now replace the second polar webhook with a correct one.
const secondPolarIdx = code.indexOf('app.post("/api/webhooks/polar"');
const reportExportIdx = code.indexOf('app.post("/api/report/export"');

if (secondPolarIdx !== -1 && reportExportIdx !== -1 && secondPolarIdx < reportExportIdx) {
  const newPolarWebhook = `app.post("/api/webhooks/polar", express.raw({ type: '*/*' }), async (req: any, res: any) => {
  const secret = process.env.POLAR_WEBHOOK_SECRET;
  if (!secret) {
    return res.status(500).json({ error: "Webhook secret not configured" });
  }
  let event: any;
  try {
    const { validateEvent } = await import('@polar-sh/sdk/webhooks');
    event = validateEvent(req.body, req.headers, secret);
  } catch (err: any) {
    console.error("Polar webhook signature verification failed:", err?.message || err);
    return res.status(403).json({ error: "Invalid webhook signature" });
  }

  const payload = event;
  const eventName = payload.type;
  const data = payload.data;
  
  const userId = data.custom_field_data?.uid || data.metadata?.userId;
  
  try {
    let userRecord = null;
    let userDoc = null;
    if (userId) {
      userDoc = await usersCollection.doc(userId).get();
      if (userDoc.exists) {
        userRecord = userDoc.data();
      }
    }

    if (userRecord && eventName === "subscription.created") {
      const plan = resolvePlanFromProductId(data.product_id || data.productId);
      if (!plan) return res.status(400).json({ error: "Unrecognized Polar product." });
      await usersCollection.doc(userId).update({
        subscriptionStatus: "active",
        polarCustomerId: data.customer_id || data.customerId,
        plan: plan
      });
    } else if (userRecord && eventName === "subscription.updated") {
       const plan = resolvePlanFromProductId(data.product_id || data.productId);
       if (!plan) return res.status(400).json({ error: "Unrecognized Polar product." });
       await usersCollection.doc(userId).update({
         subscriptionStatus: data.status === "active" ? "active" : "canceled",
         plan: plan
       });
    } else if (userRecord && (eventName === "subscription.canceled" || eventName === "subscription.revoked")) {
      await usersCollection.doc(userId).update({
        subscriptionStatus: "canceled"
      });
    }
    res.json({ success: true });
  } catch (err) {
    console.error("Error processing Polar webhook:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

`;
  code = code.substring(0, secondPolarIdx) + newPolarWebhook + code.substring(reportExportIdx);
}

fs.writeFileSync('server.ts', code);
console.log('patched webhooks');
