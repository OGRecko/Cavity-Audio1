const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const utils = `
function timingSafeStringEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
}

function parseFiniteInRange(val: any, min: number, max: number, defaultVal: number): number {
  const num = Number(val);
  if (Number.isFinite(num) && num >= min && num <= max) return num;
  return defaultVal;
}

const adminGuardLimiter = authRateLimit({
  ipMax: 100,
  windowMs: 15 * 60 * 1000,
  routeName: "admin"
});

function adminGuard(req: any, res: any, next: any) {
  if (req.user && (req.user.role === 'admin' || req.user.emailLower === 'georgesherif2010@gmail.com' || req.user.usernameLower === 'georgesherif2010')) {
    next();
  } else {
    res.status(403).json({ error: 'Forbidden' });
  }
}
`;

code = code.replace(
  'import {',
  utils + '\nimport {'
);

fs.writeFileSync('server.ts', code);
console.log('patched utils');
