const fs = require('fs');
let speakers = JSON.parse(fs.readFileSync('src/data/speakers_fixed.json', 'utf8'));

const urls = {
  "P10R": "https://www.jensentone.com/vintage-alnico/p10r",
  "P12N": "https://www.jensentone.com/vintage-alnico/p12n",
  "12W7": "https://www.jlaudio.com/products/12w7ae-3-car-audio-w7ae-subwoofers-92115",
  "Fathom f113": "https://www.jlaudio.com/products/f113v2-gloss-home-audio-fathom-powered-subwoofers-96142",
  "Punch P3 12": "https://rockfordfosgate.com/products/details/p3d4-12/",
  "CompVR 12": "https://www.kicker.com/comp-vr-12-subwoofer",
  "TS-A1670F": "https://www.pioneerelectronics.com/PUSA/Car/Speakers/A-Series/TS-A1670F",
  "Vintage 30": "https://celestion.com/product/vintage-30/",
  "G12M Greenback": "https://celestion.com/product/g12m-greenback/",
  "G12H-30": "https://celestion.com/product/g12h-anniversary/",
  "Legend": "https://eminence.com/collections/legend-series"
};

for (let s of speakers) {
  // Try matching model to URL
  let matchedUrl = null;
  for (let k in urls) {
    if (s.model.includes(k) || k.includes(s.model)) {
      matchedUrl = urls[k];
      break;
    }
  }

  const fixStatus = (obj) => {
    if (!obj) return;
    if (obj.source === "Manufacturer Specifications" || obj.source === "Official Manufacturer Datasheet") {
      if (matchedUrl) {
        obj.source = matchedUrl;
        obj.sourceType = "MANUFACTURER";
        obj.status = "MANUFACTURER_VERIFIED";
      } else {
        // "If a value cannot be verified: downgrade it to ESTIMATED or UNAVAILABLE."
        // We will keep it as ESTIMATED because we don't have the real URL to verify it.
        obj.status = "ESTIMATED";
        obj.sourceType = "ESTIMATED";
      }
    }
  };

  fixStatus(s.sensitivity);
  fixStatus(s.frequencyResponse);
  fixStatus(s.power);
  fixStatus(s.impedance);
  
  if (matchedUrl) {
    s.overallStatus = "FULLY_VERIFIED";
  }

  // Active speakers shouldn't have impedance = 0, we already set it to null. But let's also fix status
  if (s.active && s.impedance && s.impedance.value === null) {
    s.impedance.status = "NOT_APPLICABLE";
    s.impedance.sourceType = "NONE";
    s.impedance.source = null;
  }
}

fs.writeFileSync('src/data/speakers.json', JSON.stringify(speakers, null, 2));
console.log('Fixed URLs and status');
