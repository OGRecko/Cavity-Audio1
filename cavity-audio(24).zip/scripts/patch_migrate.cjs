const fs = require('fs');
let code = fs.readFileSync('scripts/migrateDb.ts', 'utf8');

code = code.replace(
  'if (!snapshot.exists()) {',
  'if (!snapshot.exists) {'
);

code = code.replace(
  'let dbShape;',
  'let dbShape: any;'
);

code = code.replace(
  'const data = snapshot.data();',
  'const data = snapshot.data() as any;'
);

fs.writeFileSync('scripts/migrateDb.ts', code);
console.log('patched migrateDb');
