const { initializeApp } = require('firebase/app');
const { getFirestore, collection, getDocs } = require('firebase/firestore');
const config = require('./firebase-applet-config.json');

const app = initializeApp(config);
const db = getFirestore(app, config.firestoreDatabaseId);

getDocs(collection(db, 'users')).then(snap => {
  console.log(`Users migrated: ${snap.size}`);
  process.exit(0);
}).catch(console.error);
