const fs = require('fs');

let layoutSrc = fs.readFileSync('src/components/Layout.tsx', 'utf8');

layoutSrc = layoutSrc.replace(
  'const activeProjectId = useProjectsStore((s) => s.activeProjectId);',
  'const activeProjectId = useProjectsStore((s) => s.activeProjectId);\n  const projectsError = useProjectsStore((s) => s.error);'
);

const bannerHtml = `
      {projectsError && (
        <div className="absolute top-0 left-0 right-0 z-50 p-2 bg-red-500 text-white text-center text-sm">
          {projectsError}
        </div>
      )}
      <AuthModal />
`;

layoutSrc = layoutSrc.replace('<AuthModal />', bannerHtml);

fs.writeFileSync('src/components/Layout.tsx', layoutSrc);
console.log('patched layout.tsx');
