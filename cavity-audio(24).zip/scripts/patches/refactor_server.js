const { Project } = require("ts-morph");
const project = new Project();
const sourceFile = project.addSourceFileAtPath("server.ts");

const appGets = sourceFile.getDescendantsOfKind(require("ts-morph").SyntaxKind.CallExpression)
  .filter(c => c.getExpression().getText() === "app.get");
console.log("Found app.get calls:", appGets.length);
