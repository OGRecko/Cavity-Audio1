const fs = require('fs');
let serverSrc = fs.readFileSync('server.ts', 'utf8');

const postList = `app.post("/api/projects", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const name = String(req.body.name || 'Untitled Project').slice(0, 200);
  const id = crypto.randomUUID();
  const now = Date.now();

  const newProject: ProjectRecord = {
    id,
    ownerId: uid,
    name,
    createdAt: now,
    updatedAt: now,
    archived: false,
    schemaVersion: 1,
    appVersion: "1.0.0",
    data: req.body.data ?? null,
  };

  try {
    await projectsCollection.doc(id).set(newProject);
    await usersCollection.doc(uid).update({ activeProjectId: id });
    res.json({ success: true, project: newProject });
  } catch (err) {
    console.error("POST /api/projects error:", err);
    res.status(500).json({ error: "Service unavailable." });
  }
});`;

serverSrc = serverSrc.replace(/app\.post\("\/api\/projects", authMiddleware, async \(req: any, res: any\) => \{[\s\S]*?res\.json\(\{ success: true, project: newProject \}\);\n\}\);/, postList);

fs.writeFileSync('server.ts', serverSrc);
console.log('patched CREATE project');
