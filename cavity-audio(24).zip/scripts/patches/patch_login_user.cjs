const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'setSessionCookie(res, user.uid, !!rememberMe);\n  res.json({ success: true, user: sanitizeUser(user) });',
  'setSessionCookie(res, loggedInUser.uid, !!rememberMe);\n  res.json({ success: true, user: sanitizeUser(loggedInUser) });'
);

fs.writeFileSync('server.ts', code);
console.log('patched login user');
