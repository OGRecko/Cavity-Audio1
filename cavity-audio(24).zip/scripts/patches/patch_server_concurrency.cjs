const fs = require('fs');

let serverSrc = fs.readFileSync('server.ts', 'utf8');

const updateRouteStr = `app.put("/api/projects/:id", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const ref = projectsCollection.doc(req.params.id);
  
  try {
    const project = await firestoreDb.runTransaction(async (t) => {
      const doc = await t.get(ref);
      if (!doc.exists) throw new Error("Not found");
      const p = doc.data() as ProjectRecord;
      if (p.ownerId !== uid || p.archived) throw new Error("Not found");
      
      if (req.body.updatedAt != null && p.updatedAt > req.body.updatedAt) {
         throw new Error("Conflict: Project modified elsewhere.");
      }
      
      const updates: any = { updatedAt: Date.now() };
      if (req.body.name != null) updates.name = String(req.body.name).slice(0, 200);
      if (req.body.data !== undefined) updates.data = req.body.data;
      
      t.update(ref, updates);
      return { ...p, ...updates };
    });
    res.json({ success: true, project });
  } catch (e: any) {
    if (e.message.startsWith("Conflict")) {
      return res.status(409).json({ error: "This project has been modified in another session. Please reload." });
    }
    res.status(404).json({ error: "Project not found." });
  }
});`;

serverSrc = serverSrc.replace(/app\.put\("\/api\/projects\/:id"[\s\S]*?catch \(e: any\) \{\n    res\.status\(404\)\.json\(\{ error: "Project not found\." \}\);\n  \}\n\}\);/, updateRouteStr);

fs.writeFileSync('server.ts', serverSrc);
console.log('patched server concurrency');
