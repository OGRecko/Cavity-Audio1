const fs = require('fs');

const waveSrc = fs.readFileSync('/tmp/wave.txt', 'utf8');
const irSrc = fs.readFileSync('/tmp/ir.txt', 'utf8');

let worker = fs.readFileSync('server/solverWorker.ts', 'utf8');

// extract the body of wave
let waveBody = waveSrc.replace(/app\.post\(".*?async \(req: any, res: any\) => \{/, '');
// find the last '});' and remove it
waveBody = waveBody.substring(0, waveBody.lastIndexOf('});'));
// replace req.body with payload
waveBody = waveBody.replace(/req\.body/g, 'payload');
waveBody = waveBody.replace(/req\.user\.plan/g, 'payload.userPlan');
waveBody = waveBody.replace(/return res\.status\(400\)\.json\(\{ error: (.*?) \}\);/g, 'throw new Error($1);');
waveBody = waveBody.replace(/res\.json\((.*?)\);/g, 'return $1;');
// remove the `const isPro = req.user.plan ...` if needed, but payload.userPlan is fine.

let irBody = irSrc.replace(/app\.post\(".*?async \(req: any, res: any\) => \{/, '');
irBody = irBody.substring(0, irBody.lastIndexOf('});'));
irBody = irBody.replace(/req\.body/g, 'payload');
irBody = irBody.replace(/req\.user\.plan/g, 'payload.userPlan');
irBody = irBody.replace(/return res\.status\(400\)\.json\(\{ error: (.*?) \}\);/g, 'throw new Error($1);');
irBody = irBody.replace(/res\.json\((.*?)\);/g, 'return $1;');


worker = worker.replace('function runWave(payload: any) {\n  // we will insert the body of /tmp/wave.txt here\n}', 'function runWave(payload: any) {\n' + waveBody + '\n}');
worker = worker.replace('function runIR(payload: any) {\n  // we will insert the body of /tmp/ir.txt here\n}', 'function runIR(payload: any) {\n' + irBody + '\n}');

fs.writeFileSync('server/solverWorker.ts', worker);
console.log('patched solver worker');
