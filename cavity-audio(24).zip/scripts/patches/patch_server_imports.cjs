const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

if (!code.includes('uniqueEmailsCollection')) {
  code = code.replace(
    '  signupAbuseCollection,',
    '  signupAbuseCollection,\n  uniqueEmailsCollection,\n  uniqueUsernamesCollection,'
  );
}

fs.writeFileSync('server.ts', code);
console.log('patched server.ts imports');
