const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'import { usersCollection, projectsCollection, promoCodesCollection, verificationCodesCollection, passwordResetsCollection, UserRecord, ProjectRecord, simulationsCollection, firestoreDb, VerificationRecord, PasswordResetRecord, PromoCodeRecord, SimulationRecord } from "./server/db";',
  'import { usersCollection, projectsCollection, promoCodesCollection, verificationCodesCollection, passwordResetsCollection, UserRecord, ProjectRecord, simulationsCollection, firestoreDb, VerificationRecord, PasswordResetRecord, PromoCodeRecord, SimulationRecord, signupAbuseCollection, uniqueEmailsCollection, uniqueUsernamesCollection } from "./server/db";'
);

// fix user redeclare in login
code = code.replace(
  /const user = userQuery\.docs\[0\]\.data\(\) as UserRecord;\n  if \(\!timingSafeStringEqual\(user\.passwordHash, hashCode\(password\)\)\) \{/g,
  `const loggedInUser = userQuery.docs[0].data() as UserRecord;
  if (!timingSafeStringEqual(loggedInUser.passwordHash, hashCode(password))) {`
);

code = code.replace(
  /setSessionCookie\(res, loggedInUser\.uid, \!\!rememberMe\);\n  res\.json\(\{ success: true, user: sanitizeUser\(user\) \}\);/,
  `setSessionCookie(res, loggedInUser.uid, !!rememberMe);
  res.json({ success: true, user: sanitizeUser(loggedInUser) });`
);

// The actual error is around line 429 and 446.
// Let's just blindly rename "user" to "loginUser" in the login route to avoid conflicts
// Actually, I can use a regex to replace the specific instance in the login route.

fs.writeFileSync('server.ts', code);
console.log('patched imports');
