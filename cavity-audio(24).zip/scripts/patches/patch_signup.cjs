const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

// 1. We will create two new collections: uniqueEmails and uniqueUsernames.
// In server/db.ts:
// export const uniqueEmailsCollection = lazyCollection("uniqueEmails");
// export const uniqueUsernamesCollection = lazyCollection("uniqueUsernames");

code = code.replace(
  'app.post("/api/auth/signup", async (req: any, res: any) => {',
  `app.post("/api/auth/signup", async (req: any, res: any) => {
  const { firstName, lastName, username, email, password } = req.body;
  if (!firstName || !lastName || !username || !email || !password) {
    return res.status(400).json({ error: "All fields are required." });
  }
  if (!USERNAME_RE.test(username)) {
    return res.status(400).json({ error: "Username must be 6-20 characters (letters, numbers, underscores)." });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters." });
  }

  const emailLower = String(email).toLowerCase().trim();
  const usernameLower = String(username).toLowerCase().trim();
  `
);

// Now we need to remove the original validation and rate limit logic.
// We will replace the middle block.
const origMiddle = `  const ipStatus = await checkAndRecordSignup(req.ip || req.connection?.remoteAddress);
  if (!ipStatus.allowed) {
    if (ipStatus.permanent) {
      return res.status(429).json({ error: "Too many signups from this IP. Permanent ban." });
    } else {
      return res.status(429).json({ error: \`Too many signups from this IP. Try again in \${Math.ceil(ipStatus.waitMs / 60000)} minute(s).\` });
    }
  }

  const { firstName, lastName, username, email, password } = req.body;
  if (!firstName || !lastName || !username || !email || !password) {
    return res.status(400).json({ error: "All fields are required." });
  }
  if (!USERNAME_RE.test(username)) {
    return res.status(400).json({ error: "Username must be 6-20 characters (letters, numbers, underscores)." });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters." });
  }

  const emailLower = String(email).toLowerCase().trim();
  const usernameLower = String(username).toLowerCase().trim();

  const userQuery = await usersCollection.where("emailLower", "==", emailLower).limit(1).get();
  if (!userQuery.empty) {
    return res.status(400).json({ error: "Email is already registered." });
  }
  const usernameQuery = await usersCollection.where("usernameLower", "==", usernameLower).limit(1).get();
  if (!usernameQuery.empty) {
    return res.status(400).json({ error: "Username is taken." });
  }

  const uid = crypto.randomUUID();`;

const newMiddle = `  const ipStatus = await checkAndRecordSignup(req.ip || req.connection?.remoteAddress);
  if (!ipStatus.allowed) {
    if (ipStatus.permanent) {
      return res.status(429).json({ error: "Too many signups from this IP. Permanent ban." });
    } else {
      return res.status(429).json({ error: \`Too many signups from this IP. Try again in \${Math.ceil(ipStatus.waitMs / 60000)} minute(s).\` });
    }
  }

  const uid = crypto.randomUUID();
  try {
    await firestoreDb.runTransaction(async (t) => {
      const emailRef = uniqueEmailsCollection.doc(emailLower);
      const usernameRef = uniqueUsernamesCollection.doc(usernameLower);
      
      const [emailDoc, usernameDoc] = await Promise.all([t.get(emailRef), t.get(usernameRef)]);
      if (emailDoc.exists) throw new Error("Email is already registered.");
      if (usernameDoc.exists) throw new Error("Username is taken.");
      
      t.set(emailRef, { uid });
      t.set(usernameRef, { uid });
      
      const userRef = usersCollection.doc(uid);
      const user: UserRecord = {
        uid,
        firstName: String(firstName).trim(),
        lastName: String(lastName).trim(),
        username: String(username).trim(),
        usernameLower,
        email: String(email).trim(),
        emailLower,
        passwordHash: hashCode(password), // using existing hashCode pattern to avoid breaking old users
        emailVerified: false,
        createdAt: Date.now(),
        subscriptionStatus: "free",
        trialStartsAt: 0,
        trialEndsAt: 0,
        role: "user"
      };
      
      t.set(userRef, user);
    });
  } catch (err: any) {
    if (err.message === "Email is already registered." || err.message === "Username is taken.") {
      return res.status(400).json({ error: err.message });
    }
    console.error("Signup transaction error:", err);
    return res.status(500).json({ error: "Service unavailable." });
  }

  const user: UserRecord = {
    uid,
    firstName: String(firstName).trim(),
    lastName: String(lastName).trim(),
    username: String(username).trim(),
    usernameLower,
    email: String(email).trim(),
    emailLower,
    passwordHash: hashCode(password),
    emailVerified: false,
    createdAt: Date.now(),
    subscriptionStatus: "free",
    trialStartsAt: 0,
    trialEndsAt: 0,
    role: "user"
  };
`;

code = code.replace(origMiddle, newMiddle);
fs.writeFileSync('server.ts', code);
console.log('patched server.ts signup atomicity');
