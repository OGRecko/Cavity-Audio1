const fs = require('fs');
let pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
pkg.scripts.build = "vite build && esbuild server.ts --bundle --platform=node --format=cjs --packages=external --sourcemap --outfile=dist/server.cjs && esbuild server/solverWorker.ts --bundle --platform=node --format=cjs --packages=external --sourcemap --outfile=dist/solverWorker.cjs";
fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2));
console.log('patched package.json');
