const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

// 1. Fix the double user declaration
code = code.replace(
  `  const user: UserRecord = {
    uid,
    firstName: String(firstName).trim(),
    lastName: String(lastName).trim(),
    username: String(username).trim(),
    usernameLower,
    email: String(email).trim(),
    emailLower,
    passwordHash: hashCode(password),
    emailVerified: false,
    createdAt: Date.now(),
    subscriptionStatus: "free",
    trialStartsAt: 0,
    trialEndsAt: 0,
    role: "user"
  };

  const code = String(Math.floor(100000 + Math.random() * 900000));
  await usersCollection.doc(uid).set(user);`,
  `  const codeStr = String(Math.floor(100000 + Math.random() * 900000));`
);

// 2. We need to define `user` to use it below for `sanitizeUser(user)`
code = code.replace(
  `  const codeStr = String(Math.floor(100000 + Math.random() * 900000));`,
  `  const user: UserRecord = {
    uid,
    firstName: String(firstName).trim(),
    lastName: String(lastName).trim(),
    username: String(username).trim(),
    usernameLower,
    email: String(email).trim(),
    emailLower,
    passwordHash: hashCode(password),
    emailVerified: false,
    createdAt: Date.now(),
    subscriptionStatus: "free",
    trialStartsAt: 0,
    trialEndsAt: 0,
    role: "user"
  };
  const codeStr = String(Math.floor(100000 + Math.random() * 900000));`
);

code = code.replace(
  /const \[emailDoc, usernameDoc\] = await Promise\.all\(\[t\.get\(emailRef\), t\.get\(usernameRef\)]\);/,
  `const emailDoc = await t.get(emailRef as any) as any;
      const usernameDoc = await t.get(usernameRef as any) as any;`
);

// wait, the code string was originally called `code`. Let's fix that.
code = code.replace(/codeStr/g, 'code');

fs.writeFileSync('server.ts', code);
console.log('patched signup fixes');
