const fs = require('fs');

let worker = fs.readFileSync('server/solverWorker.ts', 'utf8');

worker = worker.replace(/return res\.status\(422\)\.json\(\{([\s\S]*?)\}\);/g, (match, body) => {
  return `throw new Error(JSON.stringify({${body}}));`;
});

// Remove fire and forget save entirely
worker = worker.replace(/simulationsCollection\.doc\([\s\S]*?\.catch\(e => console\.error\("Failed to save simulation", e\)\);/, '');
worker = worker.replace(/const simulationId = crypto\.randomUUID\(\);/, '');
worker = worker.replace(/simulationId,/g, '');

// Fix 'req' usages
worker = worker.replace(/req\.user\.uid/g, 'payload.userId');
worker = worker.replace(/req\.body/g, 'payload');

fs.writeFileSync('server/solverWorker.ts', worker);
console.log('cleaned worker');
