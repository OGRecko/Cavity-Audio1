const fs = require('fs');

let storeSrc = fs.readFileSync('src/store/useProjectsStore.ts', 'utf8');

const saveStr = `  saveCurrentProject: async () => {
    const id = get().activeProjectId;
    if (!id) return; // nothing to save into yet (e.g. legacy-only user who hasn't created/migrated a project)
    
    const projectRecord = get().projects.find(p => p.id === id);
    const updatedAt = projectRecord ? projectRecord.updatedAt : undefined;

    try {
      const res = await fetch(\`/api/projects/\${id}\`, {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: extractProjectData(), updatedAt }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Failed to save project.');
      }
      const data = await res.json();
      set(state => ({
        projects: state.projects.map(p => 
          p.id === id ? { ...p, updatedAt: data.project.updatedAt } : p
        )
      }));
    } catch (e: any) {
      set({ error: e.message || 'Failed to autosave. Changes may be lost.' });
    }
  },`;

storeSrc = storeSrc.replace(/saveCurrentProject: async \(\) => \{[\s\S]*?body: JSON\.stringify\(\{ data: extractProjectData\(\) \}\),\n      \}\);\n    \} catch \{\n      \/\/ Best-effort autosave; a failed save here shouldn't block navigation\.\n    \}\n  \},/, saveStr);

fs.writeFileSync('src/store/useProjectsStore.ts', storeSrc);
console.log('patched store concurrency');
