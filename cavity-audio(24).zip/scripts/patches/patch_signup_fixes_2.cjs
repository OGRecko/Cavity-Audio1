const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const regex = /  const user: UserRecord = \{\n    uid,\n    firstName: String\(firstName\)\.trim\(\),\n    lastName: String\(lastName\)\.trim\(\),\n    username: String\(username\)\.trim\(\),\n    usernameLower,\n    email: String\(email\)\.trim\(\),\n    emailLower,\n    passwordHash: hashCode\(password\),\n    emailVerified: false,\n    createdAt: Date\.now\(\),\n    subscriptionStatus: "free",\n    trialStartsAt: 0,\n    trialEndsAt: 0,\n    role: "user"\n  \};\n/g;

let matches = 0;
code = code.replace(regex, (match) => {
  matches++;
  if (matches === 1) {
    return ''; // remove the first one
  }
  return match; // keep the second one
});

fs.writeFileSync('server.ts', code);
console.log('patched double user');
