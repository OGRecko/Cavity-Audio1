const fs = require('fs');
let serverSrc = fs.readFileSync('server.ts', 'utf8');

const getList = `app.get("/api/projects", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const user = req.user as UserRecord;
  try {
    const snap = await projectsCollection
      .where("ownerId", "==", uid)
      .where("archived", "==", false)
      .get();
      
    const projects = snap.docs.map(d => {
      const p = d.data();
      // Omit heavy data payload for list view to save bandwidth
      const { data, ...metadata } = p;
      return metadata;
    });
    
    // Auto-fix activeProjectId if it's dangling
    let activeId = user.activeProjectId;
    if (activeId && !projects.find(p => p.id === activeId)) {
      activeId = null;
      await usersCollection.doc(uid).update({ activeProjectId: null }).catch(() => {});
    }
    
    res.json({ projects, activeProjectId: activeId });
  } catch (err: any) {
    console.error("GET /api/projects error:", err);
    res.status(500).json({ error: "Service unavailable." });
  }
});`;

serverSrc = serverSrc.replace(/app\.get\("\/api\/projects", authMiddleware, async \(req: any, res: any\) => \{[\s\S]*?res\.json\(\{ projects, activeProjectId: activeId \}\);\n\}\);/, getList);

const getSingle = `app.get("/api/projects/:id", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  try {
    const doc = await projectsCollection.doc(req.params.id).get();
    
    if (!doc.exists) return res.status(404).json({ error: "Project not found." });
    const project = doc.data() as ProjectRecord;
    if (project.ownerId !== uid || project.archived) return res.status(404).json({ error: "Project not found." });
    
    res.json({ project });
  } catch (err: any) {
    console.error("GET /api/projects/:id error:", err);
    res.status(500).json({ error: "Service unavailable." });
  }
});`;

serverSrc = serverSrc.replace(/app\.get\("\/api\/projects\/:id", authMiddleware, async \(req: any, res: any\) => \{[\s\S]*?res\.json\(\{ project \}\);\n\}\);/, getSingle);

fs.writeFileSync('server.ts', serverSrc);
console.log('patched GET projects');
