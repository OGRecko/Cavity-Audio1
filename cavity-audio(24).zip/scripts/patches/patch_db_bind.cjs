const fs = require('fs');
let code = fs.readFileSync('server/db.ts', 'utf8');

const replacement = `const lazyCollection = (name: string) => new Proxy({}, {
  get: (target, prop) => {
    const col = firestoreDb.collection(name);
    const value = col[prop as keyof typeof col];
    if (typeof value === 'function') {
      return value.bind(col);
    }
    return value;
  }
}) as unknown as FirebaseFirestore.CollectionReference<FirebaseFirestore.DocumentData>;`;

code = code.replace(/const lazyCollection = \([^]*?\)\s*as unknown as FirebaseFirestore\.CollectionReference<FirebaseFirestore\.DocumentData>;/, replacement);
fs.writeFileSync('server/db.ts', code);
