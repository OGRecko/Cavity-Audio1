const fs = require('fs');
let code = fs.readFileSync('server/db.ts', 'utf8');

if (!code.includes('uniqueEmailsCollection')) {
  code = code.replace(
    'export const promoCodesCollection = lazyCollection("promoCodes");',
    'export const promoCodesCollection = lazyCollection("promoCodes");\nexport const uniqueEmailsCollection = lazyCollection("uniqueEmails");\nexport const uniqueUsernamesCollection = lazyCollection("uniqueUsernames");'
  );
}

// Also add role to UserRecord
if (!code.includes('role?: string;')) {
  code = code.replace(
    'activeProjectId?: string;',
    'activeProjectId?: string;\n  role?: string;'
  );
}

fs.writeFileSync('server/db.ts', code);
console.log('patched db.ts');
