const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const adminRoute = `
async function adminMiddleware(req: any, res: any, next: any) {
  if (!req.user || req.user.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Admins only." });
  }
  next();
}

app.post("/api/admin/signup-abuse/:ip/unban", authMiddleware, adminMiddleware, async (req: any, res: any) => {
  const ip = req.params.ip;
  if (!ip) return res.status(400).json({ error: "IP is required." });
  try {
    const ref = signupAbuseCollection.doc(ip);
    await ref.delete();
    res.json({ success: true, message: \`IP \${ip} unbanned.\` });
  } catch(e) {
    console.error("Admin unban error:", e);
    res.status(500).json({ error: "Service unavailable." });
  }
});
`;

code = code.replace(
  '// Heavy-compute guard for the FDTD solver endpoints',
  adminRoute + '\n// Heavy-compute guard for the FDTD solver endpoints'
);

fs.writeFileSync('server.ts', code);
console.log('patched admin route');
