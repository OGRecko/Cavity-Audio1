const fs = require('fs');

let serverSrc = fs.readFileSync('server.ts', 'utf8');

// Fix PUT projects/:id
serverSrc = serverSrc.replace(
  /catch \(e: any\) \{\n    if \(e\.message\.startsWith\("Conflict"\)\) \{\n      return res\.status\(409\)\.json\(\{ error: "This project has been modified in another session\. Please reload\." \}\);\n    \}\n    res\.status\(404\)\.json\(\{ error: "Project not found\." \}\);\n  \}/,
  `catch (e: any) {
    if (e.message === "Not found") {
      return res.status(404).json({ error: "Project not found." });
    }
    if (e.message.startsWith("Conflict")) {
      return res.status(409).json({ error: "This project has been modified in another session. Please reload." });
    }
    console.error("PUT project error:", e);
    res.status(500).json({ error: "Service unavailable." });
  }`
);

// Fix POST projects/:id/archive
serverSrc = serverSrc.replace(
  /\} catch \(e\) \{\n    res\.status\(404\)\.json\(\{ error: "Project not found\." \}\);\n  \}/g,
  `} catch (e: any) {
    if (e.message === "Not found") {
      return res.status(404).json({ error: "Project not found." });
    }
    console.error("Project op error:", e);
    res.status(500).json({ error: "Service unavailable." });
  }`
);

fs.writeFileSync('server.ts', serverSrc);
console.log('patched db error handling');
