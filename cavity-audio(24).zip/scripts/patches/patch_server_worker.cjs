const fs = require('fs');

let serverSrc = fs.readFileSync('server.ts', 'utf8');

const workerCall = `
import { Worker } from "worker_threads";

function runSolverWorker(type: string, payload: any): Promise<any> {
  return new Promise((resolve, reject) => {
    const isProd = process.env.NODE_ENV === 'production';
    const workerPath = isProd 
      ? path.join(process.cwd(), 'dist', 'solverWorker.cjs') 
      : path.join(process.cwd(), 'server', 'solverWorker.ts');
      
    const workerOptions: any = { workerData: { type, payload } };
    
    if (!isProd) {
      workerOptions.execArgv = ['--import', 'tsx']; 
    }

    const worker = new Worker(workerPath, workerOptions);
    
    worker.on('message', (msg) => {
      if (msg.success) resolve(msg.data);
      else reject(new Error(msg.error));
    });
    
    worker.on('error', reject);
    worker.on('exit', (code) => {
      if (code !== 0) reject(new Error(\`Worker stopped with exit code \${code}\`));
    });
  });
}
`;

serverSrc = serverSrc.replace('import { createServer as createViteServer } from "vite";', workerCall + '\nimport { createServer as createViteServer } from "vite";');

function replaceRouteBody(source, routeMatch, newBody) {
  let lines = source.split('\n');
  let start = lines.findIndex(l => l.includes(routeMatch));
  if (start === -1) return source;
  
  let end = -1;
  let braceCount = 0;
  let started = false;
  
  for (let i = start; i < lines.length; i++) {
    const line = lines[i];
    if (!started && line.includes('{')) {
      started = true;
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      continue;
    }
    if (started) {
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        end = i;
        break;
      }
    }
  }
  
  const before = lines.slice(0, start + 1).join('\n');
  const after = lines.slice(end).join('\n');
  
  return before + '\n' + newBody + '\n' + after;
}

const waveBody = `
  const payload = { ...req.body, userPlan: req.user.plan, userId: req.user.uid };
  try {
    const data = await runSolverWorker('wave', payload);
    
    // Fire and forget save
    const simulationId = crypto.randomUUID();
    const resultObj = {
      rt60: data.rt60,
      simulatedRt60: data.simulatedRt60,
      gridDims: data.gridDims,
      steps: data.steps,
    };
    simulationsCollection.doc(simulationId).set({
      simulationId,
      ownerId: req.user.uid,
      projectId: req.body.projectId || "unknown",
      createdAt: Date.now(),
      status: "completed",
      room: req.body,
      speakers: [req.body.source],
      receivers: [req.body.receiver],
      result: resultObj
    }).catch(e => console.error("Failed to save simulation", e));
    
    data.simulationId = simulationId;
    return res.json(data);
  } catch (err: any) {
    console.error("Wave Solver Error:", err);
    try {
      const parsed = JSON.parse(err.message);
      return res.status(422).json(parsed);
    } catch {
      return res.status(500).json({ error: err.message || "Wave computation failed." });
    }
  }
`;

const irBody = `
  const payload = { ...req.body, userPlan: req.user.plan, userId: req.user.uid };
  try {
    const data = await runSolverWorker('impulse-response', payload);
    return res.json(data);
  } catch (err: any) {
    console.error("Impulse Response Solver Error:", err);
    try {
      const parsed = JSON.parse(err.message);
      return res.status(422).json(parsed);
    } catch {
      return res.status(500).json({ error: err.message || "Impulse response computation failed." });
    }
  }
`;

serverSrc = replaceRouteBody(serverSrc, 'app.post("/api/solver/wave"', waveBody);
serverSrc = replaceRouteBody(serverSrc, 'app.post("/api/solver/impulse-response"', irBody);

fs.writeFileSync('server.ts', serverSrc);
console.log('patched server.ts with worker calls');
