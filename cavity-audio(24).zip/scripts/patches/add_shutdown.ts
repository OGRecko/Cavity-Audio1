import fs from 'fs';

let serverTs = fs.readFileSync('server.ts', 'utf8');

const shutdownCode = `
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(\`Server running on http://localhost:\${PORT}\`);
  });

  const gracefulShutdown = (signal: string) => {
    console.log(\`Received \${signal}. Shutting down gracefully...\`);
    server.close(() => {
      console.log('HTTP server closed.');
      process.exit(0);
    });
    
    // Force close after 10s
    setTimeout(() => {
      console.error('Could not close connections in time, forcefully shutting down');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
`;

serverTs = serverTs.replace(/app\.listen\(PORT, "0\.0\.0\.0", \(\) => \{\n    console\.log\(\`Server running on http:\/\/localhost:\$\{PORT\}\`\);\n  \}\);/g, shutdownCode);

fs.writeFileSync('server.ts', serverTs);
console.log('Added graceful shutdown');
