const fs = require('fs');

const waveSrc = fs.readFileSync('/tmp/wave.txt', 'utf8');
const irSrc = fs.readFileSync('/tmp/ir.txt', 'utf8');

function extractRouteBody(source) {
  let lines = source.split('\n');
  let start = lines.findIndex(l => l.includes('app.post("'));
  let end = -1;
  let braceCount = 0;
  let started = false;
  
  for (let i = start; i < lines.length; i++) {
    const line = lines[i];
    if (!started && line.includes('{')) {
      started = true;
      // count braces on the first line
      let idx = line.indexOf('{');
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      continue;
    }
    if (started) {
      braceCount += (line.match(/\{/g) || []).length;
      braceCount -= (line.match(/\}/g) || []).length;
      if (braceCount === 0) {
        end = i;
        break;
      }
    }
  }
  
  let bodyLines = lines.slice(start + 1, end);
  return bodyLines.join('\n');
}

let waveBody = extractRouteBody(waveSrc);
let irBody = extractRouteBody(irSrc);

[waveBody, irBody] = [waveBody, irBody].map(body => {
  let res = body;
  res = res.replace(/req\.body/g, 'payload');
  res = res.replace(/req\.user\.plan/g, 'payload.userPlan');
  res = res.replace(/return res\.status\(400\)\.json\(\{ error: (.*?) \}\);/g, 'throw new Error($1);');
  res = res.replace(/res\.json\(([\s\S]*?)\);/g, 'return $1;');
  res = res.replace(/res\.status\(500\)\.json\(\{ error: (.*?) \}\);/g, 'throw new Error($1);');
  return res;
});

let worker = `import { parentPort, workerData } from 'worker_threads';

function clamp01(v: number) { return Math.max(0, Math.min(1, v)); }
function parseFiniteInRange(val: any, min: number, max: number, nameOrDef: any): number {
  const num = Number(val);
  if (Number.isFinite(num) && num >= min && num <= max) return num;
  if (typeof nameOrDef === "string") throw new Error(nameOrDef + " is invalid");
  return nameOrDef;
}

import { getAbsorption } from "../src/lib/absorption";
function getAbsorptionAt500Hz(materialId: string): number {
  return getAbsorption(materialId).hz500;
}

try {
  const { type, payload } = workerData;
  if (type === 'wave') {
    const result = runWave(payload);
    parentPort?.postMessage({ success: true, data: result });
  } else if (type === 'impulse-response') {
    const result = runIR(payload);
    parentPort?.postMessage({ success: true, data: result });
  } else {
    throw new Error("Unknown solver type");
  }
} catch (err: any) {
  parentPort?.postMessage({ success: false, error: err.message || String(err) });
}

function runWave(payload: any) {
${waveBody}
}

function runIR(payload: any) {
${irBody}
}
`;

fs.writeFileSync('server/solverWorker.ts', worker);
console.log('patched solver worker accurately');
