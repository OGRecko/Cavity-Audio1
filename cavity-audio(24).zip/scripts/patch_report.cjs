const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'import { generateProjectReport } from "./server/reportGenerator";',
  'import { generateProjectReport as generateAcousticReport } from "./server/reportGenerator";'
);

fs.writeFileSync('server.ts', code);
console.log('patched report import');
