const fs = require('fs');
let code = fs.readFileSync('src/store/useProjectsStore.ts', 'utf8');

const targetStr = `function extractProjectData() {
  const s = useStore.getState();
  return {
    schemaVersion: 1,
    appVersion: "1.0.0",
    roomName: s.roomName,
    poly: s.poly,
    L: s.L, W: s.W, H: s.H,
    wallMaterial: s.wallMaterial,
    wallSegMats: s.wallSegMats,
    wallOpenings: s.wallOpenings,
    floorMaterial: s.floorMaterial,
    ceilMaterial: s.ceilMaterial,
    scatter: s.scatter,
    sources: s.sources,
    receivers: s.receivers,
    simulations: s.simulations,
  };
};
}`;

const replaceStr = `function extractProjectData() {
  const s = useStore.getState();
  return {
    schemaVersion: 1,
    appVersion: "1.0.0",
    roomName: s.roomName,
    poly: s.poly,
    L: s.L, W: s.W, H: s.H,
    wallMaterial: s.wallMaterial,
    wallSegMats: s.wallSegMats,
    wallOpenings: s.wallOpenings,
    floorMaterial: s.floorMaterial,
    ceilMaterial: s.ceilMaterial,
    scatter: s.scatter,
    sources: s.sources,
    receivers: s.receivers,
    simulations: s.simulations,
  };
}`;

code = code.replace(targetStr, replaceStr);
fs.writeFileSync('src/store/useProjectsStore.ts', code);
