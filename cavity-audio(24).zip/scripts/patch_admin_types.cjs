const fs = require('fs');
let code = fs.readFileSync('server/firebase-admin.ts', 'utf8');

code = code.replace(
  'export const adminDb = new Proxy({}, {',
  'export const adminDb = new Proxy({}, {\n  get: (target, prop) => {\n    return getAdminDb()[prop];\n  }\n}) as FirebaseFirestore.Firestore;'
);

code = code.replace(
  '// For backward compatibility',
  'import type * as FirebaseFirestore from "@google-cloud/firestore";\n// For backward compatibility'
);

fs.writeFileSync('server/firebase-admin.ts', code);
console.log('patched types');
