const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  /const resultObj = {\s*rt60: sabineRt60,\s*simulatedRt60,\s*gridDims: \[nx, ny, nz\],\s*steps: numSteps,\s*targetDurationSec,\s*actualDurationSec,\s*warning: reachedTarget \? null : "Simulation capped early",\s*};/,
  `const resultObj = {
      rt60: sabineRt60,
      simulatedRt60,
      gridDims: [nx, ny, nz],
      steps: numSteps,
    };`
);

fs.writeFileSync('server.ts', code);
console.log('patched wave');
