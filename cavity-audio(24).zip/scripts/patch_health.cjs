const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  'app.use(cookieParser());',
  `app.use(cookieParser());\napp.get("/api/health", (req, res) => res.json({ status: "ok" }));`
);

fs.writeFileSync('server.ts', code);
console.log('patched health');
