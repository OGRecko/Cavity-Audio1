const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');
code = code.replace(
  'import { usersCollection, projectsCollection, promoCodesCollection, verificationCodesCollection, passwordResetsCollection, UserRecord, ProjectRecord, simulationsCollection } from "./server/db";',
  'import { usersCollection, projectsCollection, promoCodesCollection, verificationCodesCollection, passwordResetsCollection, UserRecord, ProjectRecord, simulationsCollection, firestoreDb, VerificationRecord, PasswordResetRecord, PromoCodeRecord, SimulationRecord } from "./server/db";'
);
fs.writeFileSync('server.ts', code);
console.log('patched imports');
