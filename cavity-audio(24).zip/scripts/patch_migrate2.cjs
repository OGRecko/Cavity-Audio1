const fs = require('fs');
let code = fs.readFileSync('scripts/migrateDb.ts', 'utf8');

code = code.replace(
  'for (const [uid, user] of Object.entries(dbShape.users)) {',
  'for (const [uid, userEntry] of Object.entries(dbShape.users)) { const user = userEntry as any;'
);

fs.writeFileSync('scripts/migrateDb.ts', code);
console.log('patched migrate2');
