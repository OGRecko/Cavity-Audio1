const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  /const session = await polar\.checkouts\.create\(\{\s*productOptions: \[\{ productId: priceId \}\],\s*customerOptions: \{ customerEmail: email \},\s*successUrl: `\$\{req\.headers\.origin\}\/\?checkout=success`,\s*metadata: \{ userId: user\.uid \}\s*\}\);/,
  `const session = await polar.checkouts.create({
      productId: priceId,
      customerEmail: email,
      successUrl: \`\${req.headers.origin}/?checkout=success\`,
      metadata: { userId: user.uid }
    } as any);`
);

fs.writeFileSync('server.ts', code);
console.log('patched checkout');
