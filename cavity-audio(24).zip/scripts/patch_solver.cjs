const fs = require('fs');
let code = fs.readFileSync('server_routes_4.ts', 'utf-8');

code = code.replace(
`    res.json({
      success: true,
      meshSize: N,`,
`    const simulationId = crypto.randomUUID();
    const resultObj = {
      rt60: sabineRt60,
      simulatedRt60,
      gridDims: [nx, ny, nz],
      steps: numSteps,
      targetDurationSec,
      actualDurationSec,
      warning: reachedTarget ? null : "Simulation capped early",
    };
    
    // Fire and forget save
    simulationsCollection.doc(simulationId).set({
      simulationId,
      ownerId: req.user.uid,
      projectId: req.body.projectId || "unknown",
      createdAt: Date.now(),
      status: "completed",
      room: req.body,
      speakers: [source],
      receivers: [receiver],
      result: resultObj
    }).catch(e => console.error("Failed to save simulation", e));

    res.json({
      success: true,
      simulationId,
      meshSize: N,`
);
fs.writeFileSync('server_routes_4.ts', code);
