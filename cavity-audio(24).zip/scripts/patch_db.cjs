const fs = require('fs');
let code = fs.readFileSync('server/db.ts', 'utf8');

code = code.replace(
  'import { adminDb as firestoreDb } from "./firebase-admin";',
  'import { adminDb } from "./firebase-admin";\nexport const firestoreDb = adminDb;'
);

fs.writeFileSync('server/db.ts', code);
console.log('patched db.ts');
