const fs = require('fs');

// 1. Add FIREBASE_SERVICE_ACCOUNT to .env.example
let env = fs.readFileSync('.env.example', 'utf8');
if (!env.includes('FIREBASE_SERVICE_ACCOUNT')) {
  env += '\n# Firebase Admin SDK Service Account JSON\nFIREBASE_SERVICE_ACCOUNT=""\n';
  fs.writeFileSync('.env.example', env);
}

// 2. Patch firebase-admin.ts
const adminCode = `import { initializeApp, cert, getApps } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import firebaseConfig from '../firebase-applet-config.json';

let adminDbInstance = null;

export const getAdminDb = () => {
  if (adminDbInstance) return adminDbInstance;

  if (getApps().length === 0) {
    if (!process.env.FIREBASE_SERVICE_ACCOUNT) {
      throw new Error("FIREBASE_SERVICE_ACCOUNT environment variable is missing. Please generate a Firebase Service Account JSON from your Firebase console and add it to the Secrets menu.");
    }
    try {
      initializeApp({ 
        credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)), 
        projectId: firebaseConfig.projectId 
      });
    } catch(e) {
      console.error("Failed to initialize Firebase Admin:", e);
      throw e;
    }
  }

  const dbId = process.env.FIRESTORE_DATABASE_ID || firebaseConfig.firestoreDatabaseId;
  adminDbInstance = getFirestore(dbId);
  return adminDbInstance;
};

// For backward compatibility (Proxy to evaluate lazily)
export const adminDb = new Proxy({}, {
  get: (target, prop) => {
    return getAdminDb()[prop];
  }
});
`;

fs.writeFileSync('server/firebase-admin.ts', adminCode);
console.log('patched firebase-admin.ts and .env.example');
