const fs = require('fs');
let code = fs.readFileSync('src/store/useProjectsStore.ts', 'utf8');

code = code.replace(
  `  };
};}`,
  `  };
}`
);

fs.writeFileSync('src/store/useProjectsStore.ts', code);
