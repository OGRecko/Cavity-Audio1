# Cavity Audio — Fixes Applied

This package is a hardened revision of `cavity-audio(10)`.

## Fixed

- Production email verification no longer auto-verifies accounts when SMTP is missing or fails.
- Added an explicit development-only `ALLOW_DEV_EMAIL_BYPASS=true` switch.
- Session cookies now use `SameSite=Lax`, `HttpOnly`, `/` path, and production-only `Secure`.
- Polar webhooks now refuse unrecognized product IDs instead of silently assigning the standard plan.
- Firestore write failures now propagate instead of returning apparent success after persistence failure.
- FDTD room dimensions, `fmax`, accuracy mode, and step count are validated server-side.
- Final FDTD grid is checked against the actual server element cap after rounding.
- Reported FDTD `actualFmax` is calculated from the final actual cell size.
- Corrected the required FDTD grid axis mapping for L/H/W.
- Removed fabricated numeric legacy speaker defaults from normalized speaker records; DSP fallbacks remain explicitly generic.
- Corrected sensitivity-source mapping so estimates are not mislabeled as measurements.
- Reclassified legacy sensitivity values as `LEGACY` instead of manufacturer-verified.
- Corrected Jensen P10R official 8-ohm values: 94.2 dB, 25 W, Fs 97 Hz.
- Corrected Jensen P12N official 8-ohm values: 97.5 dB, 50 W, Fs 90 Hz.
- Added official Jensen specification-sheet URLs to those corrected records' notes.
- Regenerated the speaker audit report with field-level status counts.
- Updated stale tier-limit and report provenance comments.
- Updated client-side solver budget hints to match server caps.

## Verification performed in this environment

- Speaker JSON parses successfully.
- 356 speaker records present.
- Duplicate IDs: 0.
- Duplicate brand/model pairs: 0.
- Changed TypeScript/TSX files pass TypeScript transpile/syntax parsing.
- Full `npm run lint` was attempted but could not complete because dependency installation timed out and the environment lacks the complete `node_modules` tree. Therefore a full production build is **not claimed as passed** here.
