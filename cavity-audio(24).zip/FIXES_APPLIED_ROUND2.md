# Cavity Audio — Round 2 Fixes

Static-review fixes applied on top of `cavity-audio-fixed-final`. No build/
typecheck was run (no network access to install node_modules in this
environment) — these are code-read fixes with a documented reason each.

## Fixed

1. **`server/db.ts` — cache poisoned on failed write.**
   `writeDb()` set `cachedDb = state` *before* attempting the Firestore
   write. If the write then failed, the function correctly threw an error —
   but the in-memory cache had already been overwritten with the unsaved
   state. Every subsequent `readDb()` in that process would silently return
   that phantom, never-persisted data as if it had been saved, directly
   defeating the "never report success when persistence failed" fix from
   the previous round. Fixed by only updating `cachedDb` after `setDoc`
   succeeds.

2. **`server.ts` `/api/auth/resend-code` — dev-bypass path treated as an
   error.** `sendVerificationEmail()` intentionally returns `false` (not a
   thrown error) when SMTP is unconfigured and the explicit
   `ALLOW_DEV_EMAIL_BYPASS` switch is on — the code is generated and logged
   instead of emailed. `resend-code` treated any `false` return as a hard
   500, breaking the documented dev flow. `forgot-password` already handled
   this correctly (`if (!emailSent && mailTransporter)`); `resend-code` now
   matches that pattern.

3. **`server.ts` `/api/solver/wave` and `/api/solver/impulse-response` —
   unhandled throws before the `try` block.** Both endpoints validated the
   computed source/receiver grid positions with bare `throw new Error(...)`
   statements positioned *before* the route's `try { ... } catch` began.
   An out-of-bounds source or receiver position (e.g. from malformed
   client input) would therefore produce an unhandled exception — Express's
   default error path — instead of the clean `{ error: "..." }` JSON
   response the `catch` block exists to produce for every other failure in
   these routes. Moved the validation inside the `try` block so these
   failures are handled the same way as everything else in the route.

## Round 3 — acoustics/DSP layer

4. **`src/lib/sti.ts` — STI silently understated when bands are skipped.**
   `computeRealSTI` divided the summed per-band transmission index by the
   *fixed* `BANDS_USED_IN_COMBINATION.length`, even though its own Nyquist
   guard (`if (centerHz >= sampleRateHz / 2) continue`) can skip bands at
   low sample rates. A skipped band contributed 0 to the sum but the
   divisor never shrank to match, so the combined STI was silently pulled
   down — exactly the "missing key ≠ zero energy" mistake
   `octaveFilter.ts`'s own contract explicitly warns callers against, which
   the equivalent per-band C50/C80/D50/Ts code in
   `impulseResponseParams.ts` already avoided correctly. Fixed by dividing
   by the count of bands actually resolved.

5. **`src/lib/speakerDSP.ts` — `year: number` fed a nullable value.**
   `SpeakerSpec.year` is typed `number | null` (legacy entries explicitly
   set it to `null`), but `makeSaturationCurve(power_w, year)` declared
   `year: number` and both call sites pass `spec.year` straight through.
   `null - 1950` coerces to `-1950`, which happens to clamp into a
   plausible-looking "old/soft knee" value by accident of numeric
   coercion — not a real default. Also a genuine `tsc` type error given
   the declared types. Fixed the signature to accept `number | null` and
   used an explicit neutral mid-era default when year is unknown, instead
   of relying on coercion.

6. **`src/lib/speakers.ts` — legacy sensitivity mislabeled as "unavailable."**
   80 legacy speaker entries have a real, non-null `sensitivity.value` (a
   plain number carried over from the old flat list) but
   `sensitivity.sourceType: 'NONE'` (their status is `'LEGACY'`, not backed
   by a manufacturer/measurement/estimate source). `SPEAKERS`'s
   `sensitivitySource` derivation only checked `sourceType`, so these fell
   through to `'unavailable'` while `manufacturerSensitivityDb` on the same
   object was simultaneously populated with the real number — self-
   contradictory (a value whose source is "unavailable"). This export
   isn't on the currently-used path (`sensitivityStatus`, which is correct,
   is what the UI actually reads) but is still misleading to anyone
   consuming it. Fixed by checking `status === 'LEGACY'` first.

7. **`src/lib/audioEngine.ts` — real-time RT60 preview used a different,
   disagreeing absorption table than the rest of the app.** The live audio
   engine's Sabine RT60 approximation imported `getAbsorption` from
   `materials.ts` (a separate, independently-maintained flat single-value
   table), while `roomAcoustics.ts` (RT60 UI/report) and `server.ts` (FDTD
   solver, via `getAbsorptionAt500Hz`) both use the shared per-octave-band
   table in `absorption.ts`. The two tables' numbers diverge per material
   (e.g. `acoustic_panel`: 0.70 in `materials.ts` vs 0.75 at 500Hz in the
   shared table), so the real-time audio preview's reverb time could
   audibly disagree with the RT60 shown elsewhere in the app for the exact
   same room and materials. Fixed by sourcing this calculation's absorption
   from `absorption.ts`'s 500Hz value instead, matching the pattern already
   used in `server.ts`. `materials.ts`'s `MATERIALS` list (names/TL values
   for the material picker UI) is unrelated and still used as before.

## Round 4 — store & components

8. **`src/store/useStore.ts` — `saveProject()` exported the entire raw
   store, not a clean project.** `saveProject()` called
   `JSON.stringify(get())` directly, dumping every field currently in
   Zustand state: all action functions (silently dropped by `JSON.
   stringify`, so not a crash, but not intentional), UI-only state (`view`,
   `viewMode`, `showMixer`, `selectedWallSeg`, `activeParam`...), undo/redo
   history (`past`/`future`), and even a live, non-serializable
   `MediaDeviceInfo[]` (`availableMics`). `useProjectsStore.ts`'s own
   comment states the file export is supposed to match its
   `extractProjectData()` shape — it didn't. Fixed to export only the
   actual project fields, matching `extractProjectData()`/
   `applyProjectData()`.

9. **`src/components/RightSidebar.tsx` — dead code referencing
   nonexistent API fields.** After a successful `/api/solver/wave` call,
   a second block checked `data.trace`/`data.dt`, but the server's actual
   JSON response only ever includes `receiverTrace`/`dtEstimate`
   (confirmed by reading the route's `res.json({...})` call directly) —
   so this block was unreachable dead code duplicating what the
   `receiverTrace`/`dtEstimate` block above it already did correctly.
   Removed.

10. **`src/components/Layout.tsx` — legacy project load bypassed all
    validation.** The legacy single-project load path
    (`useStore.setState(data.projectData)`) applied whatever the server
    returned directly to the store with no whitelisting or validation,
    unlike `useProjectsStore.ts`'s `applyProjectData()` for the
    multi-project path, which explicitly whitelists fields and clamps
    `L`/`W`/`H` against corrupted/zero/negative/NaN values before they
    reach room geometry, wall-occlusion audio, and RT60 math. Fixed to
    whitelist and validate the same way.

11. **`src/components/Layout.tsx` — legacy autosave silently dropped room
    dimensions.** The legacy path's autosave `snapshot` object omitted
    `L`/`W`/`H` entirely, even though they're real, user-editable room
    dimensions and `useProjectsStore.ts`'s `extractProjectData()` already
    includes them for the multi-project path. Any legacy (non-multi-
    project) user's custom room dimensions were silently dropped on every
    autosave and would revert to the `L=10/W=8/H=3` defaults on next load.
    Added them to the snapshot.

12. **`src/components/SpeakerPicker.tsx` — same legacy-sensitivity
    mislabeling as `speakers.ts` (round 3, fix 6).** The guitar-cab/car-
    audio spec panel labeled any speaker with a numeric
    `sensitivity.value` as "Manufacturer specification," which doesn't
    hold for legacy entries (real value, but `status: 'LEGACY'`, no real
    source). Currently unreachable with the actual speaker data (no
    legacy entry falls into those two categories — checked directly
    against `speakers.json`), but fixed defensively to stay correct if
    that changes, using the same `status === 'LEGACY'` check as the
    `speakers.ts` fix.

## Round 5 — report generator & remaining files

13. **`server/reportGenerator.ts` — speaker placement diagnosis used
    normalized coordinates as if they were real meters.** The PDF report's
    corner/near-wall/free-space speaker diagnosis compared `s.x`/`s.y`
    directly against `0.5` and `room.L - 0.5` / `room.W - 0.5`. But
    speaker `x`/`y` are normalized (0-1) footprint coordinates everywhere
    else in the app (confirmed against `roomAcoustics.ts`'s
    `RoomGeometryInput.poly` convention and `RightSidebar.tsx`, which
    passes `source.x`/`source.y` straight from the store's normalized
    `Source.x`/`y` — e.g. the default source sits at `x: 0.3, y: 0.3`).
    Since `s.x` is always in `[0,1]` and `room.L`/`room.W` are typically
    8-20m, `s.x < 0.5` was true for roughly half of all speakers
    regardless of actual placement, and `s.x > room.L - 0.5` was
    essentially never true for any normal-sized room — so the "in a
    corner" / "near a wall" / "in free space" diagnosis in the generated
    report was effectively arbitrary rather than reflecting where the
    speaker was actually placed. Fixed by converting to real coordinates
    (`s.x * room.L`, `s.y * room.W`) before the threshold comparisons,
    matching the conversion `ThreeView.tsx` and `roomAcoustics.ts` already
    use correctly.

## Not fixed / out of scope here

- No dependency install or `tsc --noEmit` could be run (no network access
  in this environment) — same limitation noted in the original
  `FIXES_APPLIED.md`. These fixes address bugs found by reading the code,
  not a compiler-verified pass.
- `materials.ts`'s flat `ABSORPTION` table itself was left in place (it's
  still used correctly for TL/color lookups elsewhere) rather than deleted
  — only its use as an RT60 input in `audioEngine.ts` was redirected to the
  shared per-band table. Consider removing the flat table's `getAbsorption`
  export entirely in a future pass so this can't regress.
- Speaker JSON data itself (356 entries) and `speakers.json`-level
  corrections were not re-audited beyond the `sensitivitySource`/legacy-
  label derivation bugs above — round 1's `FIXES_APPLIED.md` already
  covers Jensen spec corrections and reclassification.
- `PaywallModal.tsx`'s advertised "Wave solver up to 355 Hz" (Standard
  tier) figure was checked against the server's actual `actualFmax`
  formula and found to be room-size/accuracy-mode dependent — not
  necessarily wrong, but not verifiable as correct either without knowing
  which reference room/settings the marketing copy assumed. Flagged, not
  changed, since this is a business-copy judgment call rather than a
  code-logic bug.
- `src/physics/gpu-solver.ts`'s benchmark shader hardcodes a `310^3`-cube
  Z-stride assumption (`uZStride = 310.0 / texSize`) regardless of the
  actual `elements` argument passed in — the module's own header already
  discloses this is a standalone capability/performance check whose timing
  should never be presented as reflecting a specific simulation result, so
  this was flagged but not changed pending a decision on whether the
  benchmark workload shape should scale with the requested element count.
- `Dashboard.tsx`, `ThreeView.tsx` (spot-checked its coordinate handling
  specifically — found correct), `LandingPage.tsx`, `ErrorBoundary.tsx`,
  `RotateDevicePrompt.tsx`, and `AuthProvider.tsx` were scanned for the
  same data-shape/coordinate-mismatch patterns that caught the bugs above
  but not read line-by-line in full.



