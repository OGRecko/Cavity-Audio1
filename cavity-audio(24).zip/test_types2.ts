import { Polar } from '@polar-sh/sdk';
type Create = Parameters<Polar['checkouts']['create']>[0];
let obj: Create = { productId: "123", customerEmail: "a@b", successUrl: "a" } as any;
