import express from "express";
import { OAuth2Client } from "google-auth-library";
const googleClient = new OAuth2Client();
import helmet from "helmet";
import path from "path";

function timingSafeStringEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
}

function parseFiniteInRange(val: any, min: number, max: number, nameOrDef: any): number {
    const num = Number(val);
    if (Number.isFinite(num) && num >= min && num <= max) return num;
    if (typeof nameOrDef === "string") throw new Error(nameOrDef + " is invalid");
    return nameOrDef;
  }

const adminGuardLimiter = authRateLimit({
  ipMax: 100,
  windowMs: 15 * 60 * 1000,
  routeName: "admin"
});

function adminGuard(req: any, res: any, next: any) {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ error: 'Forbidden' });
  }
}


import { Worker } from "worker_threads";

function runSolverWorker(type: string, payload: any): Promise<any> {
  return new Promise((resolve, reject) => {
    const isProd = process.env.NODE_ENV === 'production';
    const workerPath = isProd 
      ? path.join(process.cwd(), 'dist', 'solverWorker.cjs') 
      : path.join(process.cwd(), 'server', 'solverWorker.ts');
      
    const workerOptions: any = { workerData: { type, payload } };
    if (!isProd) {
      workerOptions.execArgv = ['--import', 'tsx']; 
    }
    
    const worker = new Worker(workerPath, workerOptions);
    
    let resolved = false;
    
    // Hard 60 second timeout for any background solver work
    const timeoutId = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        worker.terminate();
        reject(new Error("Worker timed out after 60 seconds"));
      }
    }, 60000);
    
    worker.on('message', (msg) => {
      if (resolved) return;
      resolved = true;
      clearTimeout(timeoutId);
      worker.terminate().catch(() => {});
      if (msg.success) resolve(msg.data);
      else reject(new Error(msg.error));
    });
    
    worker.on('error', (err) => {
      if (resolved) return;
      resolved = true;
      clearTimeout(timeoutId);
      worker.terminate().catch(() => {});
      reject(err);
    });
    
    worker.on('exit', (code) => {
      if (resolved) return;
      resolved = true;
      clearTimeout(timeoutId);
      if (code !== 0) reject(new Error(`Worker stopped with exit code ${code}`));
    });
  });
}

import { createServer as createViteServer } from "vite";
import crypto from "crypto";
import nodemailer from "nodemailer";
import cookieParser from "cookie-parser";
import { usersCollection, projectsCollection, promoCodesCollection, verificationCodesCollection, passwordResetsCollection, UserRecord, ProjectRecord, simulationsCollection, firestoreDb, VerificationRecord, PasswordResetRecord, PromoCodeRecord, SimulationRecord, signupAbuseCollection, uniqueEmailsCollection, uniqueUsernamesCollection } from "./server/db";
import { authRateLimit } from "./server/rateLimit";
import { checkAndRecordSignup } from "./server/signupRateLimit";
import { getAbsorption } from "./src/lib/absorption";
import { generateProjectReport as generateAcousticReport } from "./server/reportGenerator";

// Broadband (500 Hz) absorption lookup for the FDTD solver's per-step
// boundary damping, derived from the shared per-octave-band table in
// src/lib/absorption.ts rather than a second hand-maintained map.
function getAbsorptionAt500Hz(materialId: string): number {
  return getAbsorption(materialId).hz500;
}
import {
  hashPassword,
  verifyPassword,
  generateCode,
  hashCode,
  createSessionToken,
  verifySessionToken,
  SESSION_COOKIE_NAME,
  SESSION_COOKIE_MAX_AGE,
} from "./server/authUtils";

const app = express();
import { errorLogger } from "./server/errorLogger";
app.use(errorLogger);
// trust proxy should be configured based on the deployment environment
// We'll read TRUST_PROXY from environment (default to 1 for Cloud Run)
app.set("trust proxy", process.env.TRUST_PROXY ? (isNaN(Number(process.env.TRUST_PROXY)) ? process.env.TRUST_PROXY : Number(process.env.TRUST_PROXY)) : 1);
const PORT = 3000;

app.use(cookieParser());
app.get("/api/health", (req, res) => res.json({ status: "ok" }));
app.use((req, res, next) => {
  if (req.originalUrl === '/api/webhooks/polar') {
    return next();
  }
  express.json({ limit: '5mb' })(req, res, next);
});

// ---------------------------------------------------------------------------
// Email helpers (SMTP via nodemailer — works with any provider, no Firebase)
// ---------------------------------------------------------------------------

const mailTransporter = process.env.SMTP_HOST
  ? nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: Number(process.env.SMTP_PORT) === 465,

      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
    })
  : null;

async function sendVerificationEmail(email: string, firstName: string, code: string): Promise<boolean> {
  const subject = "Your Cavity verification code";
  const text = `Hi ${firstName},\n\nYour Cavity verification code is: ${code}\n\nThis code expires in 15 minutes. If you didn't request this, you can ignore this email.`;
  const html = `<p>Hi ${firstName},</p><p>Your Cavity verification code is:</p><p style="font-size:28px;font-weight:bold;letter-spacing:4px;">${code}</p><p>This code expires in 15 minutes. If you didn't request this, you can ignore this email.</p>`;

  try {
    if (!mailTransporter) {
      // Development-only bypass must be explicitly enabled. Production never
      // auto-verifies an address merely because SMTP is unavailable.
      if (process.env.NODE_ENV !== "production" && process.env.ALLOW_DEV_EMAIL_BYPASS === "true") {
        console.warn(`[dev] SMTP not configured. Verification code for ${email}: ${code}`);
        return false;
      }
      throw new Error("SMTP is not configured.");
    }

    await mailTransporter.sendMail({
      from: process.env.SMTP_FROM || "Cavity <no-reply@cavity.app>",
      to: email,
      subject,
      text,
      html,
    });
    return true; // Sent successfully
  } catch (err) {
    console.error(`SMTP error when sending verification code: ${err}`);
    throw new Error("Failed to send verification email.");
  }
}

async function sendPasswordResetEmail(email: string, firstName: string, code: string): Promise<boolean> {
  const subject = "Reset your Cavity password";
  const text = `Hi ${firstName},\n\nYour Cavity password reset code is: ${code}\n\nThis code expires in 15 minutes. If you didn't request this, you can safely ignore this email — your password will not be changed.`;
  const html = `<p>Hi ${firstName},</p><p>Your Cavity password reset code is:</p><p style="font-size:28px;font-weight:bold;letter-spacing:4px;">${code}</p><p>This code expires in 15 minutes. If you didn't request this, you can safely ignore this email — your password will not be changed.</p>`;

  try {
    if (!mailTransporter) {
      // Mirror sendVerificationEmail's fail-closed behavior: production
      // never silently "succeeds" (nor logs the raw reset code) just
      // because SMTP isn't configured. Only the explicit dev bypass may
      // surface the code, and only outside production.
      if (process.env.NODE_ENV !== "production" && process.env.ALLOW_DEV_EMAIL_BYPASS === "true") {
        console.warn(`[dev] SMTP not configured. Password reset code for ${email}: ${code}`);
        return false;
      }
      throw new Error("SMTP is not configured.");
    }

    await mailTransporter.sendMail({
      from: process.env.SMTP_FROM || "Cavity <no-reply@cavity.app>",
      to: email,
      subject,
      text,
      html,
    });
    return true;
  } catch (err) {
    console.error(`SMTP error when sending password reset code: ${err}`);
    throw new Error("Failed to send password reset email.");
  }
}

const USERNAME_RE = /^[a-zA-Z0-9_]{6,20}$/;
const CODE_TTL_MS = 15 * 60 * 1000; // 15 minutes
const RESEND_COOLDOWN_MS = 60 * 1000; // 1 minute
const TRIAL_MS = 15 * 24 * 60 * 60 * 1000; // 15 days

// ---------------------------------------------------------------------------
// Rate limiters for authentication endpoints (item 23). Combines per-IP and
// per-account throttling with a generic, non-enumerating error message.
// ---------------------------------------------------------------------------
const loginLimiter = authRateLimit({
  routeName: "login",
  windowMs: 15 * 60 * 1000,
  ipMax: 20,
  keyMax: 8,
  getKey: (req) => req.body?.identifier,
});
const forgotPasswordLimiter = authRateLimit({
  routeName: "forgot-password",
  windowMs: 15 * 60 * 1000,
  ipMax: 10,
  keyMax: 5,
  getKey: (req) => req.body?.email,
});
const resetPasswordLimiter = authRateLimit({
  routeName: "reset-password",
  windowMs: 15 * 60 * 1000,
  ipMax: 20,
  keyMax: 10,
  getKey: (req) => req.body?.email,
});
const resendCodeLimiter = authRateLimit({
  routeName: "resend-code",
  windowMs: 15 * 60 * 1000,
  ipMax: 10,
  keyMax: 5,
  getKey: (req) => req.body?.email,
});
const verifyCodeLimiter = authRateLimit({
  routeName: "verify-code",
  windowMs: 15 * 60 * 1000,
  ipMax: 30,
  keyMax: 15,
  getKey: (req) => req.body?.email,
});

function sanitizeUser(user: UserRecord) {
  return {
    uid: user.uid,
    firstName: user.firstName,
    lastName: user.lastName,
    username: user.username,
    email: user.email,
    emailVerified: user.emailVerified,
  };
}

function setSessionCookie(res: any, uid: string, rememberMe: boolean = true) {
  const token = createSessionToken(uid);
  // This app serves its frontend and API from the same Express process/origin
  // (see the static-file + catch-all route at the bottom of this file), so
  // there's no cross-site request that legitimately needs this cookie sent —
  // "lax" (sent on top-level navigation, withheld on cross-site XHR/fetch)
  // is the correct, narrower default here. "none" was carried over from an
  // earlier split-origin assumption that no longer applies; it wasn't
  // exploitable (there's no CORS allowlist granting a foreign origin access
  // to read the response either way), but it was wider than this deployment
  // needs, and would become a real gap the moment anyone adds a permissive
  // CORS middleware later without revisiting this. `secure` still requires
  // HTTPS in production; only relaxed for local HTTP dev.
  const options: any = {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
  };
  if (rememberMe) {
    options.maxAge = SESSION_COOKIE_MAX_AGE;
  }
  res.cookie(SESSION_COOKIE_NAME, token, options);
}

// Requires a valid session cookie. Attaches the full user record to req.user.
async function authMiddleware(req: any, res: any, next: any) {
  try {
    const uid = verifySessionToken(req.cookies?.[SESSION_COOKIE_NAME]);
    if (!uid) {
      return res.status(401).json({ error: "Not logged in." });
    }
    const doc = await usersCollection.doc(uid).get();
    if (!doc.exists) {
      res.clearCookie(SESSION_COOKIE_NAME);
      return res.status(401).json({ error: "Not logged in." });
    }
    req.user = doc.data();
    next();
  } catch (err) {
    console.error("Auth middleware error:", err);
    res.status(503).json({ error: "Service unavailable." });
  }
}

// ---------------------------------------------------------------------------

async function adminMiddleware(req: any, res: any, next: any) {
  if (!req.user || req.user.role !== "admin") {
    return res.status(403).json({ error: "Forbidden: Admins only." });
  }
  next();
}

app.post("/api/admin/signup-abuse/:ip/unban", authMiddleware, adminMiddleware, async (req: any, res: any) => {
  const ip = req.params.ip;
  if (!ip) return res.status(400).json({ error: "IP is required." });
  try {
    const ref = signupAbuseCollection.doc(ip);
    await ref.delete();
    res.json({ success: true, message: `IP ${ip} unbanned.` });
  } catch(e) {
    console.error("Admin unban error:", e);
    res.status(500).json({ error: "Service unavailable." });
  }
});

// Heavy-compute guard for the FDTD solver endpoints
// ---------------------------------------------------------------------------
// Node runs JavaScript on a single thread — while one of these endpoints'
// large synchronous nested loops is executing, it blocks the ENTIRE event
// loop, stalling every other request (including other users' logins,
// project saves, everything) until it finishes. Without any protection, a
// single user spamming the "compute" button, or several users triggering
// it at once, can make the whole server unresponsive.
//
// This is a simple, in-memory, single-process guard: per-user cooldown
// (reject a new request if their last one hasn't been outside the cooldown
// window) plus a global concurrency cap (reject if too many heavy
// computations are already in flight across all users). It is NOT a
// substitute for a real job queue or moving this work to worker threads —
// see the note below — but it prevents the most obvious abuse/pile-up
// cases cheaply, with no new dependency.
//
// LIMITATION: this state lives in a single Node process's memory. It does
// NOT coordinate across multiple server instances (e.g. behind a load
// balancer) — each instance would enforce its own limits independently.
// If this app ever runs more than one server process, replace this with a
// shared store (Redis, etc.) or move the actual computation to a proper
// background job queue.
const SOLVER_COOLDOWN_MS = 3000; // minimum time between one user's solver requests
const MAX_CONCURRENT_SOLVER_JOBS = 2; // global cap across all users, on this process
const lastSolverRequestAt = new Map<string, number>();
let activeSolverJobs = 0;

function solverGuard(req: any, res: any, next: any) {
  const uid = req.user?.uid;
  const now = Date.now();

  if (activeSolverJobs >= MAX_CONCURRENT_SOLVER_JOBS) {
    return res.status(429).json({ error: "The server is already computing another simulation. Please try again in a moment." });
  }
  const last = uid ? lastSolverRequestAt.get(uid) : undefined;
  if (last && now - last < SOLVER_COOLDOWN_MS) {
    return res.status(429).json({ error: `Please wait ${Math.ceil((SOLVER_COOLDOWN_MS - (now - last)) / 1000)}s before running another simulation.` });
  }
  if (uid) lastSolverRequestAt.set(uid, now);

  activeSolverJobs++;
  // Decrement once the response is actually sent, whether it succeeded,
  // errored, or the client disconnected — 'finish' and 'close' cover all
  // of those cases so activeSolverJobs can never get stuck incremented.
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
    activeSolverJobs = Math.max(0, activeSolverJobs - 1);
  };
  res.on('finish', release);
  res.on('close', release);

  next();
}

import { Polar } from '@polar-sh/sdk';

// Polar integration
const polar = new Polar({
  accessToken: process.env.POLAR_ACCESS_TOKEN,
});

// Maps a Polar product_id from a webhook event to this app's internal plan
// tier. Previously this only checked against the Premium product IDs and
// treated everything else as "standard" by default -- an assumption, not a
// check, which meant a misconfigured or unrecognized product_id (including
// a genuine third tier added later) would silently get bucketed as
// "standard" with no visibility into that happening. Now Standard product
// IDs are checked explicitly too, and a product_id matching neither tier is
// logged rather than silently guessed at, so a configuration problem shows
// up in the logs instead of quietly mis-granting access.
function resolvePlanFromProductId(pId: string | undefined): 'premium' | 'standard' | null {
  if (pId === process.env.VITE_POLAR_PREMIUM_MONTHLY_PRODUCT_ID || pId === process.env.VITE_POLAR_PREMIUM_ANNUAL_PRODUCT_ID) {
    return 'premium';
  }
  if (pId === process.env.VITE_POLAR_STANDARD_MONTHLY_PRODUCT_ID || pId === process.env.VITE_POLAR_STANDARD_ANNUAL_PRODUCT_ID) {
    return 'standard';
  }
  console.error(`[Polar webhook] Unrecognized product_id "${pId}" — refusing to assign a plan. Check VITE_POLAR_*_PRODUCT_ID env vars.`);
  return null;
}

app.post("/api/auth/signup", async (req: any, res: any) => {
  const { firstName, lastName, username, email, password } = req.body;
  if (!firstName || !lastName || !username || !email || !password) {
    return res.status(400).json({ error: "All fields are required." });
  }
  if (!USERNAME_RE.test(username)) {
    return res.status(400).json({ error: "Username must be 6-20 characters (letters, numbers, underscores)." });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters." });
  }

  const emailLower = String(email).toLowerCase().trim();
  const usernameLower = String(username).toLowerCase().trim();
  
  const ipStatus = await checkAndRecordSignup(req.ip || req.connection?.remoteAddress);
  if (!ipStatus.allowed) {
    if (ipStatus.permanent) {
      return res.status(429).json({ error: "Too many signups from this IP. Permanent ban." });
    } else {
      return res.status(429).json({ error: `Too many signups from this IP. Try again in ${Math.ceil(ipStatus.waitMs / 60000)} minute(s).` });
    }
  }

  const uid = crypto.randomUUID();
  let userRecord: UserRecord;
  try {
    await firestoreDb.runTransaction(async (t) => {
      const emailRef = uniqueEmailsCollection.doc(emailLower);
      const usernameRef = uniqueUsernamesCollection.doc(usernameLower);
      
      const emailDoc = await t.get(emailRef as any) as any;
      const usernameDoc = await t.get(usernameRef as any) as any;
      if (emailDoc.exists) throw new Error("Email is already registered.");
      if (usernameDoc.exists) throw new Error("Username is taken.");
      
      t.set(emailRef, { uid });
      t.set(usernameRef, { uid });
      
      const userRef = usersCollection.doc(uid);
      userRecord = {
        uid,
        firstName: String(firstName).trim(),
        lastName: String(lastName).trim(),
        username: String(username).trim(),
        usernameLower,
        email: String(email).trim(),
        emailLower,
        passwordHash: hashPassword(password),
        emailVerified: false,
        createdAt: Date.now(),
        subscriptionStatus: "free",
        trialStartsAt: 0,
        trialEndsAt: 0,
        role: "user"
      };
      
      t.set(userRef, userRecord);
    });
  } catch (err: any) {
    if (err.message === "Email is already registered." || err.message === "Username is taken.") {
      return res.status(400).json({ error: err.message });
    }
    console.error("Signup transaction error:", err);
    return res.status(500).json({ error: "Service unavailable." });
  }


  const user = userRecord!;
  const code = String(Math.floor(100000 + Math.random() * 900000));
  await verificationCodesCollection.doc(emailLower).set({
    codeHash: hashCode(code),
    attempts: 0,
    expiresAt: Date.now() + CODE_TTL_MS,
    lastSentAt: Date.now()
  });

  const bypassEmail = process.env.ALLOW_DEV_EMAIL_BYPASS === "true";
  if (!bypassEmail) {
    try {
      await mailTransporter.sendMail({
        from: process.env.SMTP_FROM,
        to: user.email,
        subject: "Verify your Cavity Audio account",
        text: `Your verification code is: ${code}`,
        html: `<p>Your verification code is: <strong>${code}</strong></p>`
      });
    } catch (e) {
      console.error("Mail error:", e);
    }
  }

  setSessionCookie(res, uid, false);
  res.json({ success: true, user: sanitizeUser(user), requireVerification: true, _devCode: bypassEmail ? code : undefined });
});

app.post("/api/auth/login", loginLimiter, async (req: any, res: any) => {
  const { identifier, password, rememberMe } = req.body;
  if (!identifier || !password) return res.status(400).json({ error: "Missing identifier or password." });

  const identLower = String(identifier).toLowerCase().trim();
  let userQuery = await usersCollection.where("emailLower", "==", identLower).limit(1).get();
  if (userQuery.empty) {
    userQuery = await usersCollection.where("usernameLower", "==", identLower).limit(1).get();
  }

  if (userQuery.empty) {
    return res.status(401).json({ error: "Invalid credentials." });
  }
  
  const loggedInUser = userQuery.docs[0].data() as UserRecord;
  const userRef = userQuery.docs[0].ref;

  let passwordValid = false;
  if (loggedInUser.passwordHash.includes(':')) {
    // Modern scrypt hash
    passwordValid = verifyPassword(password, loggedInUser.passwordHash);
  } else {
    // Legacy SHA-256 hash
    passwordValid = timingSafeStringEqual(loggedInUser.passwordHash, hashCode(password));
    if (passwordValid) {
            // Upgrade hash on successful login
      const upgradedHash = hashPassword(password);
      await userRef.update({ passwordHash: upgradedHash });
      loggedInUser.passwordHash = upgradedHash;
    }
  }

  if (!passwordValid) {
    return res.status(401).json({ error: "Invalid credentials." });
  }

  setSessionCookie(res, loggedInUser.uid, !!rememberMe);
  res.json({ success: true, user: sanitizeUser(loggedInUser) });
});

app.post("/api/auth/start-trial", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const userRef = usersCollection.doc(uid);

  try {
    const success = await firestoreDb.runTransaction(async (t) => {
      const doc = await t.get(userRef);
      if (!doc.exists) return false;
      const user = doc.data() as UserRecord;
      
      if (user.trialUsedAt) {
        return false;
      }
      
      const now = Date.now();
      t.update(userRef, {
        trialStartsAt: now,
        trialEndsAt: now + TRIAL_MS,
        trialUsedAt: now,
        subscriptionStatus: "trial",
        plan: "premium"
      });
      return true;
    });

    if (!success) {
      return res.status(400).json({ error: "You have already used your free trial." });
    }
    res.json({ success: true });
  } catch (err) {
    console.error("Trial error:", err);
    res.status(500).json({ error: "Failed to start trial." });
  }
});

app.post("/api/auth/google", async (req: any, res: any) => {
  const { credential } = req.body;
  if (!credential) return res.status(400).json({ error: "Missing credential." });
  if (!process.env.VITE_GOOGLE_CLIENT_ID) return res.status(500).json({ error: "Google Auth is not configured." });

  try {
    const ticket = await googleClient.verifyIdToken({
      idToken: credential,
      audience: process.env.VITE_GOOGLE_CLIENT_ID,
    });
    const tokenInfo = ticket.getPayload();
    if (!tokenInfo || !tokenInfo.email || !tokenInfo.email_verified) {
      return res.status(400).json({ error: "Google Auth failed or email not verified." });
    }

    const email = String(tokenInfo.email).trim();
    const emailLower = email.toLowerCase();
    
    let userQuery = await usersCollection.where("emailLower", "==", emailLower).limit(1).get();
    let user: UserRecord;

    if (!userQuery.empty) {
      user = userQuery.docs[0].data() as UserRecord;
      if (!user.emailVerified) {
        await usersCollection.doc(user.uid).update({ emailVerified: true });
        user.emailVerified = true;
      }
    } else {
      const uid = crypto.randomUUID();
      const baseName = email.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '');
      let username = baseName;
      let suffix = 1;
      while (!(await usersCollection.where("usernameLower", "==", username.toLowerCase()).limit(1).get()).empty) {
        username = `${baseName}${suffix++}`;
      }

      user = {
        uid,
        firstName: tokenInfo.given_name || "",
        lastName: tokenInfo.family_name || "",
        username,
        usernameLower: username.toLowerCase(),
        email,
        emailLower,
        passwordHash: crypto.randomUUID(), 
        emailVerified: true,
        createdAt: Date.now(),
        subscriptionStatus: "free",
        trialStartsAt: 0,
        trialEndsAt: 0,
        role: "user"
      };
      await usersCollection.doc(uid).set(user);
    }

    setSessionCookie(res, user.uid, true);
    res.json({ success: true, user: sanitizeUser(user) });
  } catch (err) {
    console.error("Google Auth error:", err);
    res.status(401).json({ error: "Invalid Google token." });
  }
});

app.post("/api/auth/logout", (req: any, res: any) => {
  res.clearCookie(SESSION_COOKIE_NAME, { path: "/" });
  res.json({ success: true });
});

app.post("/api/auth/verify-code", verifyCodeLimiter, async (req: any, res: any) => {
  const { email, code } = req.body;
  if (!email || !code) return res.status(400).json({ error: "Missing email or code." });
  
  const emailLower = String(email).toLowerCase().trim();
  const recordDoc = await verificationCodesCollection.doc(emailLower).get();
  
  if (!recordDoc.exists) {
    return res.status(400).json({ error: "No pending verification found." });
  }
  
  const record = recordDoc.data() as VerificationRecord;
  if (record.expiresAt < Date.now()) return res.status(400).json({ error: "That code has expired. Request a new one." });
  if (record.attempts >= 5) return res.status(429).json({ error: "Too many incorrect attempts. Request a new code." });
  
  if (!timingSafeStringEqual(record.codeHash, hashCode(String(code).trim()))) {
    await verificationCodesCollection.doc(emailLower).update({ attempts: record.attempts + 1 });
    return res.status(400).json({ error: "Incorrect verification code." });
  }
  
  const userQuery = await usersCollection.where("emailLower", "==", emailLower).limit(1).get();
  if (!userQuery.empty) {
    const userDoc = userQuery.docs[0];
    await userDoc.ref.update({ emailVerified: true });
    await verificationCodesCollection.doc(emailLower).delete();
    
    // Auto-login after verification
    setSessionCookie(res, userDoc.id, true);
    const user = { ...userDoc.data(), emailVerified: true } as UserRecord;
    res.json({ success: true, user: sanitizeUser(user) });
  } else {
    res.status(404).json({ error: "User not found." });
  }
});

app.post("/api/auth/resend-code", resendCodeLimiter, async (req: any, res: any) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: "Missing email." });
  
  const emailLower = String(email).toLowerCase().trim();
  const userQuery = await usersCollection.where("emailLower", "==", emailLower).limit(1).get();
  if (userQuery.empty) return res.status(404).json({ error: "User not found." });
  
  const recordDoc = await verificationCodesCollection.doc(emailLower).get();
  if (recordDoc.exists && Date.now() - recordDoc.data()!.lastSentAt < RESEND_COOLDOWN_MS) {
    return res.status(429).json({ error: "Please wait a minute before requesting another code." });
  }
  
  const code = String(Math.floor(100000 + Math.random() * 900000));
  await verificationCodesCollection.doc(emailLower).set({
    codeHash: hashCode(code),
    attempts: 0,
    expiresAt: Date.now() + CODE_TTL_MS,
    lastSentAt: Date.now()
  });

  const bypassEmail = process.env.ALLOW_DEV_EMAIL_BYPASS === "true";
  if (!bypassEmail) {
    try {
      await mailTransporter.sendMail({
        from: process.env.SMTP_FROM,
        to: emailLower,
        subject: "Verify your Cavity Audio account",
        text: `Your verification code is: ${code}`,
        html: `<p>Your verification code is: <strong>${code}</strong></p>`
      });
    } catch (e) {
      console.error("Mail error:", e);
    }
  }
  res.json({ success: true, _devCode: bypassEmail ? code : undefined });
});

app.post("/api/auth/forgot-password", forgotPasswordLimiter, async (req: any, res: any) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: "Enter your email address." });
  
  const emailLower = String(email).toLowerCase().trim();
  const userQuery = await usersCollection.where("emailLower", "==", emailLower).limit(1).get();
  
  if (userQuery.empty) {
    return res.json({ success: true });
  }

  const recordDoc = await passwordResetsCollection.doc(emailLower).get();
  if (recordDoc.exists && Date.now() - recordDoc.data()!.lastSentAt < RESEND_COOLDOWN_MS) {
    return res.json({ success: true }); 
  }

  const code = String(Math.floor(100000 + Math.random() * 900000));
  await passwordResetsCollection.doc(emailLower).set({
    codeHash: hashCode(code),
    attempts: 0,
    expiresAt: Date.now() + CODE_TTL_MS,
    lastSentAt: Date.now()
  });

  const bypassEmail = process.env.ALLOW_DEV_EMAIL_BYPASS === "true";
  if (!bypassEmail) {
    try {
      await mailTransporter.sendMail({
        from: process.env.SMTP_FROM,
        to: emailLower,
        subject: "Reset your Cavity Audio password",
        text: `Your password reset code is: ${code}`,
        html: `<p>Your password reset code is: <strong>${code}</strong></p>`
      });
    } catch (e) {
      console.error("Mail error:", e);
    }
  }
  res.json({ success: true, _devCode: bypassEmail ? code : undefined });
});

app.post("/api/auth/reset-password", resetPasswordLimiter, async (req: any, res: any) => {
  const { email, code, newPassword } = req.body;
  if (!email || !code || !newPassword) return res.status(400).json({ error: "Missing fields." });
  if (newPassword.length < 6) return res.status(400).json({ error: "Password must be at least 6 characters." });

  const emailLower = String(email).toLowerCase().trim();
  const userQuery = await usersCollection.where("emailLower", "==", emailLower).limit(1).get();
  const recordDoc = await passwordResetsCollection.doc(emailLower).get();

  if (userQuery.empty || !recordDoc.exists) {
    return res.status(400).json({ error: "Invalid or expired reset code. Request a new one." });
  }

  const record = recordDoc.data() as PasswordResetRecord;
  if (record.expiresAt < Date.now()) return res.status(400).json({ error: "That code has expired. Request a new one." });
  if (record.attempts >= 5) return res.status(429).json({ error: "Too many incorrect attempts. Request a new code." });

  if (!timingSafeStringEqual(record.codeHash, hashCode(String(code).trim()))) {
    await passwordResetsCollection.doc(emailLower).update({ attempts: record.attempts + 1 });
    return res.status(400).json({ error: "Incorrect reset code." });
  }

  const userDoc = userQuery.docs[0];
  await userDoc.ref.update({ passwordHash: hashPassword(newPassword) });
  await passwordResetsCollection.doc(emailLower).delete();
  
  res.json({ success: true });
});
// --- USER AND PROJECTS ---

app.get("/api/me", authMiddleware, async (req: any, res: any) => {
  res.json({ user: sanitizeUser(req.user) });
});

// Legacy single-project save support
app.get("/api/project", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const user = req.user as UserRecord;
  let projectData = null;
  if (user.activeProjectId) {
    const pDoc = await projectsCollection.doc(user.activeProjectId).get();
    if (pDoc.exists) projectData = pDoc.data()?.data;
  }
  res.json({ projectData });
});

app.post("/api/project", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const user = req.user as UserRecord;
  let projectId = user.activeProjectId;
  
  if (!projectId) {
    projectId = crypto.randomUUID();
    await usersCollection.doc(uid).update({ activeProjectId: projectId });
  }

  await projectsCollection.doc(projectId).set({
    id: projectId,
    ownerId: uid,
    name: "Untitled Project",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    data: req.body.projectData
  }, { merge: true });

  res.json({ success: true });
});

app.get("/api/projects", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const user = req.user as UserRecord;
  
  const snap = await projectsCollection
    .where("ownerId", "==", uid)
    .where("archived", "==", false)
    .get();
    
  const projects = snap.docs.map(d => {
    const p = d.data();
    return { id: p.id, name: p.name, createdAt: p.createdAt, updatedAt: p.updatedAt };
  }).sort((a, b) => b.updatedAt - a.updatedAt);

  res.json({ projects, activeProjectId: user.activeProjectId || null });
});

app.post("/api/projects", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const name = String(req.body.name || 'Untitled Project').slice(0, 200);
  const id = crypto.randomUUID();
  const now = Date.now();

  const newProject: ProjectRecord = {
    id,
    ownerId: uid,
    name,
    createdAt: now,
    updatedAt: now,
    archived: false,
    schemaVersion: 1,
    appVersion: "1.0.0",
    data: req.body.data ?? null,
  };

  try {
    await projectsCollection.doc(id).set(newProject);
    await usersCollection.doc(uid).update({ activeProjectId: id });
    res.json({ success: true, project: newProject });
  } catch (err) {
    console.error("POST /api/projects error:", err);
    res.status(500).json({ error: "Service unavailable." });
  }
});

app.get("/api/projects/:id", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  try {
    const doc = await projectsCollection.doc(req.params.id).get();
    
    if (!doc.exists) return res.status(404).json({ error: "Project not found." });
    const project = doc.data() as ProjectRecord;
    if (project.ownerId !== uid || project.archived) return res.status(404).json({ error: "Project not found." });
    
    res.json({ project });
  } catch (err: any) {
    console.error("GET /api/projects/:id error:", err);
    res.status(500).json({ error: "Service unavailable." });
  }
});

app.put("/api/projects/:id", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const ref = projectsCollection.doc(req.params.id);
  
  try {
    const project = await firestoreDb.runTransaction(async (t) => {
      const doc = await t.get(ref);
      if (!doc.exists) throw new Error("Not found");
      const p = doc.data() as ProjectRecord;
      if (p.ownerId !== uid || p.archived) throw new Error("Not found");
      
      if (req.body.updatedAt != null && p.updatedAt > req.body.updatedAt) {
         throw new Error("Conflict: Project modified elsewhere.");
      }
      
      const updates: any = { updatedAt: Date.now() };
      if (req.body.name != null) updates.name = String(req.body.name).slice(0, 200);
      if (req.body.data !== undefined) updates.data = req.body.data;
      
      t.update(ref, updates);
      return { ...p, ...updates };
    });
    res.json({ success: true, project });
  } catch (e: any) {
    if (e.message === "Not found") {
      return res.status(404).json({ error: "Project not found." });
    }
    if (e.message.startsWith("Conflict")) {
      return res.status(409).json({ error: "This project has been modified in another session. Please reload." });
    }
    console.error("PUT project error:", e);
    res.status(500).json({ error: "Service unavailable." });
  }
});

app.post("/api/projects/:id/archive", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const user = req.user as UserRecord;
  const projectId = req.params.id;
  const ref = projectsCollection.doc(projectId);
  
  try {
    await firestoreDb.runTransaction(async (t) => {
      const doc = await t.get(ref);
      if (!doc.exists || doc.data()!.ownerId !== uid) throw new Error("Not found");
      
      t.update(ref, { archived: true, updatedAt: Date.now() });
      
      if (user.activeProjectId === projectId) {
        const snap = await t.get(projectsCollection.where("ownerId", "==", uid).where("archived", "==", false).limit(2));
        const remaining = snap.docs.filter(d => d.id !== projectId);
        t.update(usersCollection.doc(uid), { 
          activeProjectId: remaining.length > 0 ? remaining[0].id : null 
        });
      }
    });
    res.json({ success: true });
  } catch (e: any) {
    if (e.message === "Not found") {
      return res.status(404).json({ error: "Project not found." });
    }
    console.error("Project op error:", e);
    res.status(500).json({ error: "Service unavailable." });
  }
});

app.post("/api/projects/:id/activate", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const projectId = req.params.id;
  const doc = await projectsCollection.doc(projectId).get();
  
  if (!doc.exists || doc.data()!.ownerId !== uid || doc.data()!.archived) {
    return res.status(404).json({ error: "Project not found." });
  }
  
  await usersCollection.doc(uid).update({ activeProjectId: projectId });
  res.json({ success: true });
});

app.delete("/api/projects/:id", authMiddleware, async (req: any, res: any) => {
  const uid = req.user.uid;
  const user = req.user as UserRecord;
  const projectId = req.params.id;
  const ref = projectsCollection.doc(projectId);
  
  try {
    await firestoreDb.runTransaction(async (t) => {
      const doc = await t.get(ref);
      if (!doc.exists || doc.data()!.ownerId !== uid) throw new Error("Not found");
      
      t.delete(ref);
      
      if (user.activeProjectId === projectId) {
        const snap = await t.get(projectsCollection.where("ownerId", "==", uid).where("archived", "==", false).limit(2));
        const remaining = snap.docs.filter(d => d.id !== projectId);
        t.update(usersCollection.doc(uid), { 
          activeProjectId: remaining.length > 0 ? remaining[0].id : null 
        });
      }
    });
    res.json({ success: true });
  } catch (e: any) {
    if (e.message === "Not found") {
      return res.status(404).json({ error: "Project not found." });
    }
    console.error("Project op error:", e);
    res.status(500).json({ error: "Service unavailable." });
  }
});

app.post("/api/projects/migrate-legacy", authMiddleware, async (req: any, res: any) => {
  res.json({ migrated: false, reason: "Legacy migration no longer required." });
});
// --- ADMIN, BILLING AND PROMO CODES ---

app.post("/api/redeem", authMiddleware, async (req: any, res: any) => {
  const { code: rawCode } = req.body;
  const code = String(rawCode || "").trim();
  const uid = req.user.uid;

  if (code === 'Monthly10' || code === 'Yearly10') {
    return res.status(400).json({ error: "Please enter this code directly on the checkout page." });
  }

  const codeRef = promoCodesCollection.doc(code);
  const userRef = usersCollection.doc(uid);

  try {
    const success = await firestoreDb.runTransaction(async (t) => {
      const codeDoc = await t.get(codeRef);
      if (!codeDoc.exists) return false;
      const promo = codeDoc.data() as PromoCodeRecord;
      if (promo.redeemed || promo.revoked) return false;

      t.update(codeRef, {
        redeemed: true,
        redeemedBy: uid,
        redeemedAt: Date.now()
      });

      t.update(userRef, {
        subscriptionStatus: "active",
        plan: "lifetime"
      });

      return true;
    });

    if (!success) {
      return res.status(400).json({ error: "Invalid, expired, or already redeemed code." });
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: "Failed to redeem code." });
  }
});

app.post("/api/admin/promo-codes", adminGuardLimiter, adminGuard, async (req: any, res: any) => {
  const count = Number(req.body?.count) || 1;
  if (count < 1 || count > 100) return res.status(400).json({ error: "Count must be between 1 and 100." });
  const note = req.body?.note ? String(req.body.note).slice(0, 200) : undefined;
  
  const minted: string[] = [];
  const batch = firestoreDb.batch();

  for (let i = 0; i < count; i++) {
    let code: string;
    let exists = true;
    do {
      code = crypto.randomBytes(6).toString("base64url").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10);
      const snap = await promoCodesCollection.doc(code).get();
      exists = snap.exists;
    } while (exists);

    const record: PromoCodeRecord = {
      code,
      grant: "lifetime",
      createdAt: Date.now(),
      createdBy: req.user.uid,
      note,
      redeemed: false
    };
    batch.set(promoCodesCollection.doc(code), record);
    minted.push(code);
  }
  
  await batch.commit();
  res.json({ codes: minted });
});

app.get("/api/admin/promo-codes", adminGuardLimiter, adminGuard, async (_req: any, res: any) => {
  const snap = await promoCodesCollection.orderBy("createdAt", "desc").get();
  const codes = snap.docs.map(d => d.data());
  res.json({ codes });
});

app.post("/api/admin/promo-codes/:code/revoke", adminGuardLimiter, adminGuard, async (req: any, res: any) => {
  const ref = promoCodesCollection.doc(req.params.code);
  await firestoreDb.runTransaction(async (t) => {
    const doc = await t.get(ref);
    if (doc.exists && !doc.data()!.redeemed) {
      t.update(ref, { revoked: true });
    }
  });
  res.json({ success: true });
});

app.post("/api/checkout", authMiddleware, async (req: any, res: any) => {
  const user = req.user as UserRecord;
  const accessToken = process.env.POLAR_ACCESS_TOKEN;
  if (!accessToken) {
    return res.status(500).json({ error: "Polar Access Token is not configured." });
  }
  
  try {
    const { priceId } = req.body;
    const allowedPriceIds = [
      process.env.VITE_POLAR_STANDARD_MONTHLY_PRODUCT_ID,
      process.env.VITE_POLAR_STANDARD_ANNUAL_PRODUCT_ID,
      process.env.VITE_POLAR_PREMIUM_MONTHLY_PRODUCT_ID,
      process.env.VITE_POLAR_PREMIUM_ANNUAL_PRODUCT_ID
    ].filter(Boolean);
    
    if (!allowedPriceIds.includes(priceId)) {
      return res.status(400).json({ error: "Invalid product selected." });
    }

    const email = user.email;
    const session = await polar.checkouts.create({
      productId: priceId,
      customerEmail: email,
      successUrl: process.env.NODE_ENV === "production"
        ? (process.env.APP_ORIGIN ? `${process.env.APP_ORIGIN}/?checkout=success` : (function(){throw new Error("APP_ORIGIN missing")})())
        : `${process.env.APP_ORIGIN || "http://localhost:3000"}/?checkout=success`,
      metadata: { userId: user.uid }
    } as any);
    res.json({ url: session.url });
  } catch (err: any) {
    console.error("Polar Checkout error:", err);
    res.status(500).json({ error: "Failed to create checkout session." });
  }
});

app.post("/api/portal", authMiddleware, async (req: any, res: any) => {
  try {
    const user = req.user as UserRecord;
    if (!user.polarCustomerId) {
        return res.status(400).json({ error: "No active billing profile found." });
    }
    const session = await polar.customerSessions.create({
      customerId: user.polarCustomerId,
    });
    res.json({ url: session.customerPortalUrl });
  } catch (err) {
    console.error("Polar Portal error:", err);
    res.status(500).json({ error: "Failed to create portal session." });
  }
});

app.post("/api/webhooks/polar", express.raw({ type: '*/*' }), async (req: any, res: any) => {
  const secret = process.env.POLAR_WEBHOOK_SECRET;
  if (!secret) {
    return res.status(500).json({ error: "Webhook secret not configured" });
  }
  let event: any;
  try {
    const { validateEvent } = await import('@polar-sh/sdk/webhooks');
    event = validateEvent(req.body, req.headers, secret);
  } catch (err: any) {
    console.error("Polar webhook signature verification failed:", err?.message || err);
    return res.status(403).json({ error: "Invalid webhook signature" });
  }

  const payload = event;
  const eventName = payload.type;
  const data = payload.data;
  const eventId = payload.id;
  
  if (!eventId) return res.status(400).json({ error: "Missing event ID" });

  try {
    const webhookEventRef = firestoreDb.collection("polarWebhookEvents").doc(eventId);
    
    await firestoreDb.runTransaction(async (t) => {
      const eventDoc = await t.get(webhookEventRef);
      if (eventDoc.exists) {
        console.log(`Webhook event ${eventId} already processed.`);
        return; // Already processed
      }
      
      const userId = data.custom_field_data?.uid || data.metadata?.userId;
      let userRef = null;
      let userRecord = null;
      
      if (userId) {
        userRef = usersCollection.doc(userId);
        const userDoc = await t.get(userRef as any) as any;
        if (userDoc.exists) {
          userRecord = userDoc.data();
        }
      }

      if (userRecord && eventName === "subscription.created") {
        const plan = resolvePlanFromProductId(data.product_id || data.productId);
        if (plan) {
          t.update(userRef, {
            subscriptionStatus: "active",
            polarCustomerId: data.customer_id || data.customerId,
            plan: plan
          });
        }
      } else if (userRecord && eventName === "subscription.updated") {
        if (data.status === "active") {
          const plan = resolvePlanFromProductId(data.product_id || data.productId);
          if (plan) {
            t.update(userRef, {
              subscriptionStatus: "active",
              polarCustomerId: data.customer_id || data.customerId,
              plan: plan
            });
          }
        } else if (data.status === "canceled" || data.status === "incomplete_expired") {
          t.update(userRef, {
            subscriptionStatus: "canceled",
            plan: "free"
          });
        }
      } else if (userRecord && (eventName === "subscription.canceled" || eventName === "subscription.revoked")) {
        t.update(userRef, {
          subscriptionStatus: "canceled",
          plan: "free"
        });
      }
      
      t.set(webhookEventRef, {
        processedAt: Date.now(),
        type: eventName
      });
    });
    
    res.json({ success: true });
  } catch (err: any) {
    console.error("Polar webhook processing error:", err);
    res.status(500).json({ error: "Webhook processing failed" });
  }
});

app.post("/api/report/export", authMiddleware, async (req: any, res: any) => {
  try {
    const { simulationId, assumedSnrDb } = req.body;
    if (!simulationId) {
      return res.status(400).json({ error: "A valid simulationId is required to generate a report." });
    }
    
    const simDoc = await simulationsCollection.doc(simulationId).get();
    if (!simDoc.exists) return res.status(404).json({ error: "Simulation not found." });
    
    const sim = simDoc.data() as SimulationRecord;
    if (sim.ownerId !== req.user.uid) return res.status(403).json({ error: "Forbidden." });
    if (sim.status !== "completed") return res.status(400).json({ error: "Simulation is incomplete or failed." });

    const room = sim.room;
    const speakers = sim.speakers;
    const receivers = sim.receivers;
    const solverResult = sim.result;
    
    let L: number, W: number, H: number, parsedSnr: number | undefined;
    try {
      L = parseFiniteInRange(room.L, 0.1, 100, "Room length (L)");
      W = parseFiniteInRange(room.W, 0.1, 100, "Room width (W)");
      H = parseFiniteInRange(room.H, 0.1, 30, "Room height (H)");
      if (assumedSnrDb != null) parsedSnr = parseFiniteInRange(assumedSnrDb, -20, 120, "Assumed SNR");
    } catch (validationErr: any) {
      return res.status(400).json({ error: validationErr.message });
    }

    const reportRoom = { poly: room.poly, L, W, H, wallMaterial: room.wallMaterial || "smooth_concrete", wallSegMats: room.wallSegMats, floorMaterial: room.floorMaterial || "concrete", ceilMaterial: room.ceilMaterial || "concrete" };

    const doc = await generateAcousticReport({ 
      room: reportRoom, 
      speakers: speakers || [], 
      receivers: receivers || [], 
      solverResult: solverResult as any, 
      assumedSnrDb: parsedSnr, 
      projectName: "Export", 
      roomName: "Export",
      simulationId: sim.simulationId,
      appVersion: sim.appVersion,
      solverVersion: sim.solverVersion,
      speakerDatabaseVersion: sim.speakerDatabaseVersion || "1.0.0",
      generatedAt: new Date().toISOString(),
      simulationHash: crypto.createHmac('sha256', process.env.REPORT_INTEGRITY_SECRET || process.env.SESSION_SECRET || 'fallback').update(sim.simulationId + sim.status + sim.completedAt).digest('hex')
    } as any);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="Cavity_Acoustic_Report.pdf"');
    doc.pipe(res);
    doc.end();
  } catch (err: any) {
    console.error("Report Export Error:", err);
    res.status(500).json({ error: err.message || "Failed to generate report." });
  }
});

app.post("/api/solver/wave", authMiddleware, solverGuard, async (req: any, res: any) => {

  const payload = { ...req.body, userPlan: req.user.plan, userId: req.user.uid };
  try {
    const data = await runSolverWorker('wave', payload);
    
        // Await simulation persistence to guarantee server-authoritative ownership.
    // If the database fails, the client should not be told it succeeded with a phantom ID.
    const simulationId = crypto.randomUUID();
    const resultObj = {
      rt60: data.rt60,
      simulatedRt60: data.simulatedRt60,
      gridDims: data.gridDims,
      steps: data.steps,
    };
    try {
      const projId = req.body.projectId;
      if (projId) {
        // verify project ownership
        const projDoc = await projectsCollection.doc(projId).get();
        if (!projDoc.exists || projDoc.data().ownerId !== req.user.uid) {
          throw new Error("Invalid or unowned project ID.");
        }
      }
      
      await simulationsCollection.doc(simulationId).set({
        simulationId,
        ownerId: req.user.uid,
        projectId: req.body.projectId || null,
        appVersion: "1.0.0",
        solverVersion: "1.0.0",
        speakerDatabaseVersion: "1.0.0",
        createdAt: Date.now(),
        completedAt: Date.now(),
        status: "completed",
        room: req.body,
        speakers: [req.body.source],
        receivers: [req.body.receiver],
        result: resultObj
      });
    } catch (e) {
      console.error("Failed to save simulation", e);
      return res.status(500).json({ error: "Failed to persist simulation record." });
    }
    
    data.simulationId = simulationId;
    return res.json(data);
  } catch (err: any) {
    console.error("Wave Solver Error:", err);
    try {
      const parsed = JSON.parse(err.message);
      return res.status(422).json(parsed);
    } catch {
      return res.status(500).json({ error: err.message || "Wave computation failed." });
    }
  }

});

// ---------------------------------------------------------------------------
// IMPULSE RESPONSE / DECAY-METRIC SOLVER
// ---------------------------------------------------------------------------
// The endpoint above is a quick preview run: it prioritizes a fine spatial
// grid (up to 30M elements) but, as a direct consequence of that fine grid,
// can only afford a handful of time steps (numSteps <= 40) before a single
// HTTP request would take too long — which means it only ever simulates
// roughly 1-1.5ms of real time. That's nowhere near enough for RT60
// (typically 300-2000ms), C50/C80 (need >= 80ms of IR), or Ts to mean
// anything; it was being computed from a trace that hadn't even let sound
// leave the source region yet.
//
// RT60/C50/C80/D50/Ts are TEMPORAL decay metrics — they don't need a fine
// spatial mesh to be physically valid, they need enough SIMULATED TIME.
// This endpoint deliberately trades spatial resolution for step count: a
// small, coarse grid (a few thousand to tens of thousands of elements,
// regardless of the visual-quality tier) that can run thousands of cheap
// steps instead of dozens of expensive ones, reaching real reverberation
// timescales.
//
// Step count is derived from this room's OWN Sabine RT60 estimate (using
// the same absorption data as everywhere else in the app) so short/dead
// rooms don't waste time simulating far past their decay, and
// long/reverberant rooms get enough steps to actually capture their tail.
// Hard-capped regardless, since this is still a synchronous request with no
// progress reporting — if that cap is hit before 2x the estimated RT60 is
// reached, the response says so explicitly rather than silently truncating.
app.post("/api/solver/impulse-response", authMiddleware, solverGuard, async (req: any, res: any) => {

  const payload = { ...req.body, userPlan: req.user.plan, userId: req.user.uid };
  try {
    const data = await runSolverWorker('impulse-response', payload);
    
    // Await simulation persistence to guarantee server-authoritative ownership.
    const simulationId = crypto.randomUUID();
    const resultObj = {
      rt60: data.rt60,
      simulatedRt60: data.simulatedRt60,
      gridDims: data.gridDims,
      steps: data.steps,
      actualDurationSec: data.actualDurationSec,
      targetDurationSec: data.targetDurationSec,
      reachedTarget: data.reachedTarget,
      warning: data.warning,
      // In a real app we'd save receiverTrace to object storage if > limits.
      // But we will omit it from Firestore or store it if small enough.
      // For now, if we don't save it, PDF report won't have it unless passed.
      // We'll keep it in memory for the response.
    };
    try {
      const projId = req.body.projectId;
      if (projId) {
        // verify project ownership
        const projDoc = await projectsCollection.doc(projId).get();
        if (!projDoc.exists || projDoc.data().ownerId !== req.user.uid) {
          throw new Error("Invalid or unowned project ID.");
        }
      }
      
      await simulationsCollection.doc(simulationId).set({
        simulationId,
        ownerId: req.user.uid,
        projectId: req.body.projectId || null,
        appVersion: "1.0.0",
        solverVersion: "1.0.0",
        speakerDatabaseVersion: "1.0.0",
        createdAt: Date.now(),
        completedAt: Date.now(),
        status: "completed",
        room: req.body,
        speakers: [req.body.source],
        receivers: [req.body.receiver],
        result: resultObj
      });
    } catch (e) {
      console.error("Failed to save simulation", e);
      return res.status(500).json({ error: "Failed to persist simulation record." });
    }
    
    data.simulationId = simulationId;
    return res.json(data);
  } catch (err: any) {
    console.error("Impulse Response Solver Error:", err);
    try {
      const parsed = JSON.parse(err.message);
      return res.status(422).json(parsed);
    } catch {
      return res.status(500).json({ error: err.message || "Impulse response computation failed." });
    }
  }

});

async function startServer() {
  

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => res.sendFile(path.join(distPath, 'index.html')));
  }

  
  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  const gracefulShutdown = (signal: string) => {
    console.log(`Received ${signal}. Shutting down gracefully...`);
    server.close(() => {
      console.log('HTTP server closed.');
      process.exit(0);
    });
    
    // Force close after 10s
    setTimeout(() => {
      console.error('Could not close connections in time, forcefully shutting down');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));

}

startServer();
