import { Polar } from '@polar-sh/sdk';
type Create = Parameters<Polar['checkouts']['create']>[0];
let obj: Create = {} as any;
