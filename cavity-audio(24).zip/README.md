# Cavity Audio

Cavity Audio is a sophisticated acoustic simulation web application that estimates room modes, impulse responses, and acoustic properties (like RT60, C50, and D50) for various speaker and receiver configurations.

## Architecture
*   **Frontend**: React (Vite), TypeScript, Tailwind CSS, Three.js (for 3D room visualization).
*   **Backend**: Express.js server bundled via ESBuild.
*   **Database**: Firebase Firestore (server-authoritative via Firebase Admin SDK).
*   **Simulations**: Asynchronous FDTD (Finite Difference Time Domain) numerical solver running in isolated Node.js `worker_threads` to prevent event-loop blocking.
*   **Billing**: Polar checkout and webhook integrations.

## Installation & Development
### 1. Requirements
*   Node.js v18+
*   npm

### 2. Environment Setup
Copy `.env.example` to `.env` and fill in the required variables:
*   `GEMINI_API_KEY` - For AI features.
*   `FIREBASE_SERVICE_ACCOUNT` - JSON string for the Firebase Admin SDK.
*   `POLAR_ACCESS_TOKEN` & `POLAR_WEBHOOK_SECRET` - For billing.
*   `SMTP_*` - For sending authentication and report emails.
*   `APP_ORIGIN` - Authoritative URL for Polar webhooks and callbacks.

### 3. Run Locally
```bash
npm ci
npm run dev
```

## Features & Safety Guarantees
*   **Concurrency**: Uses `updatedAt` optimistic concurrency control on Firestore to prevent multiple sessions from overwriting the same project simultaneously.
*   **Signup Abuse Protection**: Tracks IP addresses using a tiered cooldown system (1 min, 5 min, 10 min, 1 hour, 12 hours, 24 hours, 48 hours, 72 hours, up to a permanent ban) to prevent automated signup spam.
*   **Admin Unban**: Authorized admin accounts (by `role === "admin"`) can remove IP bans.
*   **Worker Threads**: Intense numerical wave and impulse response calculations are offloaded to `worker_threads` using a custom FDTD solver.
*   **Limits & Safety**: 
    - Free tier wave solver maximum = 1,000,000 elements.
    - Premium / Lifetime wave solver maximum = 50,000,000 elements.
    - Memory admission protection checks memory requirements before allocating large typed arrays to prevent container OOM.
*   **Billing**: Secure Polar checkout integration with webhook signature verification, product validation, and idempotency.
*   **Report Provenance**: Reports use only data actually available from the database, tied explicitly to the authenticated owner's `simulationId`.

## Solver Limitations
*   **Approximations**: Both Wave and IR solvers use a first-order locally reacting boundary condition (FDTD approximation), not a full impedance boundary model.
*   **Absorption**: Uses standardized reference estimates for absorption coefficients, which approximate actual room behavior.
*   **Truncation Reporting**: The IR solver explicitly reports if execution was truncated before reaching the target temporal decay. The frontend honestly flags incomplete metrics.

## Deployment
Cavity Audio is designed to be deployed as a single containerized application.
```bash
npm run build
npm start
```
This will serve the static React assets and run the Express API on port 3000.
