const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');
const script = `
<script>
window.addEventListener('error', function(event) {
  fetch('/log-error', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: event.message, filename: event.filename, lineno: event.lineno, colno: event.colno, error: event.error ? event.error.stack : null }) });
});
window.addEventListener('unhandledrejection', function(event) {
  fetch('/log-error', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: event.reason ? event.reason.toString() : 'Unhandled Rejection', stack: event.reason && event.reason.stack ? event.reason.stack : null }) });
});
</script>
`;
html = html.replace('<head>', '<head>' + script);
fs.writeFileSync('index.html', html);
