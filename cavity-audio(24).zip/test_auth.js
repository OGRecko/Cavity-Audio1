// Quick check of our auth implementation
const fs = require('fs');
let src = fs.readFileSync('server.ts', 'utf8');

if (src.includes('verifyPassword(password, loggedInUser.passwordHash)')) {
  console.log('PASS: Login verification upgraded');
} else {
  console.log('FAIL: Login verification not found');
}

if (src.includes('hashPassword(password)')) {
  console.log('PASS: Signup hashing upgraded');
} else {
  console.log('FAIL: Signup hashing not found');
}
