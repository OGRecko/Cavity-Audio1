const fs = require('fs');

let serverSrc = fs.readFileSync('server.ts', 'utf8');

// Consolidate adminGuard and adminMiddleware
serverSrc = serverSrc.replace(
/const adminGuardLimiter = authRateLimit\(\{[^}]+\}\);\n\nfunction adminGuard\(req: any, res: any, next: any\) \{\n  if \(req\.user && \(req\.user\.role === 'admin' \|\| req\.user\.emailLower === 'georgesherif2010@gmail\.com' \|\| req\.user\.usernameLower === 'georgesherif2010'\)\) \{\n    next\(\);\n  \} else \{\n    res\.status\(403\)\.json\(\{ error: 'Forbidden' \}\);\n  \}\n\}\n/m,
`const adminGuardLimiter = authRateLimit({
  ipMax: 100,
  windowMs: 15 * 60 * 1000,
  routeName: "admin"
});

function adminGuard(req: any, res: any, next: any) {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ error: 'Forbidden' });
  }
}
`
);

fs.writeFileSync('server.ts', serverSrc);
console.log('patched admin guard');
