# Speaker Audit Report

- Total speakers: 356
- PARTIALLY_VERIFIED: 271
- FULLY_VERIFIED: 5
- LEGACY: 80
- Duplicate IDs: 0
- Duplicate brand/model pairs: 0
- Missing brands: 0
- Missing models: 0
- Missing categories: 0
- Manufacturer-verified sensitivity fields: 10
- Manufacturer-verified sensitivity fields with manufacturer source type: 10
- Legacy sensitivity fields explicitly labeled LEGACY: 80

## Field-level status counts

### sensitivity
- UNAVAILABLE: 266
- MANUFACTURER_VERIFIED: 10
- LEGACY: 80

### frequencyResponse
- MANUFACTURER_VERIFIED: 271
- UNAVAILABLE: 85

### power
- MANUFACTURER_VERIFIED: 276
- UNAVAILABLE: 80

### impedance
- MANUFACTURER_VERIFIED: 276
- UNAVAILABLE: 80

### resonantFreq
- UNAVAILABLE: 346
- MANUFACTURER_VERIFIED: 10

### voiceCoil
- UNAVAILABLE: 346
- MANUFACTURER_VERIFIED: 10

### woofer
- MANUFACTURER_VERIFIED: 276
- UNAVAILABLE: 80

## Round 3 audit (this session)

Re-verified the 6 models flagged in the brief as questionable (Jensen P12N,
Jensen P10R, JL Audio 12W7, Rockford Fosgate Punch P3 12, Kicker CompVR 12,
Pioneer TS-A1670F) via live web search against retailer/manufacturer listings.

- **Jensen P12N / P10R**: already had real jensentone.com spec-sheet URLs
  buried in `notes`. Promoted those URLs into each field's structured
  `source` value so they're traceable without reading free-text notes.
- **JL Audio 12W7**: DB values (86.2 dB / 3\u03a9 / 1000W RMS) match the
  **12W7AE-3** (Anniversary Edition) variant, not the base 12W7-3 (86 dB /
  2000W RMS per third-party spec databases) \u2014 confirmed cross-generation
  ambiguity per item 7. Model field corrected; downgraded from
  MANUFACTURER_VERIFIED to ESTIMATED/RETAILER since only retailer listings
  (not jlaudio.com itself) were retrieved.
- **Rockford Fosgate Punch P3 12**: DB values match the **P3D4-12** (dual
  4\u03a9) variant specifically. Model corrected; downgraded to
  ESTIMATED/RETAILER (retailer corroboration only, not rockfordfosgate.com's
  own spec page).
- **Kicker CompVR 12**: genuinely traceable to kicker.com's own product page
  for the 4\u03a9 variant (model 43CVR124); kept MANUFACTURER_VERIFIED with
  the real URL, and the 2\u03a9 variant (43CVR122, different specs) is now
  called out in the model name so they aren't conflated.
- **Pioneer TS-A1670F**: found a real data-accuracy bug, not just a
  provenance issue \u2014 sensitivity was listed as 89 dB, which multiple
  independent sources confirm belongs to the companion TS-A6960F/A6970F 6x9"
  model, not the TS-A1670F. Corrected to 87 dB (unanimous across every
  retailer spec sheet checked) and downgraded to ESTIMATED/RETAILER pending
  an actual pioneerelectronics.com source.

**Not yet re-verified this round** (flagged for follow-up, left as-is \u2014
no evidence found either way): celestion-v30, celestion-greenback,
celestion-g12h30, eminence-legend. These 4 guitar-speaker entries still
carry a vague `"Manufacturer Specifications"` source string with no URL.
They were not in the brief's explicit "known questionable models" list and
were not independently checked in this pass; they should not be assumed
correct or incorrect without doing so.

Post-fix counts (verified programmatically): 356 total speakers, 0
duplicate IDs, 0 duplicate brand/model pairs, 0 fields with
`status: MANUFACTURER_VERIFIED` and `sourceType: NONE`.
