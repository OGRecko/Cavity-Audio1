import React, { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { useProjectsStore } from '../store/useProjectsStore';
import { Logo } from './Logo';
import { Plus, Search, Folder, Clock, Share2, FileText, ChevronRight, ChevronLeft, Activity, Headphones, FileCode, Users, Menu, X } from 'lucide-react';

export default function Dashboard() {
  const { setView, theme } = useStore();
  const { projects, loading, fetchProjects, migrateLegacyIfNeeded, createProject, switchToProject, renameProject, archiveProject, deleteProject } = useProjectsStore();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [mobileDetailsOpen, setMobileDetailsOpen] = useState(false);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    // Idempotent: copies a pre-existing user's legacy single project into
    // the new multi-project list exactly once, then just fetches normally.
    migrateLegacyIfNeeded().then(() => fetchProjects());
  }, []);

  const selectedProject = projects.find(p => p.id === selectedProjectId) || projects[0] || null;

  const handleOpenProject = async (id: string) => {
    await switchToProject(id);
    setView('editor');
  };

  const handleNewProject = async () => {
    const name = window.prompt('Project name', 'Untitled Project');
    if (name === null) return; // cancelled
    const id = await createProject(name || 'Untitled Project');
    if (id) {
      setView('editor');
    }
  };

  const filteredProjects = projects.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className={`flex flex-1 overflow-hidden font-sans relative ${theme === 'dark' ? 'bg-[#1e1e1e] text-[#e7e7e5]' : 'bg-[#f0f2f5] text-[#111827]'}`}>

      {/* Mobile top bar: hamburger to open nav. Hidden on md+ where the
          sidebar is always visible. */}
      <button
        onClick={() => setMobileNavOpen(true)}
        className={`md:hidden absolute top-3 left-3 z-30 p-2 rounded ${theme === 'dark' ? 'bg-[#2a2b2f] text-white' : 'bg-white text-black shadow'}`}
      >
        <Menu size={18} />
      </button>

      {/* Left Navigation.
          Desktop: static w-64 column, always visible.
          Mobile: slide-over drawer, hidden unless opened, with a backdrop. */}
      {mobileNavOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-black/50" onClick={() => setMobileNavOpen(false)} />
      )}
      <div className={`
        w-64 flex flex-col shrink-0 border-r
        ${theme === 'dark' ? 'border-[#2a2c30] bg-[#1a1b1e]' : 'border-[#e5e7eb] bg-[#ffffff]'}
        fixed md:static inset-y-0 left-0 z-50 md:z-auto
        transform transition-transform duration-200
        ${mobileNavOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0
      `}>
        <div className="flex items-center justify-between px-4 py-3 md:hidden">
          <div className="flex items-center gap-2">
            <Logo className={`w-4 h-4 ${theme === 'dark' ? 'text-white' : 'text-black'}`} />
            <span className={theme === 'dark' ? "text-white text-xs font-bold uppercase tracking-wide" : "text-black text-xs font-bold uppercase tracking-wide"}>Cavity</span>
          </div>
          <button onClick={() => setMobileNavOpen(false)} className={theme === 'dark' ? 'text-[#83868c] hover:text-white' : 'text-[#6b7280] hover:text-black'}>
            <X size={18} />
          </button>
        </div>
        <div className="flex-1 py-4">
          <nav className="space-y-1">
            <NavItem icon={<Folder size={18} />} label="Home" onClick={() => setMobileNavOpen(false)} />
            <NavItem icon={<FileCode size={18} />} label="My projects" active onClick={() => setMobileNavOpen(false)} />
            <NavItem icon={<Users size={18} />} label="Shared with me" onClick={() => setMobileNavOpen(false)} />
            <NavItem icon={<FileText size={18} />} label="Tutorials" onClick={() => setMobileNavOpen(false)} />
            <div className={`my-4 border-t ${theme === 'dark' ? 'border-[#2a2c30]' : 'border-[#e5e7eb]'} mx-4`}></div>
            <NavItem icon={<Activity size={18} />} label="Results" onClick={() => setMobileNavOpen(false)} />
            <NavItem icon={<Headphones size={18} />} label="Auralizations" onClick={() => setMobileNavOpen(false)} />
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className={`flex-1 flex flex-col min-w-0 overflow-y-auto ${theme === 'dark' ? 'bg-[#212224]' : 'bg-[#f7f8f9]'}`}>
        <div className="p-4 pt-16 md:p-8 md:pt-8">
          <div className="flex items-center justify-between gap-4 mb-8 flex-wrap">
            <div className="relative max-w-md flex-1 min-w-[200px]">
              <Search size={18} className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`} />
              <input
                type="text"
                placeholder="Search projects..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full pl-10 pr-4 py-2 border-b ${theme === 'dark' ? 'bg-transparent border-[#404040] focus:border-[#43d9b8] text-white' : 'bg-transparent border-[#d1d5db] focus:border-[#43d9b8] text-black'} outline-none transition-colors`}
              />
            </div>
            <button
              onClick={handleNewProject}
              className="flex items-center gap-1.5 bg-[#43d9b8] text-black px-4 py-2 rounded text-sm font-bold hover:bg-[#3bc2a4] transition-colors shrink-0"
            >
              <Plus size={16} /> New Project
            </button>
          </div>

          <div className={`flex justify-between items-center text-xs font-semibold mb-4 uppercase tracking-wider ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
            <span>Projects</span>
            <span className="hidden sm:inline">Modified ↓</span>
          </div>

          {loading && projects.length === 0 && (
            <div className={`text-sm ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>Loading projects...</div>
          )}

          {!loading && filteredProjects.length === 0 && (
            <div className={`text-sm p-6 text-center rounded-lg border border-dashed ${theme === 'dark' ? 'border-[#2a2c30] text-[#83868c]' : 'border-[#e5e7eb] text-[#6b7280]'}`}>
              {projects.length === 0
                ? "No projects yet — click \"New Project\" to start your first room."
                : "No projects match your search."}
            </div>
          )}

          <div className="space-y-2">
            {filteredProjects.map(project => (
              <div
                key={project.id}
                onClick={() => { setSelectedProjectId(project.id); handleOpenProject(project.id); }}
                className={`flex justify-between items-center p-4 rounded-lg cursor-pointer ${theme === 'dark' ? 'bg-[#2a2b2f] hover:bg-[#34353a]' : 'bg-white hover:bg-[#eef2f6] shadow-sm'} transition-colors group ${selectedProjectId === project.id ? 'ring-2 ring-[#43d9b8]' : ''}`}
              >
                <div className="flex items-center space-x-4 min-w-0">
                  <div className="w-16 h-12 bg-[#b0bec5] rounded flex items-center justify-center relative overflow-hidden shrink-0">
                    <svg viewBox="0 0 100 100" className="w-12 h-12 opacity-80">
                      <path d="M 20,40 L 80,40 L 80,80 L 20,80 Z" fill="rgba(255,255,255,0.2)"/>
                      <path d="M 40,20 L 60,20 L 60,40 L 40,40 Z" fill="rgba(255,255,255,0.2)"/>
                    </svg>
                  </div>
                  <span className={`font-medium truncate ${theme === 'dark' ? 'text-white' : 'text-black'}`}>{project.name}</span>
                </div>
                <div className={`flex items-center space-x-3 sm:space-x-6 text-sm shrink-0 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
                  <span className="hidden sm:inline">{new Date(project.updatedAt).toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                  <button
                    onClick={(e) => { e.stopPropagation(); setSelectedProjectId(project.id); setMobileDetailsOpen(true); }}
                    className="md:hidden p-1"
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Sidebar Details.
          Desktop: static w-80 column, always visible.
          Mobile: slide-over panel from the right, opened via the chevron above. */}
      {mobileDetailsOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-black/50" onClick={() => setMobileDetailsOpen(false)} />
      )}
      <div className={`
        w-80 max-w-[85vw] border-l flex flex-col
        ${theme === 'dark' ? 'border-[#2a2c30] bg-[#1a1b1e]' : 'border-[#e5e7eb] bg-[#ffffff]'}
        fixed md:static inset-y-0 right-0 z-50 md:z-auto
        transform transition-transform duration-200 overflow-y-auto
        ${mobileDetailsOpen ? 'translate-x-0' : 'translate-x-full'} md:translate-x-0
      `}>
        {selectedProject ? (
          <>
            <div className="p-6">
              <div className="flex justify-between items-start mb-6">
                <button
                  onClick={() => setMobileDetailsOpen(false)}
                  className={`md:hidden mr-2 -ml-1 p-1 ${theme === 'dark' ? 'text-[#83868c] hover:text-white' : 'text-[#6b7280] hover:text-black'}`}
                >
                  <ChevronLeft size={18} />
                </button>
                <h2 className={`font-semibold text-lg flex-1 ${theme === 'dark' ? 'text-white' : 'text-black'}`}>{selectedProject.name}</h2>
                <button
                  onClick={() => {
                    const name = window.prompt('Rename project', selectedProject.name);
                    if (name && name.trim()) renameProject(selectedProject.id, name.trim());
                  }}
                  className={`${theme === 'dark' ? 'text-[#83868c] hover:text-white' : 'text-[#6b7280] hover:text-black'}`}
                >⋮</button>
              </div>

              <div className={`aspect-video rounded-lg flex items-center justify-center mb-6 ${theme === 'dark' ? 'bg-[#212224]' : 'bg-[#f3f4f6]'}`}>
                <Folder size={64} className="text-[#e7e7e5]" />
              </div>

              <div className={`space-y-2 text-sm ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
                <div className="flex justify-between">
                  <span>Created: {new Date(selectedProject.createdAt).toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                </div>
                <div className="flex justify-between">
                  <span>Last modified: {new Date(selectedProject.updatedAt).toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                </div>
              </div>
            </div>

            <div className="mt-auto p-6">
              <button
                onClick={() => handleOpenProject(selectedProject.id)}
                className="w-full py-2 px-4 rounded text-sm font-bold bg-[#43d9b8] text-black hover:bg-[#3bc2a4] transition-colors mb-2"
              >
                Open Project
              </button>
              <button
                onClick={() => {
                  if (window.confirm(`Archive "${selectedProject.name}"? You can restore it later — this doesn't delete your data.`)) {
                    archiveProject(selectedProject.id);
                    setSelectedProjectId(null);
                  }
                }}
                className={`w-full py-2 px-4 border rounded text-sm font-medium transition-colors mb-2 ${theme === 'dark' ? 'border-[#404040] text-red-400 hover:bg-red-950/30' : 'border-[#d1d5db] text-red-600 hover:bg-red-50'}`}
              >
                Archive Project
              </button>
              <button
                onClick={() => {
                  if (window.confirm(`Permanently delete "${selectedProject.name}"? This cannot be undone.`)) {
                    deleteProject(selectedProject.id);
                    setSelectedProjectId(null);
                  }
                }}
                className={`w-full py-2 px-4 rounded text-sm font-medium transition-colors ${theme === 'dark' ? 'text-red-500 hover:bg-red-950/50' : 'text-red-700 hover:bg-red-100'}`}
              >
                Delete Permanently
              </button>
            </div>
          </>
        ) : (
          <div className={`p-6 text-sm ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
            Select a project to see details.
          </div>
        )}
      </div>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode; label: string; active?: boolean; onClick?: () => void }) {
  const { theme } = useStore();
  return (
    <div onClick={onClick} className={`flex items-center px-6 py-2 cursor-pointer border-l-2 transition-colors ${
      active 
        ? 'border-[#43d9b8] text-[#43d9b8] font-medium' 
        : `border-transparent ${theme === 'dark' ? 'text-[#83868c] hover:text-white hover:bg-[#202226]' : 'text-[#6b7280] hover:text-black hover:bg-[#f3f4f6]'}`
    }`}>
      <span className="mr-3">{icon}</span>
      <span className="text-sm">{label}</span>
    </div>
  );
}
