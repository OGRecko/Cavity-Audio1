import React, { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { 
  Chart as ChartJS, CategoryScale, LinearScale, BarElement, LineElement, 
  PointElement, Title, Tooltip, Legend
} from 'chart.js';
import { Bar, Line } from 'react-chartjs-2';
import { X, Download, Camera, Search, Maximize, MoveUp, Move, Play } from 'lucide-react';
import { computeRT60, computeSTIProxy, BAND_LABELS } from '../lib/roomAcoustics';
import { computeRealSTI } from '../lib/sti';
import { computeImpulseResponseParams, computePerBandImpulseResponseParams } from '../lib/impulseResponseParams';

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend);

// Parameters not computable from this app's current single-channel,
// non-calibrated solver output. Rather than fabricate plausible-looking
// numbers, these are surfaced as "not yet available" wherever selected.
// G (Strength) needs a calibrated free-field reference measurement at 10m;
// LF (Lateral Fraction) needs a figure-of-eight/lateral microphone signal.
// LJ ("loudness"? / OOP) are not standard ISO 3382 parameters and have no
// defined calculation in this codebase either — same treatment.
const UNAVAILABLE_PARAMS = new Set(['G', 'LF', 'LJ', 'OOP']);

export default function LeftSidebar() {
  const [activeTab, setActiveTab] = useState('parameters');
  const [activePlot, setActivePlot] = useState('IR');
  const {
    activeParam, setActiveParam, theme, simulations, addSimulation, removeSimulation, updateSimulation,
    sources, receivers, isPlaying, setIsPlaying,
    poly, L, W, H, wallMaterial, wallSegMats, floorMaterial, ceilMaterial,
  } = useStore();

  // Real per-band RT60/absorption from the room's actual geometry and
  // materials (src/lib/roomAcoustics.ts) — computed locally, no network
  // round-trip needed since it only depends on state already in the store.
  const rt60Result = React.useMemo(() => computeRT60({
    poly, L, W, H, wallMaterial, wallSegMats, floorMaterial, ceilMaterial,
  }), [poly, L, W, H, wallMaterial, wallSegMats, floorMaterial, ceilMaterial]);

  // Real decay-based metrics come ONLY from the dedicated, long-duration
  // impulse response run — never from the quick preview solver's ~1ms
  // trace, which is fine for visualizing the mesh but physically cannot
  // produce a meaningful RT60/C50/C80/Ts. See useStore's
  // lastImpulseResponseResult vs lastSolverResult for why these are kept
  // separate.
  const lastIrResult = useStore((s: any) => s.lastImpulseResponseResult);
  const irParams = React.useMemo(() => {
    if (!lastIrResult?.receiverTrace?.length) return null;
    return computeImpulseResponseParams(lastIrResult.receiverTrace, lastIrResult.dtEstimate || 0.0001, lastIrResult.rt60);
  }, [lastIrResult]);

  // Real per-band C50/C80/D50/Ts (octave-filtered, ISO 3382-1 style) — used
  // for the per-band bar chart below instead of repeating irParams' single
  // broadband value across every column.
  const irParamsPerBand = React.useMemo(() => {
    if (!lastIrResult?.receiverTrace?.length) return null;
    return computePerBandImpulseResponseParams(lastIrResult.receiverTrace, lastIrResult.dtEstimate || 0.0001, lastIrResult.rt60);
  }, [lastIrResult]);

  // Prefer the real MTF-based STI (computed directly from an actual
  // long-duration impulse response run) when one is available and long
  // enough; otherwise fall back to the RT60-based proxy, which is a
  // formula-based estimate rather than a measurement of the room's actual
  // simulated impulse response. Both are labeled — neither is presented as
  // IEC-compliant.
  const realSti = React.useMemo(() => {
    if (!lastIrResult?.receiverTrace?.length) return null;
    const result = computeRealSTI(lastIrResult.receiverTrace, lastIrResult.dtEstimate || 0.0001);
    return result.sufficient ? result : null;
  }, [lastIrResult]);

  const proxySti = React.useMemo(() => {
    const midRt60 = rt60Result.eyring[BAND_LABELS[3]] ?? rt60Result.sabine[BAND_LABELS[3]] ?? 0.5;
    return computeSTIProxy(midRt60, 25); // 25dB SNR assumption, same default as the report
  }, [rt60Result]);

  const sti = realSti ?? proxySti;
  const stiIsReal = realSti !== null;

  const getBarData = (): (number | null)[] => {
    switch (activeParam) {
      // Real per-band values (octave-filtered per ISO 3382-1) — each band
      // is now a genuinely different number, not the same broadband value
      // repeated across every column. Falls back to null (not the
      // broadband figure) when no IR run has been computed yet, so the UI
      // shows "no data" rather than a misleading flat bar.
      case 'C50': return BAND_LABELS.map(l => irParamsPerBand?.c50[l] ?? null);
      case 'C80': return BAND_LABELS.map(l => irParamsPerBand?.c80[l] ?? null);
      case 'D50': return BAND_LABELS.map(l => irParamsPerBand?.d50[l] ?? null);
      case 'TS': return BAND_LABELS.map(l => irParamsPerBand?.centerTimeMs[l] ?? null);
      case 'SPL': return BAND_LABELS.map(() => null); // not yet calculated: needs a calibrated absolute level reference
      case 'STI': return BAND_LABELS.map(() => sti.value);
      default: return BAND_LABELS.map(() => null); // includes G, LF, LJ, OOP — see UNAVAILABLE_PARAMS
    }
  };

  const barDataRaw = getBarData();
  const hasBarData = barDataRaw.some(v => v != null);

  const barData = {
    labels: BAND_LABELS.map(l => l.replace(' Hz', '')),
    datasets: [{
      label: activeParam,
      data: barDataRaw.map(v => v ?? 0),
      backgroundColor: '#43d9b8',
    }],
  };

  // Real IR/EDC from the solver's actual receiver trace when available;
  // otherwise an empty series rather than randomly-generated placeholder
  // data. Frequency response and Spatial decay have no real data source
  // yet (the solver returns a single receiver trace, not a swept frequency
  // measurement or multiple spatial samples) and are left empty too.
  const getLineData = (): number[] => {
    const trace: number[] = lastIrResult?.receiverTrace || [];
    switch (activePlot) {
      case 'IR':
        return trace;
      case 'IR [dB]':
        return trace.map(v => Math.max(-80, 20 * Math.log10(Math.abs(v) + 0.0001)));
      case 'EDC': {
        // Schroeder backward integration of the real trace's energy — a
        // genuine energy decay curve from actual simulated data, not a
        // fabricated exponential.
        if (trace.length === 0) return [];
        const energy = trace.map(v => v * v);
        const total = energy.reduce((a, b) => a + b, 0);
        if (total <= 0) return trace.map(() => 0);
        let cumulative = 0;
        const remaining = energy.map(e => { cumulative += e; return total - cumulative; });
        return remaining.map(r => 10 * Math.log10(Math.max(r, 1e-9) / total));
      }
      default:
        return []; // Frequency response / Spatial decay: no real data source yet
    }
  };

  const lineDataRaw = getLineData();
  const hasLineData = lineDataRaw.length > 0;
  const dt = lastIrResult?.dtEstimate || 0.0001;

  const lineData = {
    labels: lineDataRaw.map((_, i) => (i * dt * 1000).toFixed(1)),
    datasets: [{
      label: activePlot,
      data: lineDataRaw,
      borderColor: '#43d9b8',
      borderWidth: 1.5,
      pointRadius: 0,
      tension: 0.1,
    }],
  };

  const commonOptions = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false } },
  };

  const barOptions = {
    ...commonOptions,
    scales: {
      x: { grid: { color: theme === 'dark' ? '#2a2c30' : '#e5e7eb' }, ticks: { color: theme === 'dark' ? '#83868c' : '#6b7280', font: { size: 10 } }, title: { display: true, text: 'FREQUENCY [Hz]', color: theme === 'dark' ? '#83868c' : '#6b7280', font: { size: 10 } } },
      y: { grid: { color: theme === 'dark' ? '#2a2c30' : '#e5e7eb' }, ticks: { color: theme === 'dark' ? '#83868c' : '#6b7280', font: { size: 10 } } },
    },
  };

  const lineOptions = {
    ...commonOptions,
    scales: {
      x: { grid: { color: theme === 'dark' ? '#2a2c30' : '#e5e7eb' }, ticks: { color: theme === 'dark' ? '#83868c' : '#6b7280', font: { size: 10 }, maxTicksLimit: 6 }, title: { display: true, text: activePlot === 'Spatial decay' ? 'DISTANCE [m]' : activePlot === 'Frequency response' ? 'FREQUENCY [Hz]' : 'TIME [ms]', color: theme === 'dark' ? '#83868c' : '#6b7280', font: { size: 10 } } },
      y: { grid: { color: theme === 'dark' ? '#2a2c30' : '#e5e7eb' }, ticks: { color: theme === 'dark' ? '#83868c' : '#6b7280', font: { size: 10 } }, title: { display: true, text: activePlot === 'IR' ? 'PRESSURE' : 'LEVEL [dB]', color: theme === 'dark' ? '#83868c' : '#6b7280', font: { size: 10 } } },
    },
  };

  return (
    <div className={`w-full ${theme === 'dark' ? 'bg-[#1a1b1e] text-[#e7e7e5]' : 'bg-[#ffffff] text-[#111827]'} flex flex-col flex-1 shrink-0 min-h-0`}>
      <div className={`flex border-b shrink-0 ${theme === 'dark' ? 'border-[#2a2c30]' : 'border-[#e5e7eb]'}`}>
        <div 
          className={`flex-1 text-center py-4 cursor-pointer border-b-2 text-xs font-semibold tracking-wide transition-colors ${activeTab === 'parameters' ? `border-[#43d9b8] ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-[#111827]'}` : `border-transparent ${theme === 'dark' ? 'text-[#83868c] hover:text-[#e7e7e5]' : 'text-[#6b7280] hover:text-[#111827]'}`}`}
          onClick={() => setActiveTab('parameters')}
        >
          Parameters
        </div>
        <div 
          className={`flex-1 text-center py-4 cursor-pointer border-b-2 text-xs font-semibold tracking-wide transition-colors ${activeTab === 'plots' ? `border-[#43d9b8] ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-[#111827]'}` : `border-transparent ${theme === 'dark' ? 'text-[#83868c] hover:text-[#e7e7e5]' : 'text-[#6b7280] hover:text-[#111827]'}`}`}
          onClick={() => setActiveTab('plots')}
        >
          Plots
        </div>
      </div>

      <div className="flex-[0.55] p-5 flex flex-col overflow-y-auto min-h-0">
        {activeTab === 'parameters' && (
          <>
            <div className="flex justify-between items-center mb-6">
              <span className="text-xs font-bold tracking-wide">Select parameter</span>
              <select className={`${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30] text-[#e7e7e5]' : 'bg-[#f9fafb] border-[#e5e7eb] text-[#111827]'} border text-xs p-1.5 rounded w-32 outline-none`}>
                <option>Source SPL level</option>
              </select>
            </div>
            <div className="flex flex-wrap gap-2 mb-8">
              {['EDT', 'T20', 'T30', 'C50', 'C80', 'D50', 'TS', 'G', 'SPL', 'STI', 'LF'].map(p => (
                <button 
                  key={p} 
                  onClick={() => setActiveParam(p)}
                  disabled={UNAVAILABLE_PARAMS.has(p)}
                  title={UNAVAILABLE_PARAMS.has(p) ? 'Not yet available — requires data this app does not currently produce' : undefined}
                  className={`text-[10px] font-bold px-2 py-1 rounded border ${activeParam === p ? 'bg-[#43d9b8] text-[#0d0e0f] border-[#43d9b8]' : `${theme === 'dark' ? 'border-[#2a2c30] text-[#83868c] hover:border-[#43d9b8] hover:text-[#e7e7e5]' : 'border-[#e5e7eb] text-[#6b7280] hover:border-[#43d9b8] hover:text-[#111827]'} bg-transparent`} ${UNAVAILABLE_PARAMS.has(p) ? 'opacity-40 cursor-not-allowed' : ''}`}>
                  {p}
                </button>
              ))}
            </div>
            <div className="flex-1 relative min-h-[150px] mb-4">
              {UNAVAILABLE_PARAMS.has(activeParam) ? (
                <div className={`absolute inset-0 flex items-center justify-center text-center text-xs px-4 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
                  {activeParam} is not yet available. It requires a calibrated reference measurement or lateral microphone data this simulator doesn't currently produce.
                </div>
              ) : !hasBarData ? (
                <div className={`absolute inset-0 flex items-center justify-center text-center text-xs px-4 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
                  {irParams && !irParams.sufficient
                    ? irParams.limitations
                    : `Click "Compute Real Impulse Response" in the Settings panel to see real ${activeParam} results for this room.`}
                </div>
              ) : (
                <>
                  <Bar data={barData} options={barOptions} />
                  {activeParam === 'STI' && (
                    <div className={`text-[9px] mt-1 px-1 ${theme === 'dark' ? 'text-[#5c5f66]' : 'text-[#9ca3af]'}`}>
                      {stiIsReal
                        ? 'Computed from the actual impulse response (MTF method) — not an IEC 60268-16 certified value. See tooltip.'
                        : 'Estimated from RT60 (no long-duration impulse response run yet) — not a measurement of this room\'s actual simulated response.'}
                    </div>
                  )}
                </>
              )}
            </div>
          </>
        )}

        {activeTab === 'plots' && (
          <>
            <div className="flex justify-between items-center mb-4">
    <div className="text-xs font-bold tracking-wide">Select plot type</div>
    <div className="flex bg-[#141517] rounded border border-[#2a2c30] overflow-hidden">
      <button className="px-2 py-1 text-[9px] font-bold bg-[#202226] text-white">1/3 OCT</button>
      <button className="px-2 py-1 text-[9px] font-bold text-[#83868c] hover:text-white">OCT</button>
    </div>
  </div>
            <div className="flex flex-wrap gap-2 mb-4">
              {['EDC', 'IR', 'IR [dB]', 'Frequency response', 'Spatial decay'].map(p => (
                <button 
                  key={p} 
                  onClick={() => setActivePlot(p)}
                  className={`text-[10px] font-bold px-2 py-1 rounded border ${activePlot === p ? 'bg-[#43d9b8] text-[#0d0e0f] border-[#43d9b8]' : `${theme === 'dark' ? 'border-[#2a2c30] text-[#83868c] hover:border-[#43d9b8] hover:text-[#e7e7e5]' : 'border-[#e5e7eb] text-[#6b7280] hover:border-[#43d9b8] hover:text-[#111827]'} bg-transparent`}`}>
                  {p}
                </button>
              ))}
            </div>
            <div className={`flex justify-end space-x-3 mb-2 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
              <Camera size={14} className="cursor-pointer hover:text-[#43d9b8]" onClick={() => alert('Screenshot captured')} />
              <Search size={14} className="cursor-pointer hover:text-[#43d9b8]" />
              <Move size={14} className="cursor-pointer hover:text-[#43d9b8]" />
              <Maximize size={14} className="cursor-pointer hover:text-[#43d9b8]" />
              <MoveUp size={14} className="cursor-pointer hover:text-[#43d9b8]" />
            </div>
            <div className="flex-1 relative min-h-[150px] mb-4">
              {(activePlot === 'Frequency response' || activePlot === 'Spatial decay') ? (
                <div className={`absolute inset-0 flex items-center justify-center text-center text-xs px-4 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
                  {activePlot} is not yet available — the solver doesn't currently produce {activePlot === 'Frequency response' ? 'a swept frequency measurement' : 'multiple spatial receiver samples'}.
                </div>
              ) : !hasLineData ? (
                <div className={`absolute inset-0 flex items-center justify-center text-center text-xs px-4 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
                  Click "Compute Real Impulse Response" in the Settings panel to see the real {activePlot} for this room.
                </div>
              ) : (
                <Line data={lineData} options={lineOptions} />
              )}
            </div>
          </>
        )}
      </div>
      
      <div className={`flex-[0.45] border-t ${theme === 'dark' ? 'border-[#2a2c30] bg-[#1a1b1e]' : 'border-[#e5e7eb] bg-[#ffffff]'} p-4 overflow-y-auto shrink-0 flex flex-col gap-4 min-h-0`}>
        {simulations.map((sim, index) => (
          <div key={sim.id} className={`${theme === 'dark' ? 'bg-[#141517] border-[#43d9b8]' : 'bg-[#ffffff] border-[#43d9b8]'} border rounded-md p-3 relative shadow-md flex flex-col shrink-0`}>
            <button onClick={(e) => { e.stopPropagation(); removeSimulation(sim.id); }} className={`absolute top-2 right-2 z-50 p-2 cursor-pointer ${theme === 'dark' ? 'text-red-400 hover:text-red-300' : 'text-red-500 hover:text-red-700'}`}><X size={14} /></button>
            <div className={`flex items-center text-xs font-bold ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-[#111827]'} mb-4`}>
              <span className="w-5 h-5 bg-[#4078c0] rounded flex items-center justify-center mr-2 text-white font-bold">{String.fromCharCode(65 + index)}</span>
              <input 
                value={sim.name} 
                onChange={(e) => updateSimulation(sim.id, { name: e.target.value })} 
                className={`bg-transparent outline-none ${theme === 'dark' ? 'text-white' : 'text-black'}`}
              />
            </div>
            
            <div className={`text-[9px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} mb-1 font-semibold tracking-wide`}>SOURCE</div>
            <div className={`flex items-center ${theme === 'dark' ? 'bg-[#202226] border-[#2a2c30] text-white' : 'bg-[#f9fafb] border-[#e5e7eb] text-black'} border p-1 rounded text-xs mb-3`}>
              <div className="w-4 h-4 bg-[#43d9b8] rounded-full flex items-center justify-center mr-2 text-black text-[9px] font-bold">{sources.findIndex(s => s.id === sim.sourceId) + 1 || '?'}</div>
              <select 
                value={sim.sourceId} 
                onChange={(e) => updateSimulation(sim.id, { sourceId: e.target.value })}
                className="bg-transparent text-xs w-full outline-none appearance-none"
              >
                <option value="">Select Source...</option>
                {sources.map((s, i) => <option key={s.id} value={s.id}>{s.brand} {s.model}</option>)}
              </select>
              <span className={`ml-auto text-[10px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} pointer-events-none`}>▼</span>
            </div>

            <div className={`text-[9px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} mb-1 font-semibold tracking-wide`}>RECEIVER</div>
            <div className={`flex items-center ${theme === 'dark' ? 'bg-[#202226] border-[#2a2c30] text-white' : 'bg-[#f9fafb] border-[#e5e7eb] text-black'} border p-1 rounded text-xs mb-3`}>
              <div className="w-4 h-4 bg-[#4fa8d9] rounded-full flex items-center justify-center mr-2 text-white text-[9px] font-bold">{receivers.findIndex(r => r.id === sim.receiverId) + 1 || '?'}</div>
              <select 
                value={sim.receiverId} 
                onChange={(e) => updateSimulation(sim.id, { receiverId: e.target.value })}
                className="bg-transparent text-xs w-full outline-none appearance-none"
              >
                <option value="">Select Receiver...</option>
                {receivers.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
              </select>
              <span className={`ml-auto text-[10px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} pointer-events-none`}>▼</span>
            </div>

            <div className="mt-auto flex justify-between items-center">
              <button onClick={() => alert('Downloading Results PDF')} className={`text-[11px] font-semibold ${theme === 'dark' ? 'text-[#83868c] hover:text-[#e7e7e5]' : 'text-[#6b7280] hover:text-[#111827]'} flex items-center`}>
                <Download size={12} className="mr-2" /> Download
              </button>
              <button 
                onClick={() => {
                  setIsPlaying(!isPlaying);
                }} 
                className="bg-[#43d9b8] text-black px-3 py-1.5 rounded text-xs font-bold flex items-center shadow-lg hover:bg-[#34b396] transition-colors"
              >
                {isPlaying ? <span className="flex items-center"><div className="w-2 h-2 bg-black mr-2"></div> Stop Sound</span> : <span className="flex items-center"><Play size={12} className="mr-1" fill="currentColor" /> Test Sound</span>}
              </button>
            </div>
          </div>
        ))}

        <div 
          onClick={addSimulation}
          className={`shrink-0 h-[100px] border border-dashed ${theme === 'dark' ? 'border-[#2a2c30] text-[#83868c] hover:border-[#43d9b8] hover:text-[#43d9b8]' : 'border-[#e5e7eb] text-[#6b7280] hover:border-[#43d9b8] hover:text-[#43d9b8]'} rounded-md flex items-center justify-center cursor-pointer text-xs font-bold transition-colors`}>
          Add simulation ⊕
        </div>
      </div>
    </div>
  );
}
