import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { useStore } from '../store/useStore';
import { useAuthStore } from '../store/useAuthStore';
import { authClient } from '../lib/authClient';

type Mode = 'login' | 'signup' | 'verify' | 'forgot' | 'reset';

export function AuthModal({ isOpen, onClose, isForced = false }: { isOpen: boolean, onClose: () => void, isForced?: boolean }) {
  const [mode, setMode] = useState<Mode>('login');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [identifier, setIdentifier] = useState(''); // login: email OR username
  const [email, setEmail] = useState(''); // signup: email
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [code, setCode] = useState('');
  const [resetEmail, setResetEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [pendingEmail, setPendingEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const { theme } = useStore();
  const { hydrate, logout, user } = useAuthStore();

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const googleLogin = async () => {
    try {
      setSubmitting(true);
      setError('');
      await authClient.loginWithGoogle();
      await hydrate();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Google login failed.');
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen) return null;

  const switchMode = (m: Mode) => {
    setMode(m);
    setError('');
    setMessage('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setSubmitting(true);
    try {
      if (mode === 'login') {
        const { user: loggedInUser } = await authClient.login({ identifier: identifier.trim(), password, rememberMe });
        await hydrate();
        if (!loggedInUser.emailVerified) {
          await authClient.resendCode(loggedInUser.email);
          setMessage(`We sent a verification code to ${loggedInUser.email}.`);
          setPendingEmail(loggedInUser.email);
          setCountdown(60);
          switchModeKeepMessage('verify');
        } else {
          onClose();
        }
      } else if (mode === 'signup') {
        const res = await authClient.signup({ firstName, lastName, username, email, password });
        await hydrate(); // Hydrates user state so they can verify
        if ((res as any).autoVerified) {
          onClose();
          return;
        }
        
        const signupEmail = res.user?.email || res.pendingEmail || email;
        setPendingEmail(signupEmail);
        setMessage(`We sent a verification code to ${signupEmail}. Check your inbox and spam folder.`);
        setCountdown(60);
        switchModeKeepMessage('verify');
      } else if (mode === 'verify') {
        const { user: verifiedUser } = await authClient.verifyCode(code, pendingEmail || email);
        await hydrate();
        if (verifiedUser?.emailVerified) {
          onClose();
        } else {
          setError('That code didn\'t work. Please check it and try again.');
        }
      } else if (mode === 'forgot') {
        await authClient.forgotPassword(resetEmail.trim());
        setMessage(`If an account exists for ${resetEmail.trim()}, we sent a reset code to it.`);
        setCountdown(60);
        switchModeKeepMessage('reset');
      } else if (mode === 'reset') {
        const { user: resetUser } = await authClient.resetPassword(resetEmail.trim(), code, newPassword);
        await hydrate();
        setMessage('Password reset. You are now logged in.');
        if (resetUser) onClose();
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  // Like switchMode, but doesn't clear the message we just set.
  const switchModeKeepMessage = (m: Mode) => {
    setMode(m);
    setError('');
    setCode('');
  };

  const handleResend = async () => {
    if (countdown > 0) return;
    setError('');
    setMessage('');
    try {
      if (mode === 'reset') {
        await authClient.forgotPassword(resetEmail.trim());
        setMessage(`A new code was sent to your email.`);
        setCountdown(60);
        return;
      }
      await authClient.resendCode(pendingEmail || email);
      setMessage(`A new code was sent to your email.`);
      setCountdown(60);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleCancelVerify = async () => {
    // Let the person back out and try a different account rather than getting stuck.
    await logout();
    switchMode('login');
  };

  const titles: Record<Mode, string> = {
    login: 'Log In to Cavity',
    signup: 'Create an Account',
    verify: 'Verify Your Email',
    forgot: 'Reset Your Password',
    reset: 'Enter Reset Code',
  };

  const inputClass = `w-full p-2.5 text-sm rounded border outline-none transition-colors ${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30] focus:border-[#43d9b8]' : 'bg-gray-50 border-gray-200 focus:border-[#43d9b8]'}`;
  const labelClass = 'block text-xs font-bold mb-1 uppercase tracking-wider';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className={`w-full max-w-md p-6 rounded-lg shadow-2xl relative ${theme === 'dark' ? 'bg-[#1a1b1e] text-[#e7e7e5] border border-[#2a2c30]' : 'bg-white text-gray-900 border border-gray-200'}`}>
        {!isForced && mode !== 'verify' && (
          <button onClick={onClose} className={`absolute top-4 right-4 p-1 rounded hover:bg-black/10 ${theme === 'dark' ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-black'}`}>
            <X size={20} />
          </button>
        )}

        <h2 className="text-xl font-bold mb-6 text-center">{titles[mode]}</h2>

        {error && <div className="mb-4 p-3 bg-red-500/10 border border-red-500/50 text-red-500 text-sm rounded">{error}</div>}
        {message && <div className="mb-4 p-3 bg-[#43d9b8]/10 border border-[#43d9b8]/50 text-[#43d9b8] text-sm rounded">{message}</div>}

        {mode === 'forgot' ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="text-center text-sm mb-4">
              Enter your account email and we'll send you a code to reset your password.
            </div>
            <div>
              <label className={labelClass}>Email Address</label>
              <input
                type="email"
                required
                autoFocus
                value={resetEmail}
                onChange={e => setResetEmail(e.target.value)}
                className={inputClass}
              />
            </div>
            <button type="submit" disabled={submitting || !resetEmail} className="w-full py-2.5 rounded bg-[#43d9b8] hover:bg-[#3bc2a4] disabled:opacity-50 text-black font-bold text-sm transition-colors">
              {submitting ? 'Sending…' : 'Send Reset Code'}
            </button>
            <div className="text-center text-sm pt-1">
              <button type="button" onClick={() => switchMode('login')} className={theme === 'dark' ? 'text-gray-400 hover:underline' : 'text-gray-500 hover:underline'}>
                Back to login
              </button>
            </div>
          </form>
        ) : mode === 'reset' ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="text-center text-sm mb-4">
              Enter the code we sent to {resetEmail || 'your email'}, and choose a new password.
            </div>
            <div>
              <label className={labelClass}>Reset Code</label>
              <input
                type="text"
                required
                autoFocus
                value={code}
                onChange={e => setCode(e.target.value.toUpperCase())}
                maxLength={8}
                className={`${inputClass} text-center tracking-[0.3em] font-mono text-lg`}
              />
            </div>
            <div>
              <label className={labelClass}>New Password</label>
              <input
                type="password"
                required
                minLength={6}
                value={newPassword}
                onChange={e => setNewPassword(e.target.value)}
                className={inputClass}
              />
            </div>
            <button type="submit" disabled={submitting || !code || !newPassword} className="w-full py-2.5 rounded bg-[#43d9b8] hover:bg-[#3bc2a4] disabled:opacity-50 text-black font-bold text-sm transition-colors">
              {submitting ? 'Resetting…' : 'Reset Password'}
            </button>
            <div className="flex items-center justify-between text-sm pt-1">
              <button type="button" onClick={() => switchMode('login')} className={theme === 'dark' ? 'text-gray-400 hover:underline' : 'text-gray-500 hover:underline'}>
                Back to login
              </button>
              <button type="button" onClick={handleResend} disabled={countdown > 0} className="text-[#43d9b8] font-bold hover:underline disabled:opacity-50 disabled:no-underline">
                {countdown > 0 ? `Resend code in ${countdown}s` : 'Resend code'}
              </button>
            </div>
          </form>
        ) : mode === 'verify' ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="text-center text-sm mb-4">
              Enter the 6-character code we sent to {pendingEmail || 'your email'}.
            </div>
            <div>
              <label className={labelClass}>Verification Code</label>
              <input
                type="text"
                required
                autoFocus
                value={code}
                onChange={e => setCode(e.target.value.toUpperCase())}
                maxLength={8}
                className={`${inputClass} text-center tracking-[0.3em] font-mono text-lg`}
              />
            </div>
            <button type="submit" disabled={submitting || !code} className="w-full py-2.5 rounded bg-[#43d9b8] hover:bg-[#3bc2a4] disabled:opacity-50 text-black font-bold text-sm transition-colors">
              {submitting ? 'Verifying…' : 'Verify Email'}
            </button>
            <div className="flex items-center justify-between text-sm pt-1">
              <button type="button" onClick={handleCancelVerify} className={theme === 'dark' ? 'text-gray-400 hover:underline' : 'text-gray-500 hover:underline'}>
                Use a different account
              </button>
              <button type="button" onClick={handleResend} disabled={countdown > 0} className="text-[#43d9b8] font-bold hover:underline disabled:opacity-50 disabled:no-underline">
                {countdown > 0 ? `Resend code in ${countdown}s` : 'Resend code'}
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>First Name</label>
                  <input type="text" required value={firstName} onChange={e => setFirstName(e.target.value)} className={inputClass} />
                </div>
                <div>
                  <label className={labelClass}>Last Name</label>
                  <input type="text" required value={lastName} onChange={e => setLastName(e.target.value)} className={inputClass} />
                </div>
              </div>
            )}

            {mode === 'signup' && (
              <div>
                <label className={labelClass}>Username</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  pattern="[a-zA-Z0-9_]{6,20}"
                  title="6-20 characters: letters, numbers, or underscores"
                  className={inputClass}
                />
              </div>
            )}

            {mode === 'login' ? (
              <div>
                <label className={labelClass}>Email or Username</label>
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={e => setIdentifier(e.target.value)}
                  className={inputClass}
                />
              </div>
            ) : (
              <div>
                <label className={labelClass}>Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className={inputClass}
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-bold mb-1 uppercase tracking-wider">Password</label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={e => setPassword(e.target.value)}
                className={inputClass}
              />
            </div>

            
            {mode === 'login' && (
              <div className="flex items-center justify-between mt-2">
                <div className="flex items-center space-x-2">
                  <input 
                    type="checkbox" 
                    id="rememberMe" 
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded border-gray-600 bg-transparent text-[#43d9b8] focus:ring-[#43d9b8] focus:ring-offset-0"
                  />
                  <label htmlFor="rememberMe" className={theme === 'dark' ? 'text-gray-400 text-sm' : 'text-gray-600 text-sm'}>
                    Remember me
                  </label>
                </div>
                <button
                  type="button"
                  onClick={() => { setResetEmail(identifier.includes('@') ? identifier : ''); switchMode('forgot'); }}
                  className="text-[#43d9b8] text-sm font-bold hover:underline"
                >
                  Forgot password?
                </button>
              </div>
            )}
            <button type="submit" disabled={submitting} className="w-full py-2.5 rounded bg-[#43d9b8] hover:bg-[#3bc2a4] disabled:opacity-50 text-black font-bold text-sm transition-colors mt-2">

              {submitting ? 'Please wait…' : mode === 'login' ? 'Log In' : 'Sign Up'}
            </button>
            <div className="flex items-center gap-2 text-sm text-gray-500 py-2">
              <div className="flex-1 h-px bg-gray-200 dark:bg-[#2a2c30]"></div>
              <span className="uppercase text-[10px] tracking-widest font-bold">Or</span>
              <div className="flex-1 h-px bg-gray-200 dark:bg-[#2a2c30]"></div>
            </div>
            <button
              type="button"
              onClick={() => googleLogin()}
              disabled={submitting}
              className="w-full py-2.5 rounded border border-gray-200 dark:border-[#2a2c30] disabled:opacity-50 disabled:cursor-not-allowed font-bold text-sm flex items-center justify-center gap-2 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
            >
              <svg viewBox="0 0 24 24" width="18" height="18"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/><path d="M1 1h22v22H1z" fill="none"/></svg>
              Continue with Google
            </button>
          </form>
        )}

        {mode !== 'verify' && mode !== 'forgot' && mode !== 'reset' && (
          <div className="mt-6 text-center text-sm flex flex-col gap-2">
            {mode === 'signup' && (
              <div>
                <span className={theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}>Already have an account? </span>
                <button onClick={() => switchMode('login')} className="text-[#43d9b8] font-bold hover:underline">Log in</button>
              </div>
            )}
            {mode === 'login' && (
              <div>
                <span className={theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}>Don't have an account? </span>
                <button onClick={() => switchMode('signup')} className="text-[#43d9b8] font-bold hover:underline">Sign up for free</button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
