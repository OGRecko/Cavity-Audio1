import { useEffect, useMemo, useRef, useState } from "react";
import { Search, Volume2, Zap, Calendar, Radio } from "lucide-react";
import { buildSpeakerChain, SpeakerSpec, SpeakerAudioChain } from "../lib/speakerDSP";
import { SPEAKER_SPECS } from "../lib/speakers";

// The picker's detail view/audition assumes full driver/frequency/power
// specs, so it only lists specs-verified entries (not the legacy,
// specs-incomplete ones carried over for the plain sidebar dropdown).
const speakerData = SPEAKER_SPECS.filter(s => s.overallStatus !== "LEGACY");

const speakers = speakerData as SpeakerSpec[];

const CATEGORIES = [
  "all",
  "studio-monitor",
  "floor-standing",
  "bookshelf",
  "pa",
  "subwoofer",
  "ceiling",
  "in-wall",
  "portable",
  "guitar-cab",
  "car-audio",
  "soundbar",
  "smart-speaker",
] as const;

const CATEGORY_LABELS: Record<string, string> = {
  all: "All",
  "studio-monitor": "Studio Monitor",
  "floor-standing": "Floor-standing",
  bookshelf: "Bookshelf",
  pa: "PA / Live Sound",
  subwoofer: "Subwoofer",
  ceiling: "Ceiling",
  "in-wall": "In-wall",
  portable: "Portable",
  "guitar-cab": "Guitar Cab",
  "car-audio": "Car Audio",
  soundbar: "Soundbar",
  "smart-speaker": "Smart Speaker",
};

export default function SpeakerPicker({ onSelect }: { onSelect?: (spec: SpeakerSpec) => void } = {}) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [era, setEra] = useState<"all" | "vintage" | "modern">("all");
  const [selected, setSelected] = useState<SpeakerSpec | null>(null);
  const [playing, setPlaying] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const chainRef = useRef<SpeakerAudioChain | null>(null);
  const oscRef = useRef<OscillatorNode | null>(null);
  const noiseRef = useRef<AudioBufferSourceNode | null>(null);

  const filtered = useMemo(() => {
    return speakers.filter((s) => {
      const matchesQuery =
        query.trim() === "" ||
        `${s.brand} ${s.model}`.toLowerCase().includes(query.toLowerCase());
      const matchesCategory = category === "all" || s.category === category;
      const matchesEra =
        era === "all" ||
        (era === "vintage" && s.year < 1990) ||
        (era === "modern" && s.year >= 1990);
      return matchesQuery && matchesCategory && matchesEra;
    });
  }, [query, category, era]);

  useEffect(() => {
    return () => {
      stopAudition();
      audioCtxRef.current?.close();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function ensureContext(): AudioContext {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new AudioContext();
    }
    return audioCtxRef.current;
  }

  function stopAudition() {
    oscRef.current?.stop();
    oscRef.current?.disconnect();
    oscRef.current = null;
    noiseRef.current?.stop();
    noiseRef.current?.disconnect();
    noiseRef.current = null;
    chainRef.current?.dispose();
    chainRef.current = null;
    setPlaying(false);
  }

  function auditionSpeaker(spec: SpeakerSpec) {
    stopAudition();
    const ctx = ensureContext();
    const chain = buildSpeakerChain(ctx, spec);
    chainRef.current = chain;
    chain.output.connect(ctx.destination);

    // Pink-ish noise burst through the chain — reveals the frequency
    // shaping much more clearly than a single tone.
    const bufferSize = 2 * ctx.sampleRate;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99765 * b0 + white * 0.0990460;
      b1 = 0.96300 * b1 + white * 0.2965164;
      b2 = 0.57000 * b2 + white * 1.0526913;
      data[i] = (b0 + b1 + b2 + white * 0.1848) * 0.15;
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    noise.loop = true;
    noise.connect(chain.input);
    noise.start();
    noiseRef.current = noise;

    setPlaying(true);
  }

  return (
    <div className="w-full h-full bg-[#0a0a0c] text-white flex flex-col">
      {/* Header */}
      <div className="border-b border-white/10 p-4 flex items-center gap-3">
        <Volume2 className="w-5 h-5" style={{ color: "#43d9b8" }} />
        <h2 className="font-bold text-lg">Speaker Library</h2>
        <span className="text-white/40 text-sm">{speakers.length} real models</span>
      </div>

      {/* Filters */}
      <div className="p-4 border-b border-white/10 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search brand or model..."
            className="w-full bg-white/5 border border-white/10 rounded-full pl-9 pr-4 py-2 text-sm outline-none focus:border-[#43d9b8]/50 transition-colors"
          />
        </div>

        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${
                category === c
                  ? "bg-[#43d9b8] text-black"
                  : "bg-white/5 hover:bg-white/10 text-white/70"
              }`}
            >
              {CATEGORY_LABELS[c]}
            </button>
          ))}
        </div>

        <div className="flex gap-2">
          {(["all", "vintage", "modern"] as const).map((e) => (
            <button
              key={e}
              onClick={() => setEra(e)}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-colors flex items-center gap-1 ${
                era === e
                  ? "bg-white/20 text-white"
                  : "bg-white/5 hover:bg-white/10 text-white/50"
              }`}
            >
              <Calendar className="w-3 h-3" />
              {e === "all" ? "All years" : e === "vintage" ? "1950–1989" : "1990–now"}
            </button>
          ))}
        </div>
      </div>

      {/* List + detail */}
      <div className="flex-1 flex overflow-hidden">
        <div className="w-1/2 overflow-y-auto border-r border-white/10">
          {filtered.map((s) => (
            <button
              key={s.id}
              onClick={() => setSelected(s)}
              className={`w-full text-left p-3 border-b border-white/5 hover:bg-white/5 transition-colors ${
                selected?.id === s.id ? "bg-white/10" : ""
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm">
                  {s.brand} {s.model}
                </span>
                <span className="text-xs text-white/40">{s.year}</span>
              </div>
              <span className="text-xs text-white/50">{CATEGORY_LABELS[s.category]}</span>
            </button>
          ))}
          {filtered.length === 0 && (
            <div className="p-6 text-center text-white/40 text-sm">
              No speakers match those filters.
            </div>
          )}
        </div>

        <div className="w-1/2 p-4 overflow-y-auto">
          {selected ? (
            <div className="space-y-4">
              <div>
                <h3 className="text-xl font-bold flex items-center gap-2">
                  {selected.brand} {selected.model}
                  {selected.overallStatus && (
                    <span className={`text-[9px] uppercase tracking-wider px-2 py-0.5 rounded-full border ${selected.overallStatus.includes('VERIFIED') ? 'border-[#43d9b8]/50 text-[#43d9b8] bg-[#43d9b8]/10' : 'border-amber-500/50 text-amber-400 bg-amber-500/10'}`}>
                      {selected.overallStatus}
                    </span>
                  )}
                </h3>
                <p className="text-white/50 text-sm">{selected.notes}</p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="bg-white/5 rounded-lg p-2 col-span-2 border border-orange-500/30">
  <div className="text-orange-400 text-[10px] uppercase font-bold tracking-wider mb-1">Speaker Response Data</div>
  <div className="text-white/70 text-xs">
    Verified frequency response curve unavailable — neutral approximation used.
  </div>
</div>
                <Spec label="Category" value={CATEGORY_LABELS[selected.category]} />
                <Spec label="Year" value={String(selected.year)} />
                {selected.category === "guitar-cab" || selected.category === "car-audio" ? (
                  <>
                    <Spec label="Resonant Freq (Fs)" value={`${selected.resonantFreq?.value ?? "—"}Hz`} />
                    <div className="bg-white/5 rounded-lg p-2 col-span-2">
  <div className="text-white/40 text-xs">Sensitivity</div>
  <div className="font-bold">
    {selected.sensitivity?.value ? `${selected.sensitivity?.value}dB @ 1W/1m` : 'N/A'}
  </div>
  <div className="text-[10px] text-white/50 mt-1">
    {/* Same distinction as speakers.ts's sensitivitySource: a truthy value
        doesn't by itself mean manufacturer-sourced — legacy entries carry a
        real numeric value with status 'LEGACY' (no source/sourceType).
        Currently unreachable with real data (no legacy entry falls into
        guitar-cab/car-audio, the only categories that render this block),
        but the label should stay accurate if that ever changes. */}
    {selected.sensitivity?.value
      ? (selected.sensitivity?.status === 'LEGACY' ? 'Legacy entry — unverified' : 'Manufacturer specification')
      : 'Unavailable'}
  </div>
</div>
                    <Spec label="Voice Coil" value={`${selected.voiceCoil?.value ?? "—"}"`} />
                  </>
                ) : (
                  <Spec
                    label="Frequency Range"
                    value={`${selected.frequencyResponse?.low_hz}Hz – ${((selected.frequencyResponse?.high_hz || 0) / 1000).toFixed(1)}kHz`}
                  />
                )}
                <Spec label="Power" value={`${selected.power?.value}W`} />
                <Spec
                  label="Driver"
                  value={selected.panel ? "Planar/electrostatic panel" : `${selected.woofer?.value}" woofer × ${selected.driverCount}`}
                />
                <Spec
                  label="Type"
                  value={selected.active ? "Active (powered)" : `Passive, ${selected.impedance?.value}Ω`}
                />
              </div>

              <button
                onClick={() =>
                  playing && chainRef.current
                    ? stopAudition()
                    : auditionSpeaker(selected)
                }
                className="w-full flex items-center justify-center gap-2 py-3 rounded-full font-bold transition-colors"
                style={{
                  backgroundColor: playing ? "transparent" : "#43d9b8",
                  color: playing ? "#43d9b8" : "black",
                  border: playing ? "1px solid #43d9b8" : "none",
                }}
              >
                {playing ? <Radio className="w-4 h-4 animate-pulse" /> : <Zap className="w-4 h-4" />}
                {playing ? "Stop Audition" : "Audition This Speaker"}
              </button>
              <p className="text-xs text-white/30 text-center">
                Plays shaped pink noise through a live filter chain derived from this
                speaker's actual specs — not a sample or preset.
              </p>

              {onSelect && (
                <button
                  onClick={() => onSelect(selected)}
                  className="w-full py-2 rounded-full font-semibold text-xs border border-white/20 text-white/80 hover:border-[#43d9b8] hover:text-[#43d9b8] transition-colors"
                >
                  Use as Audio Source
                </button>
              )}
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-white/30 text-sm">
              Select a speaker to see specs and audition its sound.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Spec({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-white/5 rounded-lg p-2">
      <div className="text-white/40 text-xs">{label}</div>
      <div className="font-bold">{value}</div>
    </div>
  );
}
