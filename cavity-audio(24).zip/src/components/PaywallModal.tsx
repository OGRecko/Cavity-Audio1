import React, { useState } from 'react';
import { useAuthStore } from '../store/useAuthStore';
import { X, Check } from 'lucide-react';
import { useStore } from '../store/useStore';

export function PaywallModal({ isOpen, onClose, isForced = false }: { isOpen: boolean, onClose: () => void, isForced?: boolean }) {
  const { theme } = useStore();
  const { subscriptionData } = useAuthStore();
  const [loading, setLoading] = useState(false);
  const [promoCode, setPromoCode] = useState('');
  const [promoError, setPromoError] = useState('');
  const [promoSuccess, setPromoSuccess] = useState('');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');

  const handleRedeem = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setPromoError('');
    setPromoSuccess('');
    
    try {
      const res = await fetch('/api/redeem', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: promoCode })
      });
      
      const data = await res.json();
      if (data.error) {
        setPromoError(data.error);
        setLoading(false);
      } else {
        setPromoSuccess("Code redeemed successfully! Lifetime access unlocked.");
        setTimeout(() => {
          window.location.reload();
        }, 1500);
      }
    } catch (err: any) {
      setPromoError(err.message);
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const handleSubscribe = async (planType: 'standard' | 'premium') => {
    setLoading(true);
    try {
      let priceId;
      if (planType === 'standard') {
        priceId = billingCycle === 'monthly' 
          ? (import.meta as any).env.VITE_POLAR_STANDARD_MONTHLY_PRODUCT_ID 
          : (import.meta as any).env.VITE_POLAR_STANDARD_ANNUAL_PRODUCT_ID;
      } else {
        priceId = billingCycle === 'monthly' 
          ? (import.meta as any).env.VITE_POLAR_PREMIUM_MONTHLY_PRODUCT_ID 
          : (import.meta as any).env.VITE_POLAR_PREMIUM_ANNUAL_PRODUCT_ID;
      }

      if (!priceId) {
        // Fail clearly here rather than silently substituting a fake
        // product ID: Polar's API would just reject that with its own
        // (confusing, unbranded) error, and the person clicking "Subscribe"
        // gets no useful indication that this is a configuration problem,
        // not something wrong on their end.
        alert("Pricing isn't configured for this plan yet. Please contact cavityaudio@outlook.com.");
        setLoading(false);
        return;
      }

      const res = await fetch('/api/checkout', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ priceId, origin: window.location.origin })
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else if (data.error) {
        alert("Checkout Error: " + data.error);
        setLoading(false);
      } else {
        alert("Failed to create checkout session.");
        setLoading(false);
      }
    } catch (err) {
      console.error(err);
      setLoading(false);
    }
  };

  const handleStartTrial = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/auth/start-trial', { method: 'POST', credentials: 'include' });
      const data = await res.json();
      if (data.success) {
        window.location.reload();
      } else {
        alert(data.error);
        setLoading(false);
      }
    } catch (e: any) {
      alert(e.message);
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className={`w-full max-w-2xl p-8 rounded-xl shadow-2xl relative my-auto ${theme === 'dark' ? 'bg-[#1a1b1e] text-[#e7e7e5] border border-[#2a2c30]' : 'bg-white text-gray-900 border border-gray-200'}`}>
        {!isForced && (
          <button onClick={onClose} className={`absolute top-4 right-4 p-1 rounded hover:bg-black/10 ${theme === 'dark' ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-black'}`}>
            <X size={20} />
          </button>
        )}
        
        <div className="text-center max-w-md mx-auto mb-10 mt-4">
          <h2 className="text-3xl font-bold mb-3">Unlock Cavity Pro</h2>
          <p className={`text-sm ${theme === 'dark' ? 'text-[#83868c]' : 'text-gray-500'}`}>
            {subscriptionData?.subscriptionStatus === 'none' 
              ? "Start your 15-day free trial or subscribe to continue saving and simulating acoustic environments." 
              : (isForced ? "Your 15-day free trial has expired. Subscribe to continue saving and simulating acoustic environments." : "Upgrade to Pro to unlock unlimited projects, advanced materials, and premium support. Contact cavityaudio@outlook.com for help.")}
          </p>
        </div>
        
        {subscriptionData?.subscriptionStatus === 'none' && (
          <div className="mb-8 flex justify-center">
            <button 
              onClick={handleStartTrial}
              disabled={loading}
              className="py-4 px-8 rounded-full bg-gradient-to-r from-[#43d9b8] to-[#25a98d] text-black font-bold text-lg shadow-lg hover:scale-105 transition-transform disabled:opacity-50 disabled:hover:scale-100"
            >
              Start 15-Day Free Trial
            </button>
          </div>
        )}
        
                {/* Toggle */}
        <div className="flex justify-center mb-8">
          <div className={`flex p-1 rounded-lg ${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30]' : 'bg-gray-100 border-gray-200'} border`}>
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-6 py-2 rounded-md text-sm font-semibold transition-all ${billingCycle === 'monthly' ? (theme === 'dark' ? 'bg-[#2a2c30] text-white shadow' : 'bg-white text-black shadow-sm') : (theme === 'dark' ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-black')}`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle('annual')}
              className={`px-6 py-2 rounded-md text-sm font-semibold transition-all ${billingCycle === 'annual' ? (theme === 'dark' ? 'bg-[#2a2c30] text-white shadow' : 'bg-white text-black shadow-sm') : (theme === 'dark' ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-black')}`}
            >
              Annually <span className="text-[#43d9b8] ml-1">(-30%)</span>
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Standard */}
          <div className={`p-6 rounded-lg border-2 ${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30]' : 'bg-gray-50 border-gray-200'} flex flex-col`}>
            <h3 className="text-lg font-bold mb-2">Standard</h3>
            <div className="text-3xl font-bold mb-2">{billingCycle === 'monthly' ? '$100' : '$70'}<span className="text-sm font-normal text-gray-500"> /mo <span className="text-xs tracking-tight">(excl. tax)</span></span></div>
            {billingCycle === 'annual' && <div className="text-xs text-[#43d9b8] font-semibold mb-4">Billed annually at $840</div>}
            {billingCycle === 'monthly' && <div className="text-xs text-transparent mb-4 select-none" aria-hidden="true">Placeholder</div>}
            
            <ul className="space-y-3 mb-6 flex-1 mt-2">
              <li className="flex text-sm items-start gap-2"><Check size={16} className="text-[#43d9b8] mt-0.5 shrink-0" /> Geometrical acoustics solver</li>
              <li className="flex text-sm items-start gap-2"><Check size={16} className="text-[#43d9b8] mt-0.5 shrink-0" /> Wave solver up to 355 Hz</li>
              <li className="flex text-sm items-start gap-2"><Check size={16} className="text-[#43d9b8] mt-0.5 shrink-0" /> 1M mesh elements (~200k m³)</li>
            </ul>
            <button 
              disabled={loading}
              onClick={() => handleSubscribe('standard')}
              className="w-full py-3 rounded-lg border-2 border-[#43d9b8] text-[#43d9b8] font-bold hover:bg-[#43d9b8] hover:text-black transition-colors"
            >
              Subscribe Standard
            </button>
          </div>
          
          {/* Premium */}
          <div className={`p-6 rounded-lg border-2 border-[#43d9b8] ${theme === 'dark' ? 'bg-[#141517]' : 'bg-[#f0fcf9]'} flex flex-col relative`}>
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#43d9b8] text-black text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-full">
              Best Value
            </div>
            <h3 className="text-lg font-bold mb-2">Premium</h3>
            <div className="flex items-end gap-2 mb-1">
              <div className="text-3xl font-bold">{billingCycle === 'monthly' ? '$200' : '$140'}<span className="text-sm font-normal text-gray-500"> /mo <span className="text-xs tracking-tight">(excl. tax)</span></span></div>
              {billingCycle === 'annual' && <div className="text-sm text-gray-500 line-through mb-1">$200</div>}
            </div>
            {billingCycle === 'annual' && <div className="text-xs text-[#43d9b8] font-semibold mb-4">Billed annually at $1,680</div>}
            {billingCycle === 'monthly' && <div className="text-xs text-transparent mb-4 select-none" aria-hidden="true">Placeholder</div>}
            
            <ul className="space-y-3 mb-6 flex-1 mt-2">
              <li className="flex text-sm items-start gap-2"><Check size={16} className="text-[#43d9b8] mt-0.5 shrink-0" /> Everything in Standard</li>
              <li className="flex text-sm items-start gap-2"><Check size={16} className="text-[#43d9b8] mt-0.5 shrink-0" /> Wave solver up to 2840 Hz</li>
              <li className="flex text-sm items-start gap-2"><Check size={16} className="text-[#43d9b8] mt-0.5 shrink-0" /> 50 million mesh elements</li>
            </ul>
            <button 
              disabled={loading}
              onClick={() => handleSubscribe('premium')}
              className="w-full py-3 rounded-lg bg-[#43d9b8] text-black font-bold hover:bg-[#3bc2a4] transition-colors"
            >
              Subscribe Premium
            </button>
          </div>
        </div>
        
        <div className="mt-8 text-center text-xs text-gray-500 max-w-lg mx-auto space-y-2">
          <p>Local taxes and currency conversion are calculated dynamically at checkout based on your country.</p>
          <p>You will be redirected to our secure payment processor.</p>
        </div>

        <div className={`mt-8 pt-6 border-t ${theme === 'dark' ? 'border-[#2a2c30]' : 'border-gray-200'} text-center`}>
          <p className="text-sm font-semibold mb-3">Promo Code</p>
          <form onSubmit={handleRedeem} className="flex max-w-sm mx-auto items-center gap-2">
            <input 
              type="text"
              value={promoCode}
              onChange={e => setPromoCode(e.target.value)}
              placeholder="Enter code..."
              className={`flex-1 p-2 text-sm rounded border outline-none transition-colors ${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30] focus:border-[#43d9b8]' : 'bg-gray-50 border-gray-200 focus:border-[#43d9b8]'}`}
            />
            <button 
              type="submit" 
              disabled={loading || !promoCode.trim()}
              className="bg-[#43d9b8] text-black px-4 py-2 rounded text-sm font-bold disabled:opacity-50"
            >
              Redeem
            </button>
          </form>
          {promoError && <p className="text-red-500 text-xs mt-2">{promoError}</p>}
          {promoSuccess && <p className="text-[#43d9b8] text-xs mt-2">{promoSuccess}</p>}
        </div>
      </div>
    </div>
  );
}
