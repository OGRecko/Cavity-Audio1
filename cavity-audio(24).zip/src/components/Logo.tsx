import React from 'react';

export function Logo({ className, ...props }: React.SVGProps<SVGSVGElement>) {
  return (
    <svg 
      viewBox="0 0 512 512" 
      xmlns="http://www.w3.org/2000/svg" 
      className={className} 
      {...props}
    >
      {/* The C shape */}
      <path 
        d="M 366 156 A 140 140 0 1 0 366 356" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="70" 
        strokeLinecap="butt" 
      />
      {/* The Waves */}
      <g stroke="#1C75FF" strokeWidth="26" strokeLinecap="round">
        <line x1="226" y1="196" x2="226" y2="316" />
        <line x1="271" y1="156" x2="271" y2="356" />
        <line x1="316" y1="116" x2="316" y2="396" />
        <line x1="361" y1="156" x2="361" y2="356" />
        <line x1="406" y1="196" x2="406" y2="316" />
      </g>
    </svg>
  );
}
