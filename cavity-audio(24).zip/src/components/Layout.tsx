import React, { useEffect, useState } from 'react';
import { useStore } from '../store/useStore';
import { useAuthStore } from '../store/useAuthStore';
import { useProjectsStore } from '../store/useProjectsStore';
import { AuthModal } from './AuthModal';
import { PaywallModal } from './PaywallModal';
import RightSidebar from './RightSidebar';
import Mixer from './Mixer';
import ThreeView from './ThreeView';
import Dashboard from './Dashboard';
import { Logo } from './Logo';
import { BarChart2, Share2, Plus, Box, Rotate3D, Activity, Save, Download, Sun, Moon, Home, PenTool, LogOut, User, Play, Pause } from 'lucide-react';
import { audioEngine } from '../lib/audioEngine';

function FolderIcon(props: any) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
    </svg>
  );
}

export default function Layout() {
  const { sources, receivers, L, W, H, floorMaterial, ceilMaterial, audioSourceType, poly, wallSegMats, wallMaterial, wallOpenings, view, setView, roomName, projectName, setProjectName,  activeReceiverId, setActiveReceiverId, saveProject, loadProject, newProject, theme, setTheme, viewMode, setViewMode, showMixer, setShowMixer, undo, redo, past, future, isPlaying, setIsPlaying } = useStore();
  const { user, subscriptionData, loading, needsVerification, logout } = useAuthStore();
  
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showPaywallModal, setShowPaywallModal] = useState(false);
  
  const hasFdtdIR = !!useStore((state) => state.fdtdImpulseBuffer);
  const trialExpired = subscriptionData?.trialEndsAt
    ? (subscriptionData.trialEndsAt < Date.now())
    : false;
    
  const isLocked = !loading && user && (subscriptionData?.subscriptionStatus === 'none' || (trialExpired && subscriptionData?.subscriptionStatus !== 'active'));
  const isAuthForced = !loading && (!user || needsVerification);
  
  
  useEffect(() => {
    if (isPlaying) {
      const activeReceiver = receivers.find(r => r.id === activeReceiverId) || receivers[0];
      audioEngine.play(sources, activeReceiver, L, W, audioSourceType, poly, wallSegMats, wallMaterial, wallOpenings, H, floorMaterial, ceilMaterial);
    } else {
      audioEngine.stop();
    }
  }, [isPlaying, activeReceiverId, L, W, audioSourceType]);
  
  const [loadedInitial, setLoadedInitial] = useState(false);
  const activeProjectId = useProjectsStore((s) => s.activeProjectId);
  const projectsError = useProjectsStore((s) => s.error);

  // Initial load: prefer the multi-project workspace. If the user already
  // has an active project, its data was already loaded by
  // switchToProject/Dashboard's migration flow. If not (e.g. a pre-existing
  // user who hasn't visited the Dashboard/migrated yet, or someone landing
  // directly in the editor), fall back to the legacy single-project
  // endpoint so their current work still loads rather than showing a blank
  // room.
  useEffect(() => {
    if (user && !loadedInitial) {
      if (activeProjectId) {
        setLoadedInitial(true);
        return;
      }
      fetch('/api/project', { credentials: 'include' })
        .then(res => res.json())
        .then(data => {
          if (data.projectData) {
            // Whitelist + validate, matching useProjectsStore.ts's
            // applyProjectData() for the multi-project path. Previously
            // this called useStore.setState(data.projectData) directly on
            // whatever the server returned -- including, for any project
            // saved before this fix, a full raw dump of the entire store
            // (every action function silently dropped by JSON, but also
            // internal-only fields like past/future undo history and
            // availableMics). It also had no guard against a corrupted or
            // hand-edited L/W/H (0, negative, NaN) reaching every
            // downstream consumer (room geometry, wall-occlusion audio,
            // RT60) unvalidated, unlike the multi-project load path.
            const p = data.projectData;
            const safeDim = (v: any, fallback: number) =>
              Number.isFinite(v) && v > 0 ? Math.max(0.1, v) : fallback;
            const current = useStore.getState();
            useStore.setState({
              projectName: p.projectName ?? current.projectName,
              roomName: p.roomName ?? current.roomName,
              poly: p.poly ?? current.poly,
              L: safeDim(p.L, current.L), W: safeDim(p.W, current.W), H: safeDim(p.H, current.H),
              wallMaterial: p.wallMaterial ?? current.wallMaterial,
              wallSegMats: p.wallSegMats ?? current.wallSegMats,
              wallOpenings: p.wallOpenings ?? current.wallOpenings,
              floorMaterial: p.floorMaterial ?? current.floorMaterial,
              ceilMaterial: p.ceilMaterial ?? current.ceilMaterial,
              scatter: p.scatter ?? current.scatter,
              sources: p.sources ?? current.sources,
              receivers: p.receivers ?? current.receivers,
              simulations: p.simulations ?? current.simulations,
            });
          }
          setLoadedInitial(true);
        })
        .catch((e) => {
          console.error(e);
          setLoadedInitial(true);
        });
    }
  }, [user, loadedInitial, activeProjectId]);

  // Autosave: once a project is active, save into that project via the
  // multi-project endpoints. Only a user with no active project yet (not
  // migrated, or mid-editor before ever opening the Dashboard) falls back
  // to the legacy single-project endpoint — the two paths never run for
  // the same user at the same time, avoiding the double-write conflict
  // that existed when both ran unconditionally.
  useEffect(() => {
    if (!user || !loadedInitial) return;
    const interval = setInterval(() => {
      if (activeProjectId) {
        useProjectsStore.getState().saveCurrentProject();
        return;
      }
      const state = useStore.getState();
      const snapshot = {
        projectName: state.projectName,
        roomName: state.roomName,
        poly: state.poly,
        // L/W/H were previously missing from this snapshot entirely, even
        // though they're real, user-editable room dimensions (see
        // useStore.ts's setL/setW/setH) and useProjectsStore.ts's
        // extractProjectData() already includes them for the multi-project
        // path. Any legacy (non-multi-project) user's custom room
        // dimensions were silently dropped on every autosave and would
        // revert to the L=10/W=8/H=3 defaults the next time their project
        // loaded.
        L: state.L, W: state.W, H: state.H,
        wallSegMats: state.wallSegMats,
        wallOpenings: state.wallOpenings,
        wallMaterial: state.wallMaterial,
        floorMaterial: state.floorMaterial,
        ceilMaterial: state.ceilMaterial,
        scatter: state.scatter,
        sources: state.sources,
        receivers: state.receivers,
        simulations: state.simulations,
      };
      fetch('/api/project', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ projectData: snapshot })
      }).catch(console.error);
    }, 1000);
    return () => clearInterval(interval);
  }, [user, loadedInitial, activeProjectId]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && activeReceiverId) setActiveReceiverId(null);
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        if (e.shiftKey) {
          redo();
        } else {
          undo();
        }
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        redo();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeReceiverId, setActiveReceiverId, undo, redo]);

  return (
    <div className={`h-screen w-full flex flex-col ${theme === 'dark' ? 'bg-[#141517] text-[#e7e7e5]' : 'bg-[#f0f2f5] text-[#111827]'} overflow-hidden font-sans`}>
      <div className={`h-12 border-b ${theme === 'dark' ? 'border-[#2a2c30] bg-[#1a1b1e]' : 'border-[#e5e7eb] bg-[#ffffff]'} flex items-center px-3 md:px-4 justify-between shrink-0 gap-2`}>
        <div className="flex items-center text-xs font-semibold space-x-2 md:space-x-4 min-w-0">
          <div className="hidden sm:flex items-center space-x-2 shrink-0">
            <a href="/" className={`flex items-center gap-2 font-bold hover:opacity-80 transition-opacity ${theme === 'dark' ? "text-white" : "text-black"}`}>
              <Logo className="w-4 h-4" />
              <span className="uppercase tracking-wide">Cavity</span>
            </a>
          </div>
          {view === 'dashboard' ? (
             <div className={`flex items-center space-x-2 min-w-0 ${theme === 'dark' ? 'text-white' : 'text-black'}`}>
               <FolderIcon className="w-4 h-4 mr-2 shrink-0" />
               <input 
                 value={projectName} 
                 onChange={(e) => setProjectName(e.target.value)} 
                 className={`font-bold bg-transparent outline-none truncate w-32 md:w-48 ${theme === 'dark' ? 'text-white' : 'text-black'}`}
               />
             </div>
          ) : (
            <div className={`flex items-center space-x-2 min-w-0 overflow-hidden ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
              <button onClick={() => setView('dashboard')} className="hover:text-[#43d9b8] transition-colors shrink-0"><Home size={14}/></button>
              <span className="hidden md:inline">{'>'}</span>
              <span className="hidden md:inline truncate">{projectName}</span>
              <span className="hidden md:inline">{'>'}</span>
              <span className="truncate">{roomName}</span>
              <span className="shrink-0">{'>'}</span>
              <b className={`${theme === 'dark' ? 'text-white' : 'text-black'} flex items-center shrink-0`}><Activity size={14} className="mr-1"/> {view === 'results' ? 'Results' : 'Auralizer'}</b>
            </div>
          )}
        </div>
        <div className="flex items-center space-x-2 md:space-x-3 shrink-0">
          {user ? (
            <div className="flex items-center gap-3">
              <div className={`text-[10px] hidden sm:flex items-center gap-2 ${theme === 'dark' ? 'text-[#83868c]' : 'text-gray-500'}`}>
                <User size={12} />
                <span className="truncate max-w-[120px]">{user.email}</span>
              </div>
              {subscriptionData?.subscriptionStatus !== 'active' && (
                <div className="flex items-center gap-2">
                  {!trialExpired && subscriptionData?.trialEndsAt && (
                    <div className="hidden md:flex items-center text-[10px] font-semibold text-[#43d9b8] border border-[#43d9b8] px-2 py-1 rounded">
                      Free Trial: {Math.max(0, Math.ceil((subscriptionData.trialEndsAt - Date.now()) / (1000 * 60 * 60 * 24)))} days left
                    </div>
                  )}
                  <button 
                    onClick={() => setShowPaywallModal(true)}
                    className="bg-[#43d9b8] text-black px-4 py-1.5 rounded text-xs font-bold uppercase tracking-wider hover:bg-[#3bc2a4] transition-colors shadow-lg shadow-[#43d9b8]/20"
                  >
                    Subscribe Pro
                  </button>
                </div>
              )}
              {subscriptionData?.subscriptionStatus === 'active' && (
                <button 
                  onClick={async () => {
                    const res = await fetch('/api/portal', {
                      method: 'POST',
                      credentials: 'include',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ origin: window.location.origin })
                    });
                    const data = await res.json();
                    if (data.url) window.location.href = data.url;
                  }}
                  className={`border ${theme === 'dark' ? 'border-[#2a2c30] text-[#83868c] hover:text-white hover:border-[#43d9b8]' : 'border-gray-200 text-gray-500 hover:text-black hover:border-[#43d9b8]'} px-3 py-1 rounded text-[10px] font-bold transition-colors`}
                >
                  Billing{subscriptionData.plan ? ` (${subscriptionData.plan})` : ''}
                </button>
              )}
              <button 
                onClick={() => logout()}
                className={`p-1 rounded ${theme === 'dark' ? 'text-[#83868c] hover:text-white' : 'text-[#6b7280] hover:text-black'}`}
                title="Log Out"
              >
                <LogOut size={16} />
              </button>
            </div>
          ) : (
            <button 
              onClick={() => setShowAuthModal(true)}
              className="bg-[#43d9b8] text-black px-3 py-1 rounded text-[10px] font-bold uppercase tracking-wider hover:bg-[#3bc2a4] transition-colors"
            >
              Log In
            </button>
          )}
          <div className={`w-px h-4 mx-1 ${theme === 'dark' ? 'bg-[#2a2c30]' : 'bg-gray-200'}`}></div>
          
          {isPlaying && (
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded mr-1 uppercase tracking-wider ${hasFdtdIR ? 'bg-[#43d9b8]/10 text-[#43d9b8] border border-[#43d9b8]/30' : 'bg-orange-500/10 text-orange-400 border border-orange-500/30'}`}>
              {hasFdtdIR ? 'FDTD Acoustic Simulation' : 'Real-Time Acoustic Approximation'}
            </span>
          )}
          <button onClick={() => setIsPlaying(!isPlaying)} className={`p-1 rounded flex items-center gap-1 ${isPlaying ? 'text-[#43d9b8]' : (theme === 'dark' ? 'text-[#83868c] hover:text-white' : 'text-[#6b7280] hover:text-black')}`} title={isPlaying ? 'Stop Sound' : 'Play Sound'}>{isPlaying ? <Pause size={16} fill={'currentColor'} /> : <Play size={16} fill={'currentColor'} />}</button>

          <div className={`w-px h-4 mx-1 ${theme === 'dark' ? 'bg-[#2a2c30]' : 'bg-gray-200'}`}></div>
          <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className={`p-1 rounded ${theme === 'dark' ? 'text-[#83868c] hover:text-white' : 'text-[#6b7280] hover:text-black'}`}> 
             {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
          </button>
          <button disabled={past?.length === 0} onClick={undo} className={`hidden sm:inline-flex p-1 rounded ${past?.length > 0 ? (theme === 'dark' ? 'text-[#83868c] hover:text-white' : 'text-[#6b7280] hover:text-black') : 'opacity-30 cursor-not-allowed'}`} title="Undo (Ctrl+Z)"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 00-9-9 9 9 0 00-6 2.3L3 13"/></svg></button>
          <button disabled={future?.length === 0} onClick={redo} className={`hidden sm:inline-flex p-1 rounded ${future?.length > 0 ? (theme === 'dark' ? 'text-[#83868c] hover:text-white' : 'text-[#6b7280] hover:text-black') : 'opacity-30 cursor-not-allowed'}`} title="Redo (Ctrl+Y)"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 7v6h-6"/><path d="M3 17a9 9 0 019-9 9 9 0 016 2.3l3 2.7"/></svg></button>
          
          <button onClick={loadProject} className={`hidden md:flex items-center px-2 py-1 rounded text-xs transition-colors shrink-0 ${theme === 'dark' ? 'text-[#83868c] hover:text-white' : 'text-[#6b7280] hover:text-black'}`} title="Load Project">
            <Download size={14} className="mr-1" /> Load
          </button>
          <button onClick={saveProject} className={`hidden md:flex items-center px-2 py-1 rounded text-xs transition-colors shrink-0 ${theme === 'dark' ? 'text-[#83868c] hover:text-white' : 'text-[#6b7280] hover:text-black'}`} title="Save Project">
            <Save size={14} className="mr-1" /> Save
          </button>
          <button onClick={newProject} className="flex items-center border border-[#43d9b8] text-[#43d9b8] px-2 md:px-3 py-1 rounded text-xs hover:bg-[#43d9b8] hover:text-black transition-colors shrink-0">
            <Plus size={14} className="mr-0 md:mr-1" /> <span className="hidden md:inline">New</span>
          </button>
        </div>
      </div>
      
      <div className="flex-1 flex overflow-hidden relative">
        {view === 'dashboard' ? (
          <Dashboard />
        ) : (
          <>
            <main className={`flex-1 relative ${theme === 'dark' ? 'bg-[#000000]' : 'bg-[#f9fafb]'}`}>
              <ThreeView />
              {showMixer && <Mixer />}
              
              <div className="absolute bottom-4 left-4 flex bg-black/50 backdrop-blur-md rounded overflow-hidden">
                <button 
                  onClick={() => setViewMode('2d')} 
                  className={`px-3 py-1.5 text-xs font-bold ${viewMode === '2d' ? 'bg-[#43d9b8] text-black' : 'text-white hover:bg-white/10'}`}
                >
                  2D
                </button>
                <button 
                  onClick={() => setViewMode('3d')} 
                  className={`px-3 py-1.5 text-xs font-bold ${viewMode === '3d' ? 'bg-[#43d9b8] text-black' : 'text-white hover:bg-white/10'}`}
                >
                  3D
                </button>
              </div>
            </main>
            
            <RightSidebar />
          </>
        )}
      </div>

      <AuthModal isOpen={showAuthModal || isAuthForced} onClose={() => setShowAuthModal(false)} isForced={isAuthForced} />
      <PaywallModal isOpen={isLocked || showPaywallModal} onClose={() => setShowPaywallModal(false)} isForced={isLocked} />
    </div>
  );
}
