import { create } from 'zustand';

// Backed entirely by the server's own session-cookie auth (server.ts's
// /api/me, /api/auth/logout) — see authClient.ts for why this replaced a
// previous Firebase-based implementation that never actually connected to
// this server's session system.

export interface AppUser {
  uid: string;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  emailVerified: boolean;
}

interface SubscriptionData {
  subscriptionStatus: string;
  trialStartsAt?: number;
  trialEndsAt?: number;
  plan?: string;
}

interface AuthState {
  user: AppUser | null;
  subscriptionData: SubscriptionData | null;
  loading: boolean;
  needsVerification: boolean;
  setLoading: (loading: boolean) => void;
  hydrate: () => Promise<void>;
  logout: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  subscriptionData: null,
  loading: true,
  needsVerification: false,
  setLoading: (loading) => set({ loading }),

  // Fetches the current session's user from the server (if the session
  // cookie is valid) and updates local state accordingly. Call this after
  // any auth action (login, signup, verify) and once on app startup.
  hydrate: async () => {
    try {
      const res = await fetch('/api/me', { credentials: 'include' });
      if (!res.ok) {
        // 401/403: no valid session — this is the normal logged-out state,
        // not an error worth logging.
        set({ user: null, subscriptionData: null, loading: false, needsVerification: false });
        return;
      }
      const data = await res.json();
      set({
        user: data.user,
        subscriptionData: {
          subscriptionStatus: data.subscriptionStatus,
          trialStartsAt: data.trialStartsAt,
          trialEndsAt: data.trialEndsAt,
          plan: data.plan,
        },
        loading: false,
        needsVerification: !data.user?.emailVerified,
      });
    } catch (err) {
      console.error('Failed to hydrate session:', err);
      set({ loading: false });
    }
  },

  logout: async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    } catch (err) {
      console.error('Logout failed:', err);
    }
    set({ user: null, subscriptionData: null, needsVerification: false });
  },
}));

// Hydrate once on module load so the app knows the current session state
// (logged in or not) before rendering auth-dependent UI, mirroring the
// previous Firebase onAuthStateChanged behavior but as a one-shot check
// against the server rather than a persistent listener (there is no
// server-push equivalent for a plain session-cookie system — hydrate() is
// called again after every auth action instead).
useAuthStore.getState().hydrate();
