import { create } from 'zustand';
import { SPEAKERS } from '../lib/speakers';

export interface Point { x: number; y: number; }
export type WallOpening = 'full' | { start: number; end: number };
export interface Source {
  id: string; speakerId?: string; brand: string; model: string; type?: string; sens?: number | null; manufacturerSensitivityDb?: number | null; sensitivityStatus?: string;
  x: number; y: number; z?: number; yawDeg?: number; pitchDeg?: number;
  gainDb?: number; delayMs?: number; muted?: boolean; soundType?: string;
  // Display name for a user-uploaded audio file when soundType === 'custom'.
  // The decoded audio itself lives only in audioEngine.customBuffers (an
  // AudioBuffer can't be persisted to the JSON project store) — this field
  // is just what to show in the UI; re-opening a saved project with
  // soundType 'custom' will need the user to re-upload the file.
  customFileName?: string;
}
export interface Receiver { id: string; name: string; x: number; y: number; z?: number; }
export interface Simulation { id: string; name: string; sourceId: string; receiverId: string; }

export interface AppState {
  fdtdImpulseBuffer: AudioBuffer | null;
  setFdtdImpulseBuffer: (buffer: AudioBuffer | null) => void;
  past: Partial<AppState>[];
  future: Partial<AppState>[];
  undo: () => void;
  redo: () => void;
  saveHistory: () => void;

  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
  view: 'dashboard' | 'editor' | 'results';
  viewMode: '3d' | '2d'; setViewMode: (v: '3d'|'2d') => void;
  showMixer: boolean; setShowMixer: (b: boolean) => void;
  
  
  setView: (view: 'dashboard' | 'editor' | 'results') => void;
  projectName: string; setProjectName: (name: string) => void; roomName: string; setRoomName: (name: string) => void;
  poly: Point[]; setPoly: (poly: Point[]) => void;
  updatePoint: (index: number, point: Point) => void;
  addPoint: (index: number, point: Point) => void;
  removePoint: (index: number) => void;
  L: number; W: number; H: number;
  fmax: number; setFmax: (f: number) => void;
  confirmReducedResolution: boolean; setConfirmReducedResolution: (b: boolean) => void;
  solverResult: any; setSolverResult: (r: any) => void;
  accuracyMode: 'fast' | 'balanced' | 'high'; setAccuracyMode: (mode: 'fast' | 'balanced' | 'high') => void;
  setL: (L: number) => void; setW: (W: number) => void; setH: (H: number) => void;
  wallMaterial: string; wallSegMats: (string | null)[];
  setWallSegMat: (index: number, mat: string | null) => void;
  setWallMaterial: (mat: string) => void;
  // Per-wall-segment opening: 'full' removes the entire wall (open
  // archway/missing wall), or {start,end} (0-1 fraction along the segment)
  // cuts a partial gap (doorway/window) out of it. null/undefined = solid.
  wallOpenings: (WallOpening | null)[];
  setWallOpening: (index: number, opening: WallOpening | null) => void;
  floorMaterial: string; setFloorMaterial: (mat: string) => void;
  ceilMaterial: string; setCeilMaterial: (mat: string) => void;
  scatter: { walls: number; floor: number; ceiling: number };
  setScatter: (scatter: { walls: number; floor: number; ceiling: number }) => void;
  sources: Source[]; addSource: (source: Source) => void;
  addManySources: (sources: Source[]) => void;
  updateSource: (id: string, updates: Partial<Source>) => void;
  removeSource: (id: string) => void;
  receivers: Receiver[]; addReceiver: (receiver: Receiver) => void;
  updateReceiver: (id: string, updates: Partial<Receiver>) => void;
  removeReceiver: (id: string) => void;
  simulations: Simulation[]; addSimulation: () => void;
  removeSimulation: (id: string) => void;
  updateSimulation: (id: string, updates: Partial<Simulation>) => void;
  selectedWallSeg: number | null; setSelectedWallSeg: (index: number | null) => void;
  addingReceiver: boolean; setAddingReceiver: (adding: boolean) => void;
  activeReceiverId: string | null; setActiveReceiverId: (id: string | null) => void;
  isPlaying: boolean; setIsPlaying: (playing: boolean) => void;
  audioSourceType: string; setAudioSourceType: (type: string) => void;
  availableMics: MediaDeviceInfo[]; setAvailableMics: (mics: MediaDeviceInfo[]) => void;
  selectedMicId: string; setSelectedMicId: (id: string) => void;
  activeParam: string; setActiveParam: (param: string) => void;
  transitionFreqMode: string; setTransitionFreqMode: (mode: string) => void;
  saveProject: () => void; loadProject: () => void; newProject: () => void;
  // Most recent /api/solver/wave response, so other components (LeftSidebar's
  // real IR/EDC/C50/C80/D50/Ts charts) can use actual simulation output
  // instead of placeholder data. null until a run has completed.
  lastSolverResult: any | null;
  setLastSolverResult: (result: any | null) => void;
  // Separate from lastSolverResult: populated only by the dedicated
  // /api/solver/impulse-response run (coarse grid, long duration). Kept
  // distinct so the quick preview solver (fine grid, ~1ms simulated —
  // useless for decay metrics) can never silently overwrite a real,
  // long-duration trace that C50/C80/D50/Ts/RT60 depend on.
  lastImpulseResponseResult: any | null;
  setLastImpulseResponseResult: (result: any | null) => void;
}

const getDefaultSources = () => {
  return [{
    id: Math.random().toString(),
    brand: "Adam Audio",
    model: "ADA-100",
    x: 0.3,
    y: 0.3,
    gainDb: 0,
    muted: false,
    sens: null, manufacturerSensitivityDb: null, sensitivityStatus: 'UNAVAILABLE',
    type: "Active Studio Monitor"
  }];
};

const defaultPoly = [
  {x: 0.1, y: 0.1}, {x: 0.4, y: 0.1}, {x: 0.4, y: 0.4}, {x: 0.9, y: 0.4},
  {x: 0.9, y: 0.6}, {x: 0.4, y: 0.6}, {x: 0.4, y: 0.9}, {x: 0.1, y: 0.9}
];
const defaultWallMats = [null, null, null, null, null, null, null, null];
const defaultWallOpenings: (WallOpening | null)[] = [null, null, null, null, null, null, null, null];

export const useStore = create<AppState>((set, get) => ({
  fdtdImpulseBuffer: null,
  setFdtdImpulseBuffer: (buffer) => set({ fdtdImpulseBuffer: buffer }),
  past: [],
  future: [],
  saveHistory: () => {
    const state = get();
    const snapshot = {
      sources: JSON.parse(JSON.stringify(state.sources)),
      receivers: JSON.parse(JSON.stringify(state.receivers)),
      poly: JSON.parse(JSON.stringify(state.poly)),
      wallSegMats: JSON.parse(JSON.stringify(state.wallSegMats)),
      wallOpenings: JSON.parse(JSON.stringify(state.wallOpenings)),
      wallMaterial: state.wallMaterial,
      floorMaterial: state.floorMaterial,
      ceilMaterial: state.ceilMaterial,
    };
    set({ past: [...state.past || [], snapshot], future: [] });
  },
  undo: () => {
    const state = get();
    if (!state.past || state.past.length === 0) return;
    const prev = state.past[state.past.length - 1];
    const newPast = state.past.slice(0, state.past.length - 1);
    const currentSnapshot = {
      sources: JSON.parse(JSON.stringify(state.sources)),
      receivers: JSON.parse(JSON.stringify(state.receivers)),
      poly: JSON.parse(JSON.stringify(state.poly)),
      wallSegMats: JSON.parse(JSON.stringify(state.wallSegMats)),
      wallOpenings: JSON.parse(JSON.stringify(state.wallOpenings)),
      wallMaterial: state.wallMaterial,
      floorMaterial: state.floorMaterial,
      ceilMaterial: state.ceilMaterial,
    };
    set({ 
      ...prev, 
      past: newPast, 
      future: [currentSnapshot, ...(state.future || [])] 
    });
  },
  redo: () => {
    const state = get();
    if (!state.future || state.future.length === 0) return;
    const next = state.future[0];
    const newFuture = state.future.slice(1);
    const currentSnapshot = {
      sources: JSON.parse(JSON.stringify(state.sources)),
      receivers: JSON.parse(JSON.stringify(state.receivers)),
      poly: JSON.parse(JSON.stringify(state.poly)),
      wallSegMats: JSON.parse(JSON.stringify(state.wallSegMats)),
      wallOpenings: JSON.parse(JSON.stringify(state.wallOpenings)),
      wallMaterial: state.wallMaterial,
      floorMaterial: state.floorMaterial,
      ceilMaterial: state.ceilMaterial,
    };
    set({ 
      ...next, 
      past: [...(state.past || []), currentSnapshot], 
      future: newFuture 
    });
  },

  theme: 'dark', setTheme: (theme) => {
    set({ theme });
    if (theme === 'dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  },
  view: 'dashboard', setView: (view) => set({ view }),
  viewMode: '3d', setViewMode: (viewMode) => set({ viewMode }),
  showMixer: false, setShowMixer: (showMixer) => set({ showMixer }),
  
  
  projectName: 'My Project', setProjectName: (projectName) => set({ projectName }),
  roomName: 'Space 1', setRoomName: (roomName) => set({ roomName }),
  poly: defaultPoly,
  setPoly: (poly) => set({ poly }),
  updatePoint: (index, point) => set((state) => { const newPoly = [...state.poly]; newPoly[index] = point; return { poly: newPoly }; }),
  addPoint: (index, point) => {
    get().saveHistory();
    set((state) => {
      const newPoly = [...state.poly]; newPoly.splice(index, 0, point);
      const newWallSegMats = [...state.wallSegMats]; newWallSegMats.splice(index, 0, null);
      const newWallOpenings = [...state.wallOpenings]; newWallOpenings.splice(index, 0, null);
      return { poly: newPoly, wallSegMats: newWallSegMats, wallOpenings: newWallOpenings };
    });
  },
  removePoint: (index) => {
    get().saveHistory();
    set((state) => {
      if (state.poly.length <= 3) return state;
      const newPoly = [...state.poly]; newPoly.splice(index, 1);
      const newWallSegMats = [...state.wallSegMats]; newWallSegMats.splice(index, 1);
      const newWallOpenings = [...state.wallOpenings]; newWallOpenings.splice(index, 1);
      return { poly: newPoly, wallSegMats: newWallSegMats, wallOpenings: newWallOpenings };
    });
  },
  L: 10, W: 8, H: 3,
  fmax: 500, setFmax: (f) => set({ fmax: f }),
  confirmReducedResolution: false, setConfirmReducedResolution: (b) => set({ confirmReducedResolution: b }),
  solverResult: null, setSolverResult: (r) => set({ solverResult: r }),
  accuracyMode: 'balanced', setAccuracyMode: (mode) => set({ accuracyMode: mode }),
  // Real-world room dimensions in meters. `poly` points are normalized
  // (0-1) footprint coordinates; L/W scale them to real X/Y meters, H is
  // ceiling height. These were previously unused/unsettable state (dead
  // defaults) — added setters here so dimension-dependent calculations
  // (RT60, volume, surface area) and any dimensions UI have a real,
  // user-editable source of truth. Purely additive: does not change any
  // existing field, default value, or persisted shape.
  setL: (L) => { get().saveHistory(); set({ L: Math.max(0.1, L) }); },
  setW: (W) => { get().saveHistory(); set({ W: Math.max(0.1, W) }); },
  setH: (H) => { get().saveHistory(); set({ H: Math.max(0.1, H) }); },
  wallMaterial: 'drywall', wallSegMats: defaultWallMats,
  setWallSegMat: (index, mat) => { get().saveHistory(); set((state) => { const newMats = [...state.wallSegMats]; newMats[index] = mat; return { wallSegMats: newMats }; }); },
  wallOpenings: defaultWallOpenings,
  setWallOpening: (index, opening) => {
    get().saveHistory();
    set((state) => {
      const newOpenings = [...state.wallOpenings]; newOpenings[index] = opening;
      return { wallOpenings: newOpenings };
    });
  },
  setWallMaterial: (wallMaterial) => { get().saveHistory(); set({ wallMaterial }); },
  floorMaterial: 'wood_floor', setFloorMaterial: (floorMaterial) => { get().saveHistory(); set({ floorMaterial }); },
  ceilMaterial: 'stonewool', setCeilMaterial: (ceilMaterial) => { get().saveHistory(); set({ ceilMaterial }); },
  scatter: { walls: 0.15, floor: 0.15, ceiling: 0.15 }, setScatter: (scatter) => set({ scatter }),
  sources: getDefaultSources(),
  addSource: (source) => { get().saveHistory(); set((state) => ({ sources: [...state.sources, source] })); },
  addManySources: (newSources) => { get().saveHistory(); set((state) => ({ sources: [...state.sources, ...newSources] })); },
  updateSource: (id, updates) => set((state) => ({ sources: state.sources.map(s => s.id === id ? { ...s, ...updates } : s) })),
  removeSource: (id) => { get().saveHistory(); set((state) => ({ sources: state.sources.filter(s => s.id !== id) })); },
  receivers: [{ id: '1', name: 'Receiver 1', x: 0.25, y: 0.5 }],
  addReceiver: (receiver) => { get().saveHistory(); set((state) => ({ receivers: [...state.receivers, receiver] })); },
  updateReceiver: (id, updates) => set((state) => ({ receivers: state.receivers.map(r => r.id === id ? { ...r, ...updates } : r) })),
  removeReceiver: (id) => { get().saveHistory(); set((state) => ({ receivers: state.receivers.filter(r => r.id !== id) })); },
  simulations: [{ id: '1', name: 'Simulation 1', sourceId: '1', receiverId: '1' }],
  addSimulation: () => set((state) => ({ 
    simulations: [...state.simulations, { 
      id: Math.random().toString(), 
      name: `Simulation ${state.simulations.length + 1}`, 
      sourceId: state.sources[0]?.id || '', 
      receiverId: state.receivers[0]?.id || '' 
    }] 
  })),
  removeSimulation: (id) => set((state) => ({ simulations: state.simulations.filter(s => s.id !== id) })),
  updateSimulation: (id, updates) => set((state) => ({ simulations: state.simulations.map(s => s.id === id ? { ...s, ...updates } : s) })),
  selectedWallSeg: null, setSelectedWallSeg: (selectedWallSeg) => set({ selectedWallSeg }),
  addingReceiver: false, setAddingReceiver: (addingReceiver) => set({ addingReceiver }),
  activeReceiverId: null, setActiveReceiverId: (activeReceiverId) => set({ activeReceiverId }),
  isPlaying: false, setIsPlaying: (isPlaying) => set({ isPlaying }),
  audioSourceType: 'song', setAudioSourceType: (audioSourceType) => set({ audioSourceType }),
  availableMics: [], setAvailableMics: (availableMics) => set({ availableMics }),
  selectedMicId: '', setSelectedMicId: (selectedMicId) => set({ selectedMicId }),
  activeParam: 'STI', setActiveParam: (activeParam) => set({ activeParam }),
  transitionFreqMode: 'Default', setTransitionFreqMode: (transitionFreqMode) => set({ transitionFreqMode }),
  lastSolverResult: null, setLastSolverResult: (lastSolverResult) => set({ lastSolverResult }),
  lastImpulseResponseResult: null, setLastImpulseResponseResult: (lastImpulseResponseResult) => set({ lastImpulseResponseResult }),
  newProject: () => set({
    view: 'editor',
    poly: defaultPoly,
    wallSegMats: defaultWallMats,
    wallOpenings: defaultWallOpenings,
    sources: getDefaultSources(),
    receivers: [{ id: '1', name: 'Receiver 1', x: 0.25, y: 0.5 }],
    simulations: [{ id: '1', name: 'Simulation 1', sourceId: '1', receiverId: '1' }],
    isPlaying: false
  }),
  saveProject: () => {
    // Export only the actual project fields, matching the shape
    // useProjectsStore.ts's extractProjectData()/applyProjectData() and the
    // legacy /api/project endpoint already use. Previously this called
    // JSON.stringify(get()) directly on the whole Zustand store, which
    // dumped every field currently in state -- including this store's own
    // action functions (silently dropped by JSON.stringify, so not a
    // crash, but not intentional either), UI-only state (view, viewMode,
    // showMixer, selectedWallSeg, activeParam...), undo/redo history
    // snapshots (past/future), and even a live, non-serializable
    // MediaDeviceInfo[] (availableMics). The exported file was a leaky
    // dump of internal app state rather than a clean, portable project,
    // and per useProjectsStore.ts's own comment this was supposed to match
    // extractProjectData()'s shape -- it didn't.
    const state = get();
    const data = JSON.stringify({
      schemaVersion: 1,
      appVersion: "1.0.0",
      roomName: state.roomName,
      poly: state.poly,
      L: state.L, W: state.W, H: state.H,
      wallMaterial: state.wallMaterial,
      wallSegMats: state.wallSegMats,
      wallOpenings: state.wallOpenings,
      floorMaterial: state.floorMaterial,
      ceilMaterial: state.ceilMaterial,
      scatter: state.scatter,
      sources: state.sources,
      receivers: state.receivers,
      simulations: state.simulations,
    });
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${get().roomName}.json`;
    a.click();
    URL.revokeObjectURL(url);
  },
  loadProject: () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json';
    input.onchange = (e: any) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const str = e.target?.result as string;
          const data = JSON.parse(str);
          set({
            roomName: data.roomName || 'Loaded Space', poly: data.poly || get().poly,
            wallMaterial: data.wallMaterial || 'drywall', wallSegMats: data.wallSegMats || [],
            wallOpenings: data.wallOpenings || [],
            floorMaterial: data.floorMaterial || 'wood_floor', ceilMaterial: data.ceilMaterial || 'stonewool',
            sources: data.sources || [], receivers: data.receivers || [], simulations: data.simulations || []
          });
          alert('Project loaded successfully!');
        } catch (err) {
          alert('Failed to load project.');
        }
      };
      reader.readAsText(file);
    };
    input.click();
  }
}));
