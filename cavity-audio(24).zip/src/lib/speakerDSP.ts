// speakerDSP.ts
// Derives a real Web Audio filter chain from a speaker's published specs.
// This is a physically-motivated approximation, not a lab-measured impulse
// response — but every stage below is doing genuine signal processing driven
// by the actual spec numbers (freq range, driver size, power, driver count).

export type VerificationStatus = 'MANUFACTURER_VERIFIED' | 'MEASUREMENT_VERIFIED' | 'ESTIMATED' | 'UNAVAILABLE' | 'LEGACY';
export type SourceType = 'MANUFACTURER' | 'MEASUREMENT' | 'REPUTABLE_DATABASE' | 'RETAILER' | 'ESTIMATE' | 'UNKNOWN' | 'NONE';

export interface SpecField<T> {
  value: T | null;
  unit: string;
  status: VerificationStatus;
  source: string | null;
  sourceType: SourceType;
}

export type OverallStatus = 'FULLY_VERIFIED' | 'PARTIALLY_VERIFIED' | 'MEASUREMENT_VERIFIED' | 'LEGACY' | 'UNAVAILABLE';

export interface SpeakerSpec {
  id: string;
  brand: string;
  model: string;
  category: string;
  year: number | null;
  overallStatus: OverallStatus;
  driverCount: number;
  active: boolean;
  panel: boolean;
  notes: string | null;

  frequencyResponse: {
    low_hz: number | null;
    high_hz: number | null;
    status: VerificationStatus;
    source: string | null;
    sourceType: SourceType;
  };
  sensitivity: SpecField<number>;
  power: SpecField<number>;
  impedance: SpecField<number>;
  resonantFreq: SpecField<number>;
  voiceCoil: SpecField<number>;
  woofer: SpecField<number>;
}

export interface SpeakerAudioChain {
  input: GainNode;
  output: GainNode;
  nodes: AudioNode[];
  dispose: () => void;
}

// Some entries in the merged speaker library come from the legacy
// speakers.ts list (source: "legacy") and only have brand/model/year/
// category/sens_db — they predate the full spec schema below and we do
// not fabricate driver/frequency/power numbers for them. This fills in
// conservative, clearly-labeled flat-response defaults so buildSpeakerChain
// doesn't crash on missing fields; it intentionally does NOT attempt to
// approximate real per-speaker character for these entries.
export function normalizeSpeakerSpec(raw: any): SpeakerSpec {
  if (raw.overallStatus !== "LEGACY") return raw as SpeakerSpec;

  const sensValue = raw.sensitivity?.value || raw.sens_db || null;

  return {
    id: raw.id || 'unknown',
    brand: raw.brand || 'Unknown',
    model: raw.model || 'Unknown',
    category: raw.category || 'unknown',
    year: raw.year || null,
    overallStatus: 'LEGACY',
    driverCount: 2,
    active: false,
    panel: false,
    notes: (raw.notes || '') + ' [Legacy entry: speaker-specific driver/frequency/power specs unavailable; DSP uses explicit generic fallback parameters only]',
    frequencyResponse: { low_hz: null, high_hz: null, status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    sensitivity: { value: sensValue, unit: 'dB', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    power: { value: null, unit: 'W', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    impedance: { value: null, unit: 'ohm', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    resonantFreq: { value: null, unit: 'Hz', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    voiceCoil: { value: null, unit: 'in', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' },
    woofer: { value: null, unit: 'in', status: 'UNAVAILABLE', source: null, sourceType: 'NONE' }
  };
}

/**
 * Build a chain of real Web Audio nodes whose parameters are derived
 * mathematically from the speaker's spec sheet:
 *
 *  1. Low-shelf filter   — rolloff below freqLow_hz. Smaller woofers and
 *     higher freqLow_hz specs roll off earlier and more steeply (physical
 *     reality: small cones can't move enough air for deep bass).
 *  2. High-shelf filter  — rolloff above freqHigh_hz, softened/extended
 *     for tweeter types implied by high freqHigh_hz values (ribbon/beryllium
 *     designs in real speakers report >30kHz; this reflects that in the curve).
 *  3. Presence/proximity peak — driver count and category shape a broad
 *     midrange peaking filter (horn-loaded PA/vintage horn speakers get a
 *     forward upper-mid bump consistent with their real high-sensitivity
 *     horn geometry; multi-way studio monitors get a flatter response).
 *  4. WaveShaper (soft saturation) — power handling drives how much headroom
 *     the chain has before soft-clipping character appears, approximating
 *     how lower-power/vintage drivers compress and add harmonic coloration
 *     sooner than a high-power modern active monitor.
 *  5. Compressor — active/DSP-driven modern PA and studio monitors get a
 *     tighter, more controlled dynamic response (real behavior of onboard
 *     DSP limiters); passive vintage speakers get looser dynamics.
 */
export function buildSpeakerChain(
  ctx: AudioContext,
  rawSpec: SpeakerSpec
): SpeakerAudioChain {
  const spec = normalizeSpeakerSpec(rawSpec);
  const input = ctx.createGain();
  const output = ctx.createGain();
  const nodes: AudioNode[] = [];

  // ---- Narrow-band drivers (guitar cab speakers, car audio) take a
  // different signal path: they're not trying to be flat/full-range, so
  // model them as a bandpass centered near resonant frequency instead of
  // shelving filters meant for full-range speakers. ----
  if (spec.category === "guitar-cab" || spec.category === "car-audio") {
    return buildNarrowBandChain(ctx, spec, input, output, nodes);
  }

  // ---- 1. Low-end shelf, derived from freqLow_hz + woofer size ----
  const lowShelf = ctx.createBiquadFilter();
  lowShelf.type = "lowshelf";
  lowShelf.frequency.value = clamp((spec.frequencyResponse?.low_hz || 60) * 1.15, 20, 300);
  // Smaller drivers (or panels with no cone) roll off more steeply/earlier.
  const woofer = (spec.woofer?.value || 6.5) || (spec.panel ? 0 : 5);
  const bassDeficit = woofer === 0
    ? -4 // planar/electrostatic: extended but gentle natural rolloff
    : clamp((8 - woofer) * -1.4, -14, 3); // small woofer => negative (cut) gain
  lowShelf.gain.value = bassDeficit;
  nodes.push(lowShelf);

  // ---- 2. High-end shelf, derived from freqHigh_hz ----
  const highShelf = ctx.createBiquadFilter();
  highShelf.type = "highshelf";
  highShelf.frequency.value = clamp((spec.frequencyResponse?.high_hz || 18000) * 0.82, 4000, 22000);
  // Extended-response tweeters (ribbon/beryllium/AMT — anything specced
  // above ~30kHz in real spec sheets) get a gentle air-band lift;
  // older/rolled-off designs get a cut.
  highShelf.gain.value = clamp(((spec.frequencyResponse?.high_hz || 18000) - 18000) / 3000, -6, 4);
  nodes.push(highShelf);

  // ---- 3. Presence/character peak, derived from category + driver count ----
  const presence = ctx.createBiquadFilter();
  presence.type = "peaking";
  presence.Q.value = 1.1;
  if (spec.category === "pa" && !spec.active) {
    // Horn-loaded vintage/passive PA: forward, honky upper-mid presence
    presence.frequency.value = 2200;
    presence.gain.value = 4.5;
  } else if (spec.category === "pa" && spec.active) {
    // Modern DSP-tuned PA: flatter, EQ'd for even coverage
    presence.frequency.value = 2500;
    presence.gain.value = 1.5;
  } else if (spec.category === "studio-monitor") {
    // Reference monitors aim flat; tiny dip to avoid harshness bump
    presence.frequency.value = 3000;
    presence.gain.value = -0.5;
  } else if (spec.panel) {
    // Planar/electrostatic: very smooth, minimal peak
    presence.frequency.value = 2000;
    presence.gain.value = -1;
  } else if (spec.driverCount >= 4) {
    // Multi-driver arrays (e.g. Bose 901, complex towers): diffuse, slight scoop
    presence.frequency.value = 1800;
    presence.gain.value = -1.5;
  } else {
    // General consumer bookshelf/floor-standing
    presence.frequency.value = 2800;
    presence.gain.value = 1.5;
  }
  nodes.push(presence);

  // ---- 4. Soft saturation, derived from power handling ----
  const shaper = ctx.createWaveShaper();
  shaper.curve = makeSaturationCurve((spec.power?.value || 50), spec.year);
  shaper.oversample = "4x";
  nodes.push(shaper);

  // ---- 5. Dynamics, derived from active/DSP status ----
  const compressor = ctx.createDynamicsCompressor();
  if (spec.active) {
    // Modern active speakers: onboard DSP/limiter, tighter control
    compressor.threshold.value = -12;
    compressor.ratio.value = 4;
    compressor.attack.value = 0.003;
    compressor.release.value = 0.15;
  } else {
    // Passive/vintage: looser, more natural dynamics, higher threshold
    compressor.threshold.value = -6;
    compressor.ratio.value = 2;
    compressor.attack.value = 0.01;
    compressor.release.value = 0.3;
  }
  nodes.push(compressor);

  // Wire the chain: input -> lowShelf -> highShelf -> presence -> shaper -> compressor -> output
  input.connect(lowShelf);
  lowShelf.connect(highShelf);
  highShelf.connect(presence);
  presence.connect(shaper);
  shaper.connect(compressor);
  compressor.connect(output);

  return {
    input,
    output,
    nodes: [lowShelf, highShelf, presence, shaper, compressor],
    dispose: () => {
      nodes.forEach((n) => {
        try {
          n.disconnect();
        } catch {
          /* already disconnected */
        }
      });
    },
  };
}

/**
 * Narrow-band chain for guitar cab drivers and car audio subs/mids.
 * These are NOT trying to reproduce a flat frequency range — a guitar
 * speaker is intentionally colored/resonant, and a car sub is optimized
 * for a narrow low-frequency band with high excursion. Modeling them as
 * a bandpass around their resonant frequency (Fs) is closer to how they
 * actually behave than forcing a hi-fi lowshelf/highshelf onto them.
 */
function buildNarrowBandChain(
  ctx: AudioContext,
  spec: SpeakerSpec,
  input: GainNode,
  output: GainNode,
  nodes: AudioNode[]
): SpeakerAudioChain {
  const fs = spec.resonantFreq?.value ?? (spec.category === "car-audio" ? 35 : 90);

  // Bandpass centered on resonant frequency — narrower Q for car subs
  // (tuned box, narrow-band output), wider for guitar drivers (broader
  // midrange character with natural rolloff on both ends).
  const bandpass = ctx.createBiquadFilter();
  bandpass.type = "bandpass";
  bandpass.frequency.value = fs;
  bandpass.Q.value = spec.category === "car-audio" ? 1.4 : 0.7;
  nodes.push(bandpass);

  // Guitar cab drivers are famously midrange-forward and "honky" —
  // real Celestion/Jensen drivers have a characteristic upper-mid hump.
  const midHump = ctx.createBiquadFilter();
  midHump.type = "peaking";
  midHump.frequency.value = spec.category === "guitar-cab" ? 2000 : 60;
  midHump.Q.value = 1;
  midHump.gain.value = spec.category === "guitar-cab" ? 6 : 2;
  nodes.push(midHump);

  // Sensitivity affects perceived loudness/output gain — higher
  // sensitivity (dB @ 1W/1m) drivers are louder for the same input.
  const sensGain = ctx.createGain();
  const sens = spec.sensitivity?.value ?? 92;
  sensGain.gain.value = clamp((sens - 85) / 15, 0.3, 2.5);
  nodes.push(sensGain);

  // Guitar speakers break up and distort readily by design; car subs
  // stay cleaner but compress hard near excursion limits.
  const shaper = ctx.createWaveShaper();
  shaper.curve = makeSaturationCurve(
    spec.category === "guitar-cab" ? (spec.power?.value || 50) * 0.3 : (spec.power?.value || 50),
    spec.category === "guitar-cab" ? 1955 : spec.year // force an "eager to saturate" character for guitar drivers
  );
  shaper.oversample = "4x";
  nodes.push(shaper);

  input.connect(bandpass);
  bandpass.connect(midHump);
  midHump.connect(sensGain);
  sensGain.connect(shaper);
  shaper.connect(output);

  return {
    input,
    output,
    nodes,
    dispose: () => {
      nodes.forEach((n) => {
        try {
          n.disconnect();
        } catch {
          /* already disconnected */
        }
      });
    },
  };
}

/** Builds a WaveShaper curve whose softness scales with rated power and era.
 *  Lower power handling + older era => saturates/compresses sooner (smaller
 *  drivers and older voice coils reach thermal/mechanical limits faster).
 *  This is a simplified but real nonlinear transfer function, not decorative.
 */
function makeSaturationCurve(power_w: number, year: number | null): Float32Array<ArrayBuffer> {
  const samples = 1024;
  const curve = new Float32Array(new ArrayBuffer(samples * Float32Array.BYTES_PER_ELEMENT));
  // Normalize: low power (e.g. 20W vintage) => low knee; high power
  // (e.g. 2000W modern PSU) => knee pushed far out, nearly linear.
  const powerFactor = clamp(power_w / 500, 0.15, 3);
  // year can be null (e.g. legacy speaker entries with no known year — see
  // normalizeSpeakerSpec). Previously this ran `null - 1950` directly,
  // which coerces to -1950 and clamps to the 0.2 floor — happening to land
  // on a plausible-looking "old/soft knee" value by accident, but as an
  // unintended side effect of numeric coercion rather than a real default.
  // Treat unknown year explicitly as a mid-era assumption instead.
  const eraFactor = year != null ? clamp((year - 1950) / 75, 0.2, 1) : 0.6; // older = softer knee; unknown year -> neutral middle assumption
  const knee = clamp(powerFactor * eraFactor, 0.2, 2.5);

  for (let i = 0; i < samples; i++) {
    const x = (i * 2) / samples - 1; // -1 to 1
    curve[i] = Math.tanh(x * (1 + 1 / knee)) / Math.tanh(1 + 1 / knee);
  }
  return curve;
}

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}
