import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  projectId: "waking-conquest-lpthm",
  appId: "1:900503119663:web:a32664825b2df3a7a423da",
  apiKey: "AIzaSyBrUgBN8FbTHiyPqF2PrfElJ0XHmqjCPTo",
  authDomain: "waking-conquest-lpthm.firebaseapp.com",
  storageBucket: "waking-conquest-lpthm.firebasestorage.app",
  messagingSenderId: "900503119663"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, "ai-studio-cavityaudio-a5657080-522d-4b35-9e30-029683856524");
