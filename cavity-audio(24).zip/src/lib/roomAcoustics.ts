// Room acoustics calculations: per-octave-band RT60 (Sabine and Eyring) and
// a labeled STI proxy, built from the room's real geometry (poly + L/W/H)
// and per-surface materials — including per-wall-segment materials, not a
// single averaged wall material.
//
// This is the single source of truth for RT60/STI math. The FDTD solver
// endpoint in server.ts computes its own broadband (500Hz-only) Sabine RT60
// for its "does the simulated decay look sane" cross-check — that's a
// legitimate, different use case (single-band, matches what a time-domain
// step can produce) and is intentionally not replaced by this module. This
// module is for anything that needs a full per-band reverberation picture:
// the report export, any RT60 display in the UI, etc.

import { getAbsorption, nrc, type AbsorptionCoeffs } from './absorption';

export type Point = { x: number; y: number };

export interface RoomGeometryInput {
  poly: Point[]; // normalized (0-1) footprint coordinates
  L: number; // real-world footprint scale, X axis, meters
  W: number; // real-world footprint scale, Y axis, meters
  H: number; // ceiling height, meters
  wallMaterial: string; // default/global wall material
  wallSegMats: (string | null)[]; // per-segment override; null = use wallMaterial
  floorMaterial: string;
  ceilMaterial: string;
}

const BANDS: (keyof AbsorptionCoeffs)[] = ['hz125', 'hz250', 'hz500', 'hz1000', 'hz2000', 'hz4000'];
export const BAND_LABELS = ['125 Hz', '250 Hz', '500 Hz', '1000 Hz', '2000 Hz', '4000 Hz'];

// Shoelace formula: area of a simple polygon from its vertices.
function polygonArea(points: { x: number; y: number }[]): number {
  let sum = 0;
  for (let i = 0; i < points.length; i++) {
    const p1 = points[i];
    const p2 = points[(i + 1) % points.length];
    sum += p1.x * p2.y - p2.x * p1.y;
  }
  return Math.abs(sum) / 2;
}

export interface RoomSurfaces {
  volume: number; // m^3
  floorArea: number; // m^2
  ceilArea: number; // m^2
  // Each wall segment: real length (m) and the material id that applies to it.
  wallSegments: { lengthM: number; materialId: string }[];
  totalWallArea: number; // m^2 (sum of segment areas), for reference/display
}

// Derive real-world surface areas and volume from the normalized polygon +
// L/W/H scale. Each poly point (x,y) in [0,1] maps to real coordinates
// (x*L, y*W); wall segment i runs from poly[i] to poly[i+1].
export function computeRoomSurfaces(room: RoomGeometryInput): RoomSurfaces {
  const { poly, L, W, H, wallMaterial, wallSegMats } = room;

  const realPoints = poly.map(p => ({ x: p.x * L, y: p.y * W }));
  const floorArea = polygonArea(realPoints);

  const wallSegments = realPoints.map((p1, i) => {
    const p2 = realPoints[(i + 1) % realPoints.length];
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const lengthM = Math.sqrt(dx * dx + dy * dy);
    const materialId = wallSegMats[i] ?? wallMaterial;
    return { lengthM, materialId };
  });

  const totalWallArea = wallSegments.reduce((sum, seg) => sum + seg.lengthM * H, 0);
  const volume = floorArea * H;

  return {
    volume,
    floorArea,
    ceilArea: floorArea, // ceiling directly mirrors the footprint
    wallSegments,
    totalWallArea,
  };
}

export interface RT60Result {
  // Per-band RT60 in seconds, both methods, for the caller to choose/display.
  sabine: Record<string, number>; // keyed by band label, e.g. "500 Hz"
  eyring: Record<string, number>;
  // Area-weighted average absorption coefficient per band (needed for Eyring
  // and useful to show alongside the RT60 numbers).
  avgAbsorption: Record<string, number>;
  // Which formula this room's overall absorption level suggests is more
  // appropriate. Eyring's own derivation doesn't specify an exact
  // crossover point; published guidance commonly cites ~0.3 average alpha
  // as where Sabine's overestimate becomes significant (15%+), so that's
  // used here as a conservative rule of thumb, not a standardized cutoff.
  recommendedMethod: 'sabine' | 'eyring';
  volume: number;
  // Real footprint area (m^2) from the actual room polygon, not L*W — the
  // room may be non-rectangular. Exposed directly so callers (e.g. the PDF
  // report) don't need to reverse-engineer it from volume/H, which is only
  // correct today because volume happens to be floorArea*H and would
  // silently break if that relationship ever changed (sloped ceilings,
  // per-segment heights, etc.).
  floorArea: number;
  totalSurfaceArea: number;
}

// Sabine: RT60 = 0.161 * V / A, where A = sum(area_i * alpha_i).
// Eyring: RT60 = 0.161 * V / (-S * ln(1 - alpha_avg)), more accurate as
// absorption increases (Sabine over-predicts RT60 in "dead" rooms).
// Reference: Sabine (1898); Eyring (1930). Both are long-standing, widely
// published methods in architectural acoustics (see e.g. ISO 3382 for
// standard reverberation-time measurement/reporting conventions this
// calculation is meant to be compared against, not a substitute for
// on-site measurement).
//
// materialLookup: optional override for how a material id resolves to
// per-band absorption coefficients. Defaults to the real, shared
// getAbsorption() from absorption.ts (production behavior — the app should
// never pass a custom lookup). Exists so roomAcoustics.validation.ts can
// exercise this exact function against published reference cases that use
// arbitrary custom coefficients not present in our named material table,
// without needing to duplicate this formula in a separate reimplementation.
export function computeRT60(
  room: RoomGeometryInput,
  materialLookup: (materialId: string) => AbsorptionCoeffs = getAbsorption
): RT60Result {
  const surfaces = computeRoomSurfaces(room);
  const { volume, floorArea, ceilArea, wallSegments } = surfaces;
  const totalSurfaceArea = floorArea + ceilArea + wallSegments.reduce((s, w) => s + w.lengthM * room.H, 0);

  const sabine: Record<string, number> = {};
  const eyring: Record<string, number> = {};
  const avgAbsorption: Record<string, number> = {};

  let sumAlphaMid = 0; // for recommendedMethod decision, using 500Hz+1000Hz average

  BANDS.forEach((band, i) => {
    const label = BAND_LABELS[i];

    const floorAlpha = materialLookup(room.floorMaterial)[band];
    const ceilAlpha = materialLookup(room.ceilMaterial)[band];

    let totalSabins = floorArea * floorAlpha + ceilArea * ceilAlpha;
    for (const seg of wallSegments) {
      const segArea = seg.lengthM * room.H;
      const alpha = materialLookup(seg.materialId)[band];
      totalSabins += segArea * alpha;
    }

    const alphaAvg = totalSurfaceArea > 0 ? totalSabins / totalSurfaceArea : 0;
    avgAbsorption[label] = Math.round(alphaAvg * 1000) / 1000;

    sabine[label] = totalSurfaceArea > 0
      ? Math.round(((0.161 * volume) / Math.max(totalSabins, 0.001)) * 100) / 100
      : 0;

    // Eyring: guard alphaAvg -> 1 (would make ln(0) = -Infinity).
    const safeAlpha = Math.min(alphaAvg, 0.999);
    const eyringDenominator = -totalSurfaceArea * Math.log(1 - safeAlpha);
    eyring[label] = eyringDenominator > 0
      ? Math.round(((0.161 * volume) / eyringDenominator) * 100) / 100
      : 0;

    if (band === 'hz500' || band === 'hz1000') sumAlphaMid += alphaAvg;
  });

  const avgMidAlpha = sumAlphaMid / 2;

  return {
    sabine,
    eyring,
    avgAbsorption,
    recommendedMethod: avgMidAlpha < 0.3 ? 'sabine' : 'eyring',
    volume,
    floorArea,
    totalSurfaceArea,
  };
}

export interface STIProxyResult {
  value: number; // 0-1
  qualityLabel: string; // Bad / Poor / Fair / Good / Excellent
  // Explicit, non-negotiable caveat — always surface this alongside the
  // number in any UI/report. This is not the IEC 60268-16 measurement.
  disclaimer: string;
}

function stiQualityLabel(sti: number): string {
  if (sti < 0.3) return 'Bad';
  if (sti < 0.45) return 'Poor';
  if (sti < 0.6) return 'Fair';
  if (sti < 0.75) return 'Good';
  return 'Excellent';
}

// Labeled proxy STI estimate from RT60 (mid-frequency, e.g. the 1000Hz
// Sabine/Eyring value) and an assumed/measured signal-to-noise ratio at the
// listening position.
//
// Formula (Houtgast & Steeneken-derived proxy, as published and used in
// open acoustic-analysis tooling — NOT the full IEC 60268-16 modulation
// transfer function calculation, which requires per-band MTF analysis of
// an actual impulse response and is a materially larger undertaking):
//   STI_proxy = 0.15 + 0.85 * (0.65 * R_T + 0.35 * R_S)
//   R_T = 1 / (1 + (RT60/0.8)^1.6)
//   R_S = 1 / (1 + 10^(-(SNR-15)/10))
//
// The source publishing this proxy explicitly notes it "should not be used
// for formal compliance testing" — treat this output the same way. Always
// label it as an estimate, never as a certified/compliant STI measurement.
export function computeSTIProxy(rt60Seconds: number, snrDb: number): STIProxyResult {
  const rT = 1 / (1 + Math.pow(rt60Seconds / 0.8, 1.6));
  const rS = 1 / (1 + Math.pow(10, -(snrDb - 15) / 10));
  const sti = 0.15 + 0.85 * (0.65 * rT + 0.35 * rS);
  const clamped = Math.max(0, Math.min(1, sti));

  return {
    value: Math.round(clamped * 100) / 100,
    qualityLabel: stiQualityLabel(clamped),
    disclaimer:
      'This is an estimate derived from RT60 and assumed signal-to-noise ratio, not a full IEC 60268-16 speech transmission index measurement. It is not suitable for compliance or certification purposes.',
  };
}

export { nrc };
