import { adminDb } from "./server/firebase-admin";

async function run() {
  try {
    const res = await adminDb.collection("users").limit(1).get();
    console.log("Firestore works! Users count:", res.size);
  } catch(e) {
    console.error("Firestore error:", e);
  }
}
run();
