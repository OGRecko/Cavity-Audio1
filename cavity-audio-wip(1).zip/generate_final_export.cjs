const fs = require('fs');
const data = JSON.parse(fs.readFileSync('src/data/speakers.json', 'utf8'));

for (const s of data) {
    delete s.verified;
    delete s.sens_db;
    delete s.sensitivity_db;
}

fs.writeFileSync('src/data/speakers.json', JSON.stringify(data, null, 2));

let csv = "Brand,Model,Category,Verification Status,Frequency Low,Frequency High,Sensitivity,Impedance,Power,Drivers,Source\n";
for (const s of data) {
    csv += `"${s.brand || ''}","${s.model || ''}","${s.category || ''}","${s.verificationStatus || ''}",${s.freqLow_hz || ''},${s.freqHigh_hz || ''},${s.manufacturerSensitivityDb || ''},${s.impedance_ohm || ''},${s.power_w || ''},${s.driverCount || ''},"${s.source || ''}"\n`;
}

fs.writeFileSync('final-speakers.csv', csv);
