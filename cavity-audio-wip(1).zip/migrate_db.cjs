const fs = require('fs');
const data = JSON.parse(fs.readFileSync('src/data/speakers.json', 'utf8'));

const migrated = data.map(s => {
    const isLegacy = s.source === 'legacy';
    
    // Overall status
    let overallStatus = 'UNAVAILABLE';
    if (isLegacy) {
        overallStatus = 'LEGACY';
    } else if (s.verificationStatus === 'VERIFIED_MANUFACTURER') {
        overallStatus = (s.freqLow_hz && s.manufacturerSensitivityDb && s.power_w && s.impedance_ohm !== undefined) ? 'FULLY_VERIFIED' : 'PARTIALLY_VERIFIED';
    } else if (s.verificationStatus === 'VERIFIED_MEASUREMENT') {
        overallStatus = 'MEASUREMENT_VERIFIED';
    } else if (s.verificationStatus === 'PARTIAL') {
        overallStatus = 'PARTIALLY_VERIFIED';
    }

    const mapStatus = (st) => {
        if (st === 'VERIFIED_MANUFACTURER' || st === 'PARTIAL') return 'MANUFACTURER_VERIFIED';
        if (st === 'VERIFIED_MEASUREMENT') return 'MEASUREMENT_VERIFIED';
        if (isLegacy) return 'LEGACY';
        return 'UNAVAILABLE';
    };

    const fieldStatus = mapStatus(s.verificationStatus);

    const mkField = (val, unit, condition) => {
        if (condition && val !== undefined && val !== null) {
            return {
                value: val,
                unit: unit,
                status: fieldStatus,
                source: s.source || (isLegacy ? 'Legacy' : 'Manufacturer Specifications'),
                sourceType: (s.source === 'Official Manufacturer Datasheet' || s.source === 'Manufacturer Specifications') ? 'MANUFACTURER' : (isLegacy ? 'NONE' : 'UNKNOWN')
            };
        } else {
            return {
                value: val !== undefined ? val : null,
                unit: unit,
                status: 'UNAVAILABLE',
                source: null,
                sourceType: 'NONE'
            };
        }
    };

    return {
        id: s.id,
        brand: s.brand,
        model: s.model,
        category: s.category,
        year: s.year || null,
        overallStatus: overallStatus,
        driverCount: s.driverCount || 1,
        active: s.active || false,
        panel: s.panel || false,
        
        sensitivity: mkField(s.manufacturerSensitivityDb, 'dB', s.manufacturerSensitivityDb !== null && s.manufacturerSensitivityDb !== undefined),
        frequencyResponse: {
            low_hz: s.freqLow_hz !== undefined ? s.freqLow_hz : null,
            high_hz: s.freqHigh_hz !== undefined ? s.freqHigh_hz : null,
            status: s.freqLow_hz ? fieldStatus : 'UNAVAILABLE',
            source: s.freqLow_hz ? (s.source || (isLegacy ? 'Legacy' : 'Manufacturer Specifications')) : null,
            sourceType: s.freqLow_hz ? (s.source === 'Official Manufacturer Datasheet' || s.source === 'Manufacturer Specifications' ? 'MANUFACTURER' : (isLegacy ? 'NONE' : 'UNKNOWN')) : 'NONE'
        },
        power: mkField(s.power_w, 'W', s.power_w !== undefined),
        impedance: mkField(s.impedance_ohm, 'ohm', s.impedance_ohm !== undefined),
        resonantFreq: mkField(s.resonantFreq_hz, 'Hz', s.resonantFreq_hz !== undefined),
        voiceCoil: mkField(s.voiceCoil_in, 'in', s.voiceCoil_in !== undefined),
        woofer: mkField(s.woofer_in, 'in', s.woofer_in !== undefined),
        
        notes: s.notes || null
    };
});

fs.writeFileSync('src/data/speakers_migrated.json', JSON.stringify(migrated, null, 2));
