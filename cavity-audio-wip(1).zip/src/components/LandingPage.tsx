import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Activity, Cpu, Box, Headphones, ShieldCheck, Zap, Server, ChevronRight, Check } from 'lucide-react';
import { useAuthStore } from '../store/useAuthStore';
import { AuthModal } from './AuthModal';
import { motion } from 'motion/react';

export default function LandingPage() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">("annual");

  const handleGetStarted = () => {
    if (user) {
      navigate('/app');
    } else {
      setShowAuthModal(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-[#e7e7e5] font-sans selection:bg-[#43d9b8]/30">
      {/* Navigation */}
      <nav className="w-full px-8 py-5 flex items-center justify-between border-b border-[#2a2c30]/50 bg-[#0a0a0c]/90 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-[#43d9b8]/10 flex items-center justify-center border border-[#43d9b8]/30">
            <Activity className="text-[#43d9b8]" size={16} />
          </div>
          <span className="font-bold text-lg tracking-tight text-white uppercase letter-spacing-wide">Cavity Audio</span>
        </div>
        <div className="flex items-center gap-6">
          {!user ? (
            <>
              <button 
                onClick={() => setShowAuthModal(true)}
                className="font-semibold text-xs tracking-wider uppercase text-gray-400 hover:text-white transition-colors"
              >
                Client Login
              </button>
              <button 
                onClick={handleGetStarted}
                className="px-6 py-2.5 rounded bg-[#43d9b8] text-black font-bold text-xs uppercase tracking-wider hover:bg-[#34c7a3] transition-all shadow-[0_0_15px_rgba(67,217,184,0.15)] border border-[#43d9b8]/50"
              >
                Initialize Engine
              </button>
            </>
          ) : (
            <button 
              onClick={() => navigate('/app')}
              className="px-6 py-2.5 rounded bg-[#43d9b8] text-black font-bold text-xs uppercase tracking-wider hover:bg-[#34c7a3] transition-all"
            >
              Access Workspace
            </button>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative px-6 pt-32 pb-40 max-w-7xl mx-auto flex flex-col items-center text-center">
        {/* Subtle grid background to look like engineering software */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem] -z-10 [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)]"></div>
        
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#43d9b8]/10 text-[#43d9b8] font-bold text-[10px] uppercase tracking-widest mb-8 border border-[#43d9b8]/30"
        >
          <Cpu size={12} /> Finite-Difference Time-Domain Solver
        </motion.div>
        
        <motion.h1 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-5xl md:text-7xl font-extrabold tracking-tighter mb-8 leading-[1.05] max-w-5xl text-white"
        >
          Deterministic Acoustic <br/>
          <span className="text-[#43d9b8]">Simulation Engine.</span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-lg md:text-xl max-w-2xl mb-12 leading-relaxed text-gray-400"
        >
          An enterprise-grade numerical solver for architects and acoustic engineers. True physical DSP speaker integration, 3D room geometries, and real-time C50/STI analysis.
        </motion.p>
        
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          <button 
            onClick={handleGetStarted}
            className="px-8 py-4 rounded bg-[#43d9b8] text-black font-extrabold text-sm tracking-wider uppercase hover:bg-[#34c7a3] transition-all flex items-center justify-center gap-3 shadow-[0_0_30px_rgba(67,217,184,0.2)]"
          >
            {user ? 'Enter Environment' : 'Deploy Simulator'} <ChevronRight size={16} />
          </button>
        </motion.div>
      </section>

      {/* Analytics / Specs Section */}
      <section className="py-24 border-t border-[#2a2c30] bg-[#0d0e11] relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6 text-white tracking-tight">Precision Data Yields Precision Decisions.</h2>
              <p className="text-gray-400 leading-relaxed mb-8">
                Do not rely on toy algorithms or raw ray-tracing approximations. Cavity Audio employs a dedicated FDTD (Finite-Difference Time-Domain) solver that physically simulates wave propagation across up to 50,000,000 computational grid elements.
              </p>
              
              <ul className="space-y-4">
                {[
                  'True Modulation Transfer Function (MTF) for STI generation',
                  'Manufacturer specifications applied locally',
                  'Adaptive element allocation based on requested Fmax',
                  'Real-time Sabine and Eyring reverberation calculations'
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-gray-300">
                    <Check size={18} className="text-[#43d9b8] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="bg-[#141517] border border-[#2a2c30] rounded-lg p-6 relative overflow-hidden shadow-2xl">
               <div className="absolute top-0 right-0 p-4 opacity-10">
                 <Server size={120} />
               </div>
               <div className="relative z-10 font-mono text-xs text-gray-400 space-y-2">
                 <div className="flex justify-between border-b border-[#2a2c30] pb-2"><span>MODE</span><span className="text-[#43d9b8]">PHYSICAL_SIMULATION</span></div>
                 <div className="flex justify-between border-b border-[#2a2c30] pb-2"><span>ALGORITHM</span><span className="text-white">FDTD WAVE SOLVER</span></div>
                 <div className="flex justify-between border-b border-[#2a2c30] pb-2"><span>MAX_ELEMENTS</span><span className="text-white">50,000,000</span></div>
                 <div className="flex justify-between border-b border-[#2a2c30] pb-2"><span>C50 / C80 / D50</span><span className="text-[#43d9b8] text-[8px] text-right mt-1">COMPUTED FROM SIMULATED IR</span></div>
                 <div className="flex justify-between pb-2"><span>EXPORT</span><span className="text-white">COMPLIANT PDF</span></div>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 border-t border-[#2a2c30] bg-[#0a0a0c]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4 tracking-tight text-white">Engineered for the Acoustician.</h2>
            <p className="text-gray-400 max-w-xl mx-auto">Abandon generalized layout tools. Cavity Audio is designed explicitly for acoustic deployment, validation, and client reporting.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            <FeatureCard 
              icon={<Box size={24} className="text-[#43d9b8]" />}
              title="Database Transducers"
              description="Deploy physical PA arrays and monitors with actual DSP coefficients ingested from manufacturer specs."
            />
            <FeatureCard 
              icon={<ShieldCheck size={24} className="text-[#43d9b8]" />}
              title="Strict Compliance Reporting"
              description="Export raw acoustic data to strict, labeled PDF reports detailing FDTD parameters and confidence intervals."
            />
            <FeatureCard 
              icon={<Zap size={24} className="text-[#43d9b8]" />}
              title="Real-Time Analysis"
              description="Calculate decay metrics instantly via hardware-accelerated computation inside the browser sandbox."
            />
          </div>
        </div>
      </section>

      {/* Pricing / Upsell Section */}
      <section className="py-24 border-t border-[#2a2c30] bg-[#0d0e11]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4 tracking-tight text-white">Commercial Licenses.</h2>
            <p className="text-gray-400 max-w-xl mx-auto mb-8">Scale your simulation capacity with professional access tiers. Secure your computational budget today.</p>
            
            <div className="flex items-center justify-center gap-4">
              <span className={`text-sm font-bold ${billingCycle === 'monthly' ? 'text-white' : 'text-gray-500'}`}>Monthly</span>
              <button 
                onClick={() => setBillingCycle(b => b === 'monthly' ? 'annual' : 'monthly')}
                className="w-14 h-7 bg-[#141517] border border-[#2a2c30] rounded-full relative flex items-center px-1 cursor-pointer transition-all"
              >
                <div className={`w-5 h-5 rounded-full bg-[#43d9b8] transition-all ${billingCycle === 'annual' ? 'translate-x-7' : 'translate-x-0'}`} />
              </button>
              <span className={`text-sm font-bold flex items-center gap-2 ${billingCycle === 'annual' ? 'text-white' : 'text-gray-500'}`}>
                Annual <span className="text-[10px] bg-[#43d9b8]/10 text-[#43d9b8] px-2 py-0.5 rounded uppercase tracking-wider">Save 30%</span>
              </span>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Standard Tier */}
            <div className="bg-[#141517] border border-[#2a2c30] rounded-lg p-8">
              <h3 className="text-xl font-bold text-white mb-2">Standard Access</h3>
              <p className="text-gray-400 text-sm mb-6">For independent engineers and small studios.</p>
              <div className="mb-8">
                <div className="text-3xl font-extrabold text-white">
                  ${billingCycle === 'annual' ? '70' : '100'}
                  <span className="text-sm font-normal text-gray-500"> / month</span>
                </div>
                {billingCycle === 'annual' && <div className="text-xs text-[#43d9b8] mt-1 font-mono tracking-wide">BILLED AT $840 / YEAR</div>}
                {billingCycle === 'monthly' && <div className="text-xs text-transparent mt-1 font-mono tracking-wide select-none">SPACER</div>}
              </div>
              <ul className="space-y-3 mb-8">
                <PricingFeature text="1,000,000 Max Computational Elements" />
                <PricingFeature text="Standard FDTD Simulation Speed" />
                <PricingFeature text="Export Standard PDF Reports" />
                <PricingFeature text="Local Project Persistence" />
              </ul>
              <button 
                onClick={handleGetStarted}
                className="w-full py-3 rounded border border-[#2a2c30] text-white font-bold text-sm tracking-wide hover:bg-[#2a2c30] transition-all"
              >
                Access Standard
              </button>
            </div>
            
            {/* Premium Tier */}
            <div className="bg-[#141517] border border-[#43d9b8] rounded-lg p-8 relative shadow-[0_0_30px_rgba(67,217,184,0.1)]">
              <div className="absolute top-0 right-0 bg-[#43d9b8] text-black text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-bl-lg rounded-tr-lg">Enterprise</div>
              <h3 className="text-xl font-bold text-white mb-2">Pro Simulator</h3>
              <p className="text-[#43d9b8] text-sm mb-6">Unlock maximum resolution. <span className="font-bold">Limited compute nodes available.</span></p>
              <div className="mb-8">
                <div className="text-3xl font-extrabold text-white">
                  ${billingCycle === 'annual' ? '140' : '200'}
                  <span className="text-sm font-normal text-gray-500"> / month</span>
                </div>
                {billingCycle === 'annual' && <div className="text-xs text-[#43d9b8] mt-1 font-mono tracking-wide">BILLED AT $1,680 / YEAR</div>}
                {billingCycle === 'monthly' && <div className="text-xs text-transparent mt-1 font-mono tracking-wide select-none">SPACER</div>}
              </div>
              <ul className="space-y-3 mb-8">
                <PricingFeature text="50,000,000 Max Elements (Compute Budget)" />
                <PricingFeature text="Priority Simulation Queue" />
                <PricingFeature text="Strict Compliance Labeled PDF Reports" />
                <PricingFeature text="Cloud Workspace Syncing" />
              </ul>
              <button 
                onClick={handleGetStarted}
                className="w-full py-3 rounded bg-[#43d9b8] text-black font-bold text-sm tracking-wide hover:bg-[#34c7a3] transition-all shadow-lg shadow-[#43d9b8]/20"
              >
                Deploy Professional License
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#2a2c30] bg-[#0a0a0c] text-center">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-2 text-white">
              <Activity className="text-[#43d9b8]" size={16} />
              <span className="font-bold text-lg tracking-tight uppercase">Cavity Audio</span>
            </div>
            <p className="text-xs text-gray-500 max-w-xl">
              Strictly intended for use by audio engineering professionals. All simulation results are calculated deterministically via physical wave modeling unless otherwise noted. Software is provided "as is", without warranty of any kind.
            </p>
            <div className="text-xs text-gray-600 mt-4">
              &copy; {new Date().getFullYear()} Cavity Audio Systems. All rights reserved. Intellectual Property legally protected under international copyright treaties.
            </div>
          </div>
        </div>
      </footer>

      {/* Auth Modal Mounting */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="p-8 rounded bg-[#141517] border border-[#2a2c30] transition-all hover:border-[#43d9b8]/50 group">
      <div className="w-12 h-12 rounded bg-[#0a0a0c] border border-[#2a2c30] flex items-center justify-center mb-6 group-hover:border-[#43d9b8]/50 transition-colors">
        {icon}
      </div>
      <h3 className="text-lg font-bold mb-3 text-white tracking-tight">{title}</h3>
      <p className="text-sm text-gray-400 leading-relaxed">
        {description}
      </p>
    </div>
  );
}

function PricingFeature({ text }: { text: string }) {
  return (
    <li className="flex items-start gap-3 text-sm text-gray-300">
      <Check size={16} className="text-[#43d9b8] shrink-0 mt-0.5" />
      <span>{text}</span>
    </li>
  );
}
