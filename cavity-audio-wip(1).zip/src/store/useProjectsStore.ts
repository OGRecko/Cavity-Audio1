// Multi-project workspace state. Separate from useStore.ts (the current
// room-editing state) because this manages a different concern: the list of
// projects a user owns and which one is currently loaded. On switching
// projects, this hydrates useStore's existing room/speaker/receiver fields
// from the loaded project's saved data — it does not duplicate or replace
// any of useStore's existing fields or logic.
//
// Backward compatibility: existing users' current work lives in the legacy
// single `user.projectData` slot (still served by GET/POST /api/project,
// untouched). This store's `migrateLegacyIfNeeded()` should be called once
// (e.g. when the projects UI first mounts) to copy that into a real project
// via POST /api/projects/migrate-legacy — it's idempotent and safe to call
// on every mount.

import { create } from 'zustand';
import { useStore } from './useStore';

export interface ProjectSummary {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
}

interface ProjectsState {
  projects: ProjectSummary[];
  activeProjectId: string | null;
  loading: boolean;
  error: string | null;

  fetchProjects: () => Promise<void>;
  migrateLegacyIfNeeded: () => Promise<void>;
  createProject: (name: string) => Promise<string | null>; // returns new id, or null on failure
  switchToProject: (id: string) => Promise<void>;
  renameProject: (id: string, name: string) => Promise<void>;
  archiveProject: (id: string) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  saveCurrentProject: () => Promise<void>; // persist useStore's current room state into the active project
}

// The subset of useStore fields that make up "a project's data" — the same
// shape already used by saveProject()/loadProject()'s local JSON export and
// by the legacy /api/project endpoint, so switching projects and the
// existing file export/import stay consistent with each other.
function extractProjectData() {
  const s = useStore.getState();
  return {
    roomName: s.roomName,
    poly: s.poly,
    L: s.L, W: s.W, H: s.H,
    wallMaterial: s.wallMaterial,
    wallSegMats: s.wallSegMats,
    wallOpenings: s.wallOpenings,
    floorMaterial: s.floorMaterial,
    ceilMaterial: s.ceilMaterial,
    scatter: s.scatter,
    sources: s.sources,
    receivers: s.receivers,
    simulations: s.simulations,
  };
}

function applyProjectData(data: any) {
  if (!data) return;
  // Clamp dimensions the same way useStore's setL/setW/setH already do for
  // normal UI edits (min 0.1) -- this path bypasses those setters entirely
  // (raw set()), so a project loaded from disk with a corrupted/hand-edited
  // 0, negative, or non-finite L/W/H would otherwise reach every downstream
  // consumer (room geometry, audio wall-occlusion math, RT60 calculations)
  // unguarded, producing NaN/Infinity instead of a clear error.
  const safeDim = (v: any, fallback: number) =>
    Number.isFinite(v) && v > 0 ? Math.max(0.1, v) : fallback;
  useStore.setState({
    roomName: data.roomName ?? 'Untitled Room',
    poly: data.poly ?? useStore.getState().poly,
    L: safeDim(data.L, 10), W: safeDim(data.W, 8), H: safeDim(data.H, 3),
    wallMaterial: data.wallMaterial ?? 'drywall',
    wallSegMats: data.wallSegMats ?? [],
    wallOpenings: data.wallOpenings ?? [],
    floorMaterial: data.floorMaterial ?? 'wood_floor',
    ceilMaterial: data.ceilMaterial ?? 'drywall_ceil',
    scatter: data.scatter ?? { walls: 0.15, floor: 0.15, ceiling: 0.15 },
    sources: data.sources ?? [],
    receivers: data.receivers ?? [],
    simulations: data.simulations ?? [],
  });
}

// Module-level (not store state) because it's pure request-sequencing
// bookkeeping, not UI-relevant data -- it doesn't need to trigger re-renders.
const switchRequestRef: { current: string | null } = { current: null };

export const useProjectsStore = create<ProjectsState>((set, get) => ({
  projects: [],
  activeProjectId: null,
  loading: false,
  error: null,

  fetchProjects: async () => {
    set({ loading: true, error: null });
    try {
      const res = await fetch('/api/projects', { credentials: 'include' });
      if (!res.ok) throw new Error(`Failed to load projects (${res.status})`);
      const data = await res.json();
      set({ projects: data.projects || [], activeProjectId: data.activeProjectId || null, loading: false });
    } catch (err: any) {
      set({ loading: false, error: err.message || 'Failed to load projects.' });
    }
  },

  migrateLegacyIfNeeded: async () => {
    try {
      const res = await fetch('/api/projects/migrate-legacy', {
        method: 'POST',
        credentials: 'include',
      });
      const data = await res.json();
      if (data.migrated) {
        await get().fetchProjects();
      }
    } catch {
      // Non-fatal: if migration fails, the user's legacy data is still
      // safe and untouched in the old projectData slot; they just won't
      // see it in the new project list yet. Don't surface a hard error
      // for what's a best-effort convenience migration.
    }
  },

  createProject: async (name: string) => {
    set({ loading: true, error: null });
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, data: extractProjectData() }),
      });
      if (!res.ok) throw new Error(`Failed to create project (${res.status})`);
      const result = await res.json();
      await get().fetchProjects();
      set({ activeProjectId: result.project.id, loading: false });
      return result.project.id;
    } catch (err: any) {
      set({ loading: false, error: err.message || 'Failed to create project.' });
      return null;
    }
  },

  switchToProject: async (id: string) => {
    // Re-entrancy guard: if a switch is already in flight (e.g. a user
    // double-clicks two different projects in the sidebar before the first
    // request resolves), a second call here would race the first -- both
    // read/apply/activate independently, and whichever `set({ activeProjectId })`
    // lands last wins even if it corresponds to the *older* click. Track the
    // most recently requested target id and have each in-flight call check,
    // right before it commits state, whether it's still the latest request;
    // if not, it silently no-ops instead of clobbering a newer switch.
    const requestId = id;
    (switchRequestRef as { current: string | null }).current = requestId;

    set({ loading: true, error: null });
    try {
      // Save whatever's currently loaded before switching away from it, so
      // in-progress edits aren't silently lost.
      if (get().activeProjectId && get().activeProjectId !== id) {
        await get().saveCurrentProject();
      }

      const res = await fetch(`/api/projects/${id}`, { credentials: 'include' });
      if (!res.ok) throw new Error(`Failed to load project (${res.status})`);
      const { project } = await res.json();

      // A newer switchToProject call started while this one was awaiting the
      // fetch above -- let that one own the final state instead.
      if (switchRequestRef.current !== requestId) return;

      applyProjectData(project.data);
      await fetch(`/api/projects/${id}/activate`, { method: 'POST', credentials: 'include' });

      if (switchRequestRef.current !== requestId) return;
      set({ activeProjectId: id, loading: false });
    } catch (err: any) {
      if (switchRequestRef.current !== requestId) return;
      set({ loading: false, error: err.message || 'Failed to switch project.' });
    }
  },

  renameProject: async (id: string, name: string) => {
    try {
      await fetch(`/api/projects/${id}`, {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      await get().fetchProjects();
    } catch (err: any) {
      set({ error: err.message || 'Failed to rename project.' });
    }
  },

  archiveProject: async (id: string) => {
    try {
      await fetch(`/api/projects/${id}/archive`, { method: 'POST', credentials: 'include' });
      await get().fetchProjects();
    } catch (err: any) {
      set({ error: err.message || 'Failed to archive project.' });
    }
  },

  deleteProject: async (id: string) => {
    try {
      const res = await fetch(`/api/projects/${id}`, { method: 'DELETE', credentials: 'include' });
      if (!res.ok) throw new Error(`Failed to delete project (${res.status})`);
      if (get().activeProjectId === id) {
        set({ activeProjectId: null });
      }
      await get().fetchProjects();
    } catch (err: any) {
      set({ error: err.message || 'Failed to delete project.' });
    }
  },

  saveCurrentProject: async () => {
    const id = get().activeProjectId;
    if (!id) return; // nothing to save into yet (e.g. legacy-only user who hasn't created/migrated a project)
    try {
      await fetch(`/api/projects/${id}`, {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data: extractProjectData() }),
      });
    } catch {
      // Best-effort autosave; a failed save here shouldn't block navigation.
      // The user's local useStore state is unaffected either way.
    }
  },
}));
