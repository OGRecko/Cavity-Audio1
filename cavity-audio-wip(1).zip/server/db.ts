import fs from "fs";
import path from "path";
import { db as firestoreDb } from "../src/lib/firebase";
import { doc, getDoc, setDoc } from "firebase/firestore";

// Persistent application state is stored in Firebase Firestore so it survives
// container restarts and redeployments. The current implementation keeps one
// serialized application-state document; it is suitable for the current scale,
// but should be migrated to transactional per-collection documents before
// horizontally scaling the application.

const DB_DOC_REF = doc(firestoreDb, "system_store", "main");

export interface ProjectRecord {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  archived?: boolean;
  data: any;
}

export interface UserRecord {
  uid: string;
  firstName: string;
  lastName: string;
  username: string;
  usernameLower: string;
  email: string;
  emailLower: string;
  passwordHash: string;
  emailVerified: boolean;
  createdAt: number;
  subscriptionStatus: string;
  plan?: string;
  trialStartsAt: number;
  trialEndsAt: number;
  lemonSqueezyCustomerId?: string;
  polarCustomerId?: string;
  projectData?: any;
  projects?: Record<string, ProjectRecord>;
  activeProjectId?: string;
}

export interface VerificationRecord {
  codeHash: string;
  attempts: number;
  expiresAt: number;
  lastSentAt: number;
}

export interface PasswordResetRecord {
  codeHash: string;
  attempts: number;
  expiresAt: number;
  lastSentAt: number;
}

export interface PromoCodeRecord {
  code: string;
  grant: "lifetime";
  createdAt: number;
  createdBy: string;
  note?: string;
  redeemed: boolean;
  redeemedBy?: string;
  redeemedAt?: number;
  revoked?: boolean;
}

export interface DbShape {
  users: Record<string, UserRecord>;
  usernames: Record<string, string>;
  emails: Record<string, string>;
  verificationCodes: Record<string, VerificationRecord>;
  pendingSignups?: Record<string, { user: UserRecord; codeRecord: VerificationRecord }>;
  passwordResets?: Record<string, PasswordResetRecord>;
  promoCodes?: Record<string, PromoCodeRecord>;
}

function emptyDb(): DbShape {
  return { users: {}, usernames: {}, emails: {}, verificationCodes: {}, pendingSignups: {}, passwordResets: {}, promoCodes: {} };
}

// In-memory cache keeps reads fast within one container instance. Do not run
// multiple writable instances without moving state reads/writes to a shared
// transactional model; this cache is intentionally process-local.
let cachedDb: DbShape | null = null;

export async function readDb(): Promise<DbShape> {
  if (cachedDb) return cachedDb;
  
  try {
    const snapshot = await getDoc(DB_DOC_REF);
    if (snapshot.exists()) {
      const data = snapshot.data();
      // Firestore stringifies large blobs sometimes, or it could be a native object
      if (typeof data.payload === 'string') {
         cachedDb = JSON.parse(data.payload) as DbShape;
      } else {
         cachedDb = data.payload as DbShape;
      }
      return cachedDb;
    }
  } catch (e) {
    console.error("Failed to read from Firestore, falling back to empty db:", e);
  }
  
  cachedDb = emptyDb();
  return cachedDb;
}

export async function writeDb(state: DbShape): Promise<void> {
  // IMPORTANT: do not update cachedDb until the Firestore write actually
  // succeeds. Previously this set cachedDb = state BEFORE the write, so a
  // failed write still left the in-memory cache holding the unsaved state —
  // every subsequent readDb() in this process would then silently serve
  // that phantom, never-persisted data as if it had been saved, even though
  // writeDb() throws (correctly) to tell the caller it failed. Persisting
  // first and only updating the cache on success keeps the cache truthful.
  try {
    // We stringify the payload to avoid massive deeply nested object limits in Firestore
    // and easily bypass map field count limitations.
    const payloadStr = JSON.stringify(state);
    await setDoc(DB_DOC_REF, { payload: payloadStr });
    cachedDb = state;
  } catch (e) {
    console.error("Failed to write to Firestore:", e);
    // Never report a successful mutation when persistence actually failed,
    // and never let the cache silently diverge from what's actually
    // persisted. Callers can return an error and the client can retry
    // instead of believing an account/project/payment change was saved.
    throw e;
  }
}
