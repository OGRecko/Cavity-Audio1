import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import crypto from "crypto";
import nodemailer from "nodemailer";
import cookieParser from "cookie-parser";
import { readDb, writeDb, UserRecord } from "./server/db";
import { authRateLimit } from "./server/rateLimit";
import { getAbsorption } from "./src/lib/absorption";
import { generateProjectReport } from "./server/reportGenerator";

// Broadband (500 Hz) absorption lookup for the FDTD solver's per-step
// boundary damping, derived from the shared per-octave-band table in
// src/lib/absorption.ts rather than a second hand-maintained map.
function getAbsorptionAt500Hz(materialId: string): number {
  return getAbsorption(materialId).hz500;
}
import {
  hashPassword,
  verifyPassword,
  generateCode,
  hashCode,
  createSessionToken,
  verifySessionToken,
  SESSION_COOKIE_NAME,
  SESSION_COOKIE_MAX_AGE,
} from "./server/authUtils";

const app = express();
const PORT = 3000;

app.use(cookieParser());

// ---------------------------------------------------------------------------
// Email helpers (SMTP via nodemailer — works with any provider, no Firebase)
// ---------------------------------------------------------------------------

const mailTransporter = process.env.SMTP_HOST
  ? nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: Number(process.env.SMTP_PORT) === 465,
      tls: {
        ciphers: 'SSLv3'
      },
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
    })
  : null;

async function sendVerificationEmail(email: string, firstName: string, code: string): Promise<boolean> {
  const subject = "Your Cavity verification code";
  const text = `Hi ${firstName},\n\nYour Cavity verification code is: ${code}\n\nThis code expires in 15 minutes. If you didn't request this, you can ignore this email.`;
  const html = `<p>Hi ${firstName},</p><p>Your Cavity verification code is:</p><p style="font-size:28px;font-weight:bold;letter-spacing:4px;">${code}</p><p>This code expires in 15 minutes. If you didn't request this, you can ignore this email.</p>`;

  try {
    if (!mailTransporter) {
      // Development-only bypass must be explicitly enabled. Production never
      // auto-verifies an address merely because SMTP is unavailable.
      if (process.env.NODE_ENV !== "production" && process.env.ALLOW_DEV_EMAIL_BYPASS === "true") {
        console.warn(`[dev] SMTP not configured. Verification code for ${email}: ${code}`);
        return false;
      }
      throw new Error("SMTP is not configured.");
    }

    await mailTransporter.sendMail({
      from: process.env.SMTP_FROM || "Cavity <no-reply@cavity.app>",
      to: email,
      subject,
      text,
      html,
    });
    return true; // Sent successfully
  } catch (err) {
    console.error(`SMTP error when sending verification code: ${err}`);
    throw new Error("Failed to send verification email.");
  }
}

async function sendPasswordResetEmail(email: string, firstName: string, code: string): Promise<boolean> {
  const subject = "Reset your Cavity password";
  const text = `Hi ${firstName},\n\nYour Cavity password reset code is: ${code}\n\nThis code expires in 15 minutes. If you didn't request this, you can safely ignore this email — your password will not be changed.`;
  const html = `<p>Hi ${firstName},</p><p>Your Cavity password reset code is:</p><p style="font-size:28px;font-weight:bold;letter-spacing:4px;">${code}</p><p>This code expires in 15 minutes. If you didn't request this, you can safely ignore this email — your password will not be changed.</p>`;

  try {
    if (!mailTransporter) {
      // Mirror sendVerificationEmail's fail-closed behavior: production
      // never silently "succeeds" (nor logs the raw reset code) just
      // because SMTP isn't configured. Only the explicit dev bypass may
      // surface the code, and only outside production.
      if (process.env.NODE_ENV !== "production" && process.env.ALLOW_DEV_EMAIL_BYPASS === "true") {
        console.warn(`[dev] SMTP not configured. Password reset code for ${email}: ${code}`);
        return false;
      }
      throw new Error("SMTP is not configured.");
    }

    await mailTransporter.sendMail({
      from: process.env.SMTP_FROM || "Cavity <no-reply@cavity.app>",
      to: email,
      subject,
      text,
      html,
    });
    return true;
  } catch (err) {
    console.error(`SMTP error when sending password reset code: ${err}`);
    throw new Error("Failed to send password reset email.");
  }
}

const USERNAME_RE = /^[a-zA-Z0-9_]{6,20}$/;
const CODE_TTL_MS = 15 * 60 * 1000; // 15 minutes
const RESEND_COOLDOWN_MS = 60 * 1000; // 1 minute
const TRIAL_MS = 15 * 24 * 60 * 60 * 1000; // 15 days

// ---------------------------------------------------------------------------
// Rate limiters for authentication endpoints (item 23). Combines per-IP and
// per-account throttling with a generic, non-enumerating error message.
// ---------------------------------------------------------------------------
const loginLimiter = authRateLimit({
  routeName: "login",
  windowMs: 15 * 60 * 1000,
  ipMax: 20,
  keyMax: 8,
  getKey: (req) => req.body?.identifier,
});
const signupLimiter = authRateLimit({
  routeName: "signup",
  windowMs: 60 * 60 * 1000,
  ipMax: 10,
});
const forgotPasswordLimiter = authRateLimit({
  routeName: "forgot-password",
  windowMs: 15 * 60 * 1000,
  ipMax: 10,
  keyMax: 5,
  getKey: (req) => req.body?.email,
});
const resetPasswordLimiter = authRateLimit({
  routeName: "reset-password",
  windowMs: 15 * 60 * 1000,
  ipMax: 20,
  keyMax: 10,
  getKey: (req) => req.body?.email,
});
const resendCodeLimiter = authRateLimit({
  routeName: "resend-code",
  windowMs: 15 * 60 * 1000,
  ipMax: 10,
  keyMax: 5,
  getKey: (req) => req.body?.email,
});
const verifyCodeLimiter = authRateLimit({
  routeName: "verify-code",
  windowMs: 15 * 60 * 1000,
  ipMax: 30,
  keyMax: 15,
  getKey: (req) => req.body?.email,
});

function sanitizeUser(user: UserRecord) {
  return {
    uid: user.uid,
    firstName: user.firstName,
    lastName: user.lastName,
    username: user.username,
    email: user.email,
    emailVerified: user.emailVerified,
  };
}

function setSessionCookie(res: any, uid: string, rememberMe: boolean = true) {
  const token = createSessionToken(uid);
  // This app serves its frontend and API from the same Express process/origin
  // (see the static-file + catch-all route at the bottom of this file), so
  // there's no cross-site request that legitimately needs this cookie sent —
  // "lax" (sent on top-level navigation, withheld on cross-site XHR/fetch)
  // is the correct, narrower default here. "none" was carried over from an
  // earlier split-origin assumption that no longer applies; it wasn't
  // exploitable (there's no CORS allowlist granting a foreign origin access
  // to read the response either way), but it was wider than this deployment
  // needs, and would become a real gap the moment anyone adds a permissive
  // CORS middleware later without revisiting this. `secure` still requires
  // HTTPS in production; only relaxed for local HTTP dev.
  const options: any = {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
  };
  if (rememberMe) {
    options.maxAge = SESSION_COOKIE_MAX_AGE;
  }
  res.cookie(SESSION_COOKIE_NAME, token, options);
}

// Requires a valid session cookie. Attaches the full user record to req.user.
async function authMiddleware(req: any, res: any, next: any) {
  const uid = verifySessionToken(req.cookies?.[SESSION_COOKIE_NAME]);
  if (!uid) {
    return res.status(401).json({ error: "Not logged in." });
  }
  const db = await readDb();
  const user = db.users[uid];
  if (!user) {
    res.clearCookie(SESSION_COOKIE_NAME);
    return res.status(401).json({ error: "Not logged in." });
  }
  req.user = user;
  next();
}

// ---------------------------------------------------------------------------
// Heavy-compute guard for the FDTD solver endpoints
// ---------------------------------------------------------------------------
// Node runs JavaScript on a single thread — while one of these endpoints'
// large synchronous nested loops is executing, it blocks the ENTIRE event
// loop, stalling every other request (including other users' logins,
// project saves, everything) until it finishes. Without any protection, a
// single user spamming the "compute" button, or several users triggering
// it at once, can make the whole server unresponsive.
//
// This is a simple, in-memory, single-process guard: per-user cooldown
// (reject a new request if their last one hasn't been outside the cooldown
// window) plus a global concurrency cap (reject if too many heavy
// computations are already in flight across all users). It is NOT a
// substitute for a real job queue or moving this work to worker threads —
// see the note below — but it prevents the most obvious abuse/pile-up
// cases cheaply, with no new dependency.
//
// LIMITATION: this state lives in a single Node process's memory. It does
// NOT coordinate across multiple server instances (e.g. behind a load
// balancer) — each instance would enforce its own limits independently.
// If this app ever runs more than one server process, replace this with a
// shared store (Redis, etc.) or move the actual computation to a proper
// background job queue.
const SOLVER_COOLDOWN_MS = 3000; // minimum time between one user's solver requests
const MAX_CONCURRENT_SOLVER_JOBS = 2; // global cap across all users, on this process
const lastSolverRequestAt = new Map<string, number>();
let activeSolverJobs = 0;

function solverGuard(req: any, res: any, next: any) {
  const uid = req.user?.uid;
  const now = Date.now();

  if (activeSolverJobs >= MAX_CONCURRENT_SOLVER_JOBS) {
    return res.status(429).json({ error: "The server is already computing another simulation. Please try again in a moment." });
  }
  const last = uid ? lastSolverRequestAt.get(uid) : undefined;
  if (last && now - last < SOLVER_COOLDOWN_MS) {
    return res.status(429).json({ error: `Please wait ${Math.ceil((SOLVER_COOLDOWN_MS - (now - last)) / 1000)}s before running another simulation.` });
  }
  if (uid) lastSolverRequestAt.set(uid, now);

  activeSolverJobs++;
  // Decrement once the response is actually sent, whether it succeeded,
  // errored, or the client disconnected — 'finish' and 'close' cover all
  // of those cases so activeSolverJobs can never get stuck incremented.
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
    activeSolverJobs = Math.max(0, activeSolverJobs - 1);
  };
  res.on('finish', release);
  res.on('close', release);

  next();
}

import { Polar } from '@polar-sh/sdk';

// Polar integration
const polar = new Polar({
  accessToken: process.env.POLAR_ACCESS_TOKEN,
});

// Maps a Polar product_id from a webhook event to this app's internal plan
// tier. Previously this only checked against the Premium product IDs and
// treated everything else as "standard" by default -- an assumption, not a
// check, which meant a misconfigured or unrecognized product_id (including
// a genuine third tier added later) would silently get bucketed as
// "standard" with no visibility into that happening. Now Standard product
// IDs are checked explicitly too, and a product_id matching neither tier is
// logged rather than silently guessed at, so a configuration problem shows
// up in the logs instead of quietly mis-granting access.
function resolvePlanFromProductId(pId: string | undefined): 'premium' | 'standard' | null {
  if (pId === process.env.VITE_POLAR_PREMIUM_MONTHLY_PRODUCT_ID || pId === process.env.VITE_POLAR_PREMIUM_ANNUAL_PRODUCT_ID) {
    return 'premium';
  }
  if (pId === process.env.VITE_POLAR_STANDARD_MONTHLY_PRODUCT_ID || pId === process.env.VITE_POLAR_STANDARD_ANNUAL_PRODUCT_ID) {
    return 'standard';
  }
  console.error(`[Polar webhook] Unrecognized product_id "${pId}" — refusing to assign a plan. Check VITE_POLAR_*_PRODUCT_ID env vars.`);
  return null;
}

app.post("/api/webhooks/polar", express.raw({ type: '*/*' }), async (req: any, res: any) => {
  const secret = process.env.POLAR_WEBHOOK_SECRET;
  if (!secret) {
    return res.status(500).json({ error: "Webhook secret not configured" });
  }

  // Verify the Standard Webhooks signature Polar sends (webhook-id,
  // webhook-timestamp, webhook-signature headers; HMAC-SHA256 over
  // "{id}.{timestamp}.{raw body}") before trusting ANYTHING in the payload.
  // This previously only checked that a secret was configured and then
  // processed req.body directly with no verification at all -- meaning
  // anyone who knew (or guessed) a user's uid could POST a fake
  // "subscription.created" event and grant themselves premium for free.
  // Verification must run against the exact raw request bytes, not
  // re-serialized JSON (a re-stringified object is not guaranteed to be
  // byte-identical to what Polar signed), which is why this route now uses
  // express.raw() instead of express.json() -- express.json() discards the
  // raw body after parsing.
  //
  // IMPORTANT: the `@polar-sh/sdk/webhooks` import path and `validateEvent`
  // name below are based on published third-party integration guides
  // (Polar follows the Standard Webhooks spec), NOT independently confirmed
  // against the installed package version in this environment -- this repo
  // has no network access to install/inspect node_modules here. CONFIRM
  // this import actually resolves and validateEvent behaves as described
  // (reject on bad/missing signature, return the parsed event on success)
  // against your installed @polar-sh/sdk version before relying on this in
  // production; if the SDK's actual export differs, replace this block with
  // a hand-rolled Standard Webhooks HMAC-SHA256 check over
  // `${webhook-id}.${webhook-timestamp}.${rawBody}` using crypto.timingSafeEqual
  // (see server/authUtils.ts for the timing-safe comparison pattern already
  // used elsewhere in this codebase). Either way, never remove this
  // verification step -- the endpoint fails closed (403) if it throws,
  // which is the safe default while that's being confirmed.
  let event: any;
  try {
    const { validateEvent } = await import('@polar-sh/sdk/webhooks');
    event = validateEvent(req.body, req.headers, secret);
  } catch (err: any) {
    console.error("Polar webhook signature verification failed:", err?.message || err);
    return res.status(403).json({ error: "Invalid webhook signature" });
  }

  const payload = event;
  const eventName = payload.type;
  const data = payload.data;
  
  // Custom metadata we pass during checkout
  const userId = data.custom_field_data?.uid;

  try {
    const db = await readDb();
    const user = userId ? db.users[userId] : null;

    if (user && eventName === "subscription.created") {
      const plan = resolvePlanFromProductId(data.product_id);
      if (!plan) return res.status(400).json({ error: "Unrecognized Polar product." });
      user.subscriptionStatus = "active";
      user.polarCustomerId = data.customer_id;
      user.plan = plan;
      await writeDb(db);
    } else if (user && eventName === "subscription.updated") {
       const plan = resolvePlanFromProductId(data.product_id);
       if (!plan) return res.status(400).json({ error: "Unrecognized Polar product." });
       user.subscriptionStatus = data.status === "active" ? "active" : "canceled";
       user.plan = plan;
       await writeDb(db);
    } else if (user && (eventName === "subscription.canceled" || eventName === "subscription.revoked")) {
      user.subscriptionStatus = "canceled";
      await writeDb(db);
    }
  } catch (err) {
    console.error("Error processing Polar webhook:", err);
  }

  res.json({ received: true });
});

// JSON middleware for other routes
app.use(express.json());

// ---------------------------------------------------------------------------
// Sign up: create the account, reserve the username, email a verification code
// ---------------------------------------------------------------------------
app.post("/api/auth/signup", signupLimiter, async (req: any, res: any) => {
  try {
    let { firstName, lastName, username, email, password } = req.body || {};

    firstName = String(firstName || "").trim();
    lastName = String(lastName || "").trim();
    username = String(username || "").trim();
    email = String(email || "").trim().toLowerCase();

    if (!firstName || !lastName) {
      return res.status(400).json({ error: "First and last name are required." });
    }
    if (!USERNAME_RE.test(username)) {
      return res.status(400).json({ error: "Username must be 6-20 characters: letters, numbers, or underscores." });
    }
    if (!email || !email.includes("@")) {
      return res.status(400).json({ error: "A valid email address is required." });
    }
    if (!password || String(password).length < 6) {
      return res.status(400).json({ error: "Password must be at least 6 characters." });
    }

    const usernameLower = username.toLowerCase();
    const db = await readDb();

    if (db.usernames[usernameLower]) {
      return res.status(409).json({ error: "That username is already taken." });
    }
    if (db.emails[email]) {
      return res.status(409).json({ error: "An account with that email already exists." });
    }

    const uid = crypto.randomUUID();
    const now = Date.now();
    const user: UserRecord = {
      uid,
      firstName,
      lastName,
      username,
      usernameLower,
      email,
      emailLower: email,
      passwordHash: hashPassword(password),
      emailVerified: false,
      createdAt: now,
      subscriptionStatus: "none",
      trialStartsAt: 0,
      trialEndsAt: 0,
    };

    const code = generateCode();
    if (!db.pendingSignups) db.pendingSignups = {};
    db.pendingSignups[email] = {
      user,
      codeRecord: {
        codeHash: hashCode(code),
        attempts: 0,
        expiresAt: now + CODE_TTL_MS,
        lastSentAt: now,
      }
    };
    await writeDb(db);

    const emailSent = await sendVerificationEmail(email, firstName, code);

    if (!emailSent) {
      // This is reachable only when the explicit development-only bypass is
      // enabled. Production refuses this path inside sendVerificationEmail().
      const freshDb = await readDb();
      const pending = freshDb.pendingSignups?.[email];
      if (!pending) {
        return res.status(409).json({ error: "Signup expired or was replaced. Please try again." });
      }
      pending.user.emailVerified = true;
      freshDb.users[pending.user.uid] = pending.user;
      freshDb.usernames[pending.user.usernameLower] = pending.user.uid;
      freshDb.emails[pending.user.emailLower] = pending.user.uid;
      delete freshDb.pendingSignups![email];
      await writeDb(freshDb);
      setSessionCookie(res, pending.user.uid);
      return res.json({ autoVerified: true, user: sanitizeUser(pending.user) });
    }

    res.json({ pendingEmail: email });
  } catch (err: any) {
    console.error("Signup error:", err);
    res.status(500).json({ error: err.message || "Signup failed." });
  }
});

// ---------------------------------------------------------------------------
// Log in with either email or username, plus password
// ---------------------------------------------------------------------------
app.post("/api/auth/login", loginLimiter, async (req: any, res: any) => {
  try {
    let { identifier, password, rememberMe } = req.body || {};
    identifier = String(identifier || "").trim();
    password = String(password || "");

    if (!identifier || !password) {
      return res.status(400).json({ error: "Enter your email/username and password." });
    }

    const db = await readDb();
    const uid = identifier.includes("@")
      ? db.emails[identifier.toLowerCase()]
      : db.usernames[identifier.toLowerCase()];

    const user = uid ? db.users[uid] : null;
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return res.status(401).json({ error: "Incorrect email/username or password." });
    }

    setSessionCookie(res, user.uid, rememberMe !== false);
    res.json({ user: sanitizeUser(user) });
  } catch (err: any) {
    console.error("Login error:", err);
    res.status(500).json({ error: err.message || "Login failed." });
  }
});

// ---------------------------------------------------------------------------
// Start Trial
// ---------------------------------------------------------------------------
app.post("/api/auth/start-trial", authMiddleware, async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];
  if (user.subscriptionStatus !== "none" && user.subscriptionStatus !== "trialing") {
    return res.status(400).json({ error: "Trial already used or active subscription." });
  }
  const now = Date.now();
  user.subscriptionStatus = "trialing";
  user.trialStartsAt = now;
  user.trialEndsAt = now + TRIAL_MS;
  await writeDb(db);
  res.json({ success: true, user: sanitizeUser(user) });
});

// ---------------------------------------------------------------------------
// Auto-save Project
// ---------------------------------------------------------------------------
app.get("/api/project", authMiddleware, async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];
  res.json({ projectData: user.projectData || null });
});

app.post("/api/project", authMiddleware, express.json({limit: '10mb'}), async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];
  user.projectData = req.body.projectData;
  await writeDb(db);
  res.json({ success: true });
});

// ---------------------------------------------------------------------------
// MULTI-PROJECT WORKSPACE
// ---------------------------------------------------------------------------
// Additive on top of the legacy single-project endpoints above, which are
// left untouched. `user.projects` is undefined for any user who hasn't
// created a project through this new flow yet — every handler below treats
// that as "no projects" rather than throwing.

app.get("/api/projects", authMiddleware, async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];
  const projects = Object.values(user.projects || {})
    .filter((p: any) => !p.archived)
    .sort((a: any, b: any) => b.updatedAt - a.updatedAt)
    .map((p: any) => ({ id: p.id, name: p.name, createdAt: p.createdAt, updatedAt: p.updatedAt }));
  res.json({ projects, activeProjectId: user.activeProjectId || null });
});

app.post("/api/projects", authMiddleware, express.json({ limit: '10mb' }), async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];
  const name = String(req.body.name || 'Untitled Project').slice(0, 200);
  const id = crypto.randomUUID();
  const now = Date.now();

  if (!user.projects) user.projects = {};
  user.projects[id] = {
    id,
    name,
    createdAt: now,
    updatedAt: now,
    data: req.body.data ?? null,
  };
  user.activeProjectId = id;
  await writeDb(db);
  res.json({ success: true, project: user.projects[id] });
});

app.get("/api/projects/:id", authMiddleware, async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];
  const project = user.projects?.[req.params.id];
  if (!project || project.archived) return res.status(404).json({ error: "Project not found." });
  res.json({ project });
});

app.put("/api/projects/:id", authMiddleware, express.json({ limit: '10mb' }), async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];
  const project = user.projects?.[req.params.id];
  if (!project || project.archived) return res.status(404).json({ error: "Project not found." });

  if (req.body.name != null) project.name = String(req.body.name).slice(0, 200);
  if (req.body.data !== undefined) project.data = req.body.data;
  project.updatedAt = Date.now();
  await writeDb(db);
  res.json({ success: true, project });
});

app.post("/api/projects/:id/archive", authMiddleware, async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];
  const project = user.projects?.[req.params.id];
  if (!project) return res.status(404).json({ error: "Project not found." });

  // Soft delete: archive rather than remove, so a mistaken delete is
  // recoverable and we never silently destroy a client's project data.
  project.archived = true;
  project.updatedAt = Date.now();
  if (user.activeProjectId === req.params.id) {
    const remaining = Object.values(user.projects || {}).filter((p: any) => !p.archived && p.id !== req.params.id);
    user.activeProjectId = remaining.length > 0 ? remaining[0].id : undefined;
  }
  await writeDb(db);
  res.json({ success: true });
});

app.post("/api/projects/:id/activate", authMiddleware, async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];
  const project = user.projects?.[req.params.id];
  if (!project || project.archived) return res.status(404).json({ error: "Project not found." });
  user.activeProjectId = req.params.id;
  await writeDb(db);
  res.json({ success: true });
});

// Hard delete: permanently removes the project record (unlike /archive,
// which just hides it). Meant for archived projects the user wants gone
// for good, but works on any project id the user owns.
app.delete("/api/projects/:id", authMiddleware, async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];
  const project = user.projects?.[req.params.id];
  if (!project) return res.status(404).json({ error: "Project not found." });

  delete user.projects![req.params.id];
  if (user.activeProjectId === req.params.id) {
    const remaining = Object.values(user.projects || {}).filter((p: any) => !p.archived);
    user.activeProjectId = remaining.length > 0 ? remaining[0].id : undefined;
  }
  await writeDb(db);
  res.json({ success: true });
});

// One-time, idempotent migration: copy the legacy single `projectData` blob
// into the new `projects` map as a real project, so existing users' current
// work is preserved rather than orphaned when they start using multiple
// projects. The client should call this once (e.g. on first visit to a
// "Projects" screen) rather than the server doing it automatically on every
// request. Safe to call more than once — it no-ops if the user already has
// any projects or has no legacy data to migrate.
app.post("/api/projects/migrate-legacy", authMiddleware, async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];

  if (user.projects && Object.keys(user.projects).length > 0) {
    return res.json({ migrated: false, reason: "User already has projects." });
  }
  if (!user.projectData) {
    return res.json({ migrated: false, reason: "No legacy project data to migrate." });
  }

  const id = crypto.randomUUID();
  const now = Date.now();
  user.projects = {
    [id]: {
      id,
      name: 'My Project',
      createdAt: now,
      updatedAt: now,
      data: user.projectData,
    },
  };
  user.activeProjectId = id;
  await writeDb(db);
  res.json({ migrated: true, project: user.projects[id] });
});

// ---------------------------------------------------------------------------
// Google Sign In
// ---------------------------------------------------------------------------
app.post("/api/auth/google", async (req: any, res: any) => {
  try {
    const { idToken, accessToken } = req.body;
    if (!idToken && !accessToken) return res.status(400).json({ error: "Missing token" });

    const clientId = process.env.VITE_GOOGLE_CLIENT_ID;
    
    let tokenInfo: any = {};
    if (accessToken) {
      const verifyRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      tokenInfo = await verifyRes.json().catch(() => ({ error: "invalid_response" }));
    } else {
      const verifyRes = await fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + idToken);
      tokenInfo = await verifyRes.json().catch(() => ({ error: "invalid_response" }));
      // The tokeninfo endpoint verifies the token's signature and expiry for
      // us, but NOT which app it was issued for — that's on us to check, or
      // any valid Google ID token from any app would let someone log in as
      // that token's email. accessToken userinfo doesn't have this problem
      // since possessing a working access token already proves it was
      // issued to whichever app requested it.
      if (clientId && tokenInfo.aud !== clientId) {
        return res.status(401).json({ error: "Invalid Google token" });
      }
    }
    
    if (tokenInfo.error || !tokenInfo.email || tokenInfo.email_verified === "false" || tokenInfo.email_verified === false) {
      return res.status(401).json({ error: "Invalid Google token" });
    }
    
    const email = tokenInfo.email.toLowerCase();
    const googleUid = tokenInfo.sub; // Google's unique ID for the user
    
    const db = await readDb();
    let uid = db.emails[email];
    let user;
    
    if (uid) {
      // Existing user
      user = db.users[uid];
      user.emailVerified = true;
    } else {
      // New user
      uid = crypto.randomUUID();
      const now = Date.now();
      
      const firstName = tokenInfo.given_name || "Google";
      const lastName = tokenInfo.family_name || "User";
      let baseUsername = (firstName + lastName).replace(/[^a-zA-Z0-9_]/g, "").substring(0, 15) || "user";
      if (baseUsername.length < 6) baseUsername += "123456";
      let username = baseUsername;
      let counter = 1;
      while (db.usernames[username.toLowerCase()]) {
        username = baseUsername + counter;
        counter++;
      }
      
      user = {
        uid,
        firstName,
        lastName,
        username,
        usernameLower: username.toLowerCase(),
        email,
        emailLower: email,
        passwordHash: "", // No password for Google users
        emailVerified: true,
        createdAt: now,
        subscriptionStatus: "none",
        trialStartsAt: 0,
        trialEndsAt: 0,
      };
      
      db.users[uid] = user;
      db.usernames[user.usernameLower] = uid;
      db.emails[email] = uid;
    }
    
    await writeDb(db);
    setSessionCookie(res, uid);
    res.json({ user: sanitizeUser(user) });
  } catch (err: any) {
    console.error("Google Login error:", err);
    res.status(500).json({ error: err.message || "Login failed." });
  }
});

app.post("/api/auth/logout", (req: any, res: any) => {
  res.clearCookie(SESSION_COOKIE_NAME);
  res.json({ success: true });
});

// ---------------------------------------------------------------------------
// Verify the emailed code and activate the account (requires being logged in)
// ---------------------------------------------------------------------------
app.post("/api/auth/verify-code", verifyCodeLimiter, async (req: any, res: any) => {
  try {
    const { code, email } = req.body || {};
    if (!code) return res.status(400).json({ error: "Enter the code from your email." });

    const uid = verifySessionToken(req.cookies?.[SESSION_COOKIE_NAME]);
    const db = await readDb();
    
    // Check pending signups if not logged in or explicitly passed email
    if (email && db.pendingSignups && db.pendingSignups[email.toLowerCase()]) {
      const pending = db.pendingSignups[email.toLowerCase()];
      const record = pending.codeRecord;
      if (record.expiresAt < Date.now()) return res.status(400).json({ error: "That code has expired. Request a new one." });
      if (record.attempts >= 5) return res.status(429).json({ error: "Too many incorrect attempts. Request a new code." });
      if (hashCode(String(code).trim()) !== record.codeHash) {
        record.attempts += 1;
        await writeDb(db);
        return res.status(400).json({ error: "Incorrect code. Please try again." });
      }
      
      // Success! Move to users
      const user = pending.user;
      user.emailVerified = true;
      db.users[user.uid] = user;
      db.usernames[user.usernameLower] = user.uid;
      db.emails[user.emailLower] = user.uid;
      delete db.pendingSignups[email.toLowerCase()];
      await writeDb(db);
      
      setSessionCookie(res, user.uid);
      return res.json({ user: sanitizeUser(user) });
    }

    // Otherwise check logged-in unverified user
    if (!uid) return res.status(401).json({ error: "No pending verification found." });
    
    const record = db.verificationCodes[uid];
    if (!record) return res.status(400).json({ error: "No pending verification for this account. Request a new code." });
    if (record.expiresAt < Date.now()) return res.status(400).json({ error: "That code has expired. Request a new one." });
    if (record.attempts >= 5) return res.status(429).json({ error: "Too many incorrect attempts. Request a new code." });
    if (hashCode(String(code).trim()) !== record.codeHash) {
      record.attempts += 1;
      await writeDb(db);
      return res.status(400).json({ error: "Incorrect code. Please try again." });
    }

    db.users[uid].emailVerified = true;
    delete db.verificationCodes[uid];
    await writeDb(db);
    return res.json({ user: sanitizeUser(db.users[uid]) });
  } catch (err: any) {
    console.error("Verify code error:", err);
    res.status(500).json({ error: err.message || "Verification failed." });
  }
});

// ---------------------------------------------------------------------------
// Resend a fresh verification code
// ---------------------------------------------------------------------------
app.post("/api/auth/resend-code", resendCodeLimiter, async (req: any, res: any) => {
  try {
    const { email } = req.body || {};
    const uid = verifySessionToken(req.cookies?.[SESSION_COOKIE_NAME]);
    const db = await readDb();
    
    let user;
    let record;
    let pendingEmail = false;

    if (email && db.pendingSignups && db.pendingSignups[email.toLowerCase()]) {
      user = db.pendingSignups[email.toLowerCase()].user;
      record = db.pendingSignups[email.toLowerCase()].codeRecord;
      pendingEmail = true;
    } else if (uid) {
      user = db.users[uid];
      if (!user) return res.status(404).json({ error: "User not found." });
      if (user.emailVerified) return res.json({ success: true, alreadyVerified: true });
      record = db.verificationCodes[uid];
    } else {
      return res.status(404).json({ error: "No pending verification found." });
    }

    if (record && Date.now() - record.lastSentAt < RESEND_COOLDOWN_MS) {
      return res.status(429).json({ error: "Please wait 60 seconds before requesting another code." });
    }

    const code = generateCode();
    const newRecord = {
      codeHash: hashCode(code),
      attempts: 0,
      expiresAt: Date.now() + CODE_TTL_MS,
      lastSentAt: Date.now(),
    };

    if (pendingEmail && email && db.pendingSignups?.[email.toLowerCase()]) {
      db.pendingSignups[email.toLowerCase()].codeRecord = newRecord;
    } else if (uid) {
      db.verificationCodes[uid] = newRecord;
    }
    
    await writeDb(db);

    const emailSent = await sendVerificationEmail(user.email, user.firstName, code);
    // Mirrors forgot-password's handling below: sendVerificationEmail()
    // returns false (rather than throwing) only when SMTP is unconfigured
    // AND the explicit dev bypass is enabled — a legitimate, intentional
    // path, not a failure. Treating it as an error here (as this used to)
    // broke the resend flow in local/dev environments even though the code
    // was actually generated and logged. Only a real send failure (SMTP
    // configured but erroring) should surface as a 500, and that already
    // throws out of sendVerificationEmail and lands in the catch block below.
    if (!emailSent && mailTransporter) {
      return res.status(500).json({ error: "Failed to send verification email. Please check SMTP settings." });
    }

    res.json({ success: true });
  } catch (err: any) {
    console.error("Resend code error:", err);
    res.status(500).json({ error: err.message || "Could not resend code." });
  }
});

// ---------------------------------------------------------------------------
// Password reset: request a code (works whether logged in or not — the
// email address is the identifier, matching how signup/verify already
// work). Always responds success even for unknown emails, so this can't be
// used to enumerate which addresses have accounts.
// ---------------------------------------------------------------------------
app.post("/api/auth/forgot-password", forgotPasswordLimiter, express.json(), async (req: any, res: any) => {
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    if (!email) return res.status(400).json({ error: "Enter your email address." });

    const db = await readDb();
    const uid = db.emails[email];
    const user = uid ? db.users[uid] : null;

    // Don't reveal whether the account exists — always return success, but
    // only actually send an email (and create a reset record) if it does.
    if (!user) {
      return res.json({ success: true });
    }

    if (!db.passwordResets) db.passwordResets = {};
    const existing = db.passwordResets[user.uid];
    if (existing && Date.now() - existing.lastSentAt < RESEND_COOLDOWN_MS) {
      return res.status(429).json({ error: "Please wait 60 seconds before requesting another code." });
    }

    const code = generateCode();
    db.passwordResets[user.uid] = {
      codeHash: hashCode(code),
      attempts: 0,
      expiresAt: Date.now() + CODE_TTL_MS,
      lastSentAt: Date.now(),
    };
    await writeDb(db);

    // sendPasswordResetEmail now fails closed: it throws on any real SMTP
    // failure (or when SMTP is unconfigured outside of the explicit dev
    // bypass), and only returns `false` for the intentional dev-bypass path.
    // Because we've already established the account exists (the early
    // return above handles unknown emails), surfacing a genuine send
    // failure here does not create an account-enumeration issue.
    await sendPasswordResetEmail(user.email, user.firstName, code);

    res.json({ success: true });
  } catch (err: any) {
    console.error("Forgot password error:", err);
    res.status(500).json({ error: "Failed to send reset email. Please try again shortly." });
  }
});

// Verify the reset code and set a new password in one step.
app.post("/api/auth/reset-password", resetPasswordLimiter, express.json(), async (req: any, res: any) => {
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const code = String(req.body?.code || "").trim();
    const newPassword = String(req.body?.newPassword || "");

    if (!email || !code) return res.status(400).json({ error: "Enter your email and the code from your email." });
    if (newPassword.length < 6) return res.status(400).json({ error: "Password must be at least 6 characters." });

    const db = await readDb();
    const uid = db.emails[email];
    const user = uid ? db.users[uid] : null;
    const record = uid ? db.passwordResets?.[uid] : null;

    if (!user || !record) {
      return res.status(400).json({ error: "Invalid or expired reset code. Request a new one." });
    }
    if (record.expiresAt < Date.now()) {
      return res.status(400).json({ error: "That code has expired. Request a new one." });
    }
    if (record.attempts >= 5) {
      return res.status(429).json({ error: "Too many incorrect attempts. Request a new code." });
    }
    if (hashCode(code) !== record.codeHash) {
      record.attempts += 1;
      await writeDb(db);
      return res.status(400).json({ error: "Incorrect code. Please try again." });
    }

    user.passwordHash = hashPassword(newPassword);
    delete db.passwordResets![uid!];
    await writeDb(db);

    // Log the user in immediately, same as the other post-verification flows.
    setSessionCookie(res, user.uid);
    res.json({ success: true, user: sanitizeUser(user) });
  } catch (err: any) {
    console.error("Reset password error:", err);
    res.status(500).json({ error: err.message || "Could not reset password." });
  }
});

// Get the current session's user + subscription status
app.get("/api/me", authMiddleware, async (req: any, res: any) => {
  const user = req.user as UserRecord;
  res.json({
    user: sanitizeUser(user),
    subscriptionStatus: user.subscriptionStatus,
    trialStartsAt: user.trialStartsAt,
    trialEndsAt: user.trialEndsAt,
    plan: user.plan,
  });
});

// Redeem custom promo code (bypasses Lemon Squeezy for lifetime access)
app.post("/api/redeem", authMiddleware, async (req: any, res: any) => {
  try {
    const { code: rawCode } = req.body;
    const code = String(rawCode || "").trim();
    const db = await readDb();
    const user = db.users[req.user.uid];

    if (code === 'Monthly10' || code === 'Yearly10') {
      return res.status(400).json({ error: "Please enter this code directly on the Lemon Squeezy checkout page." });
    }

    // Per-recipient single-use codes minted via /api/admin/promo-codes,
    // replacing the old hardcoded 'FFGFREE' shared string (which, being a
    // literal in source, had no real secrecy and granted lifetime access to
    // anyone who ever saw this file). A code here is looked up by its exact
    // value, checked for prior redemption/revocation, then marked redeemed
    // -- so a single leaked code only ever grants one account, and any
    // unredeemed code can be revoked individually without affecting others.
    const promo = db.promoCodes?.[code];
    if (!promo || promo.revoked) {
      return res.status(400).json({ error: "Invalid or expired promo code." });
    }
    if (promo.redeemed) {
      return res.status(400).json({ error: "This promo code has already been used." });
    }

    // Set lifetime access
    const futureDate = new Date();
    futureDate.setFullYear(futureDate.getFullYear() + 100);

    user.subscriptionStatus = "active";
    user.plan = "lifetime";
    user.trialEndsAt = futureDate.getTime();

    promo.redeemed = true;
    promo.redeemedBy = user.uid;
    promo.redeemedAt = Date.now();

    await writeDb(db);

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// PROMO CODE ADMINISTRATION (mint/list/revoke single-use lifetime codes)
// ---------------------------------------------------------------------------
// Constant-time secret comparison. Guards against timing side-channels that
// a naive `===` string comparison leaks (early-exit on first differing
// byte). Requires equal-length buffers, so length is checked separately
// via a fixed-cost comparison first (returning early on length mismatch is
// safe -- it doesn't leak anything about the secret's *content*, only a
// length differential an attacker could get by other means anyway).
function timingSafeStringEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a, "utf8");
  const bufB = Buffer.from(b, "utf8");
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

const adminGuardLimiter = authRateLimit({
  routeName: "admin-guard",
  windowMs: 15 * 60 * 1000,
  ipMax: 20,
});

// Gated by a standalone ADMIN_SECRET env var (a bearer-style shared secret
// for whoever operates this deployment), not by any user account/role --
// there's no admin-user concept elsewhere in this codebase, and adding one
// just for this would be a bigger change than the promo-code problem calls
// for. If ADMIN_SECRET isn't set, these routes refuse everything (fail
// closed) rather than falling back to "no auth required".
function adminGuard(req: any, res: any, next: any) {
  const configured = process.env.ADMIN_SECRET;
  if (!configured) {
    return res.status(500).json({ error: "Admin endpoints are not configured (ADMIN_SECRET is unset)." });
  }
  const provided = req.header("x-admin-secret");
  if (!provided || !timingSafeStringEqual(provided, configured)) {
    return res.status(401).json({ error: "Unauthorized." });
  }
  next();
}

// Mint one or more new single-use lifetime promo codes.
// Body: { count?: number (default 1, max 200), note?: string }
app.post("/api/admin/promo-codes", adminGuardLimiter, express.json(), adminGuard, async (req: any, res: any) => {
  const count = Math.min(Math.max(Number(req.body?.count) || 1, 1), 200);
  const note = req.body?.note ? String(req.body.note).slice(0, 200) : undefined;

  const db = await readDb();
  if (!db.promoCodes) db.promoCodes = {};

  const minted: string[] = [];
  for (let i = 0; i < count; i++) {
    // Readable-but-unguessable: an 8-char base32-ish code from random bytes,
    // checked against existing codes (and this batch) to rule out collision.
    let code: string;
    do {
      code = crypto.randomBytes(6).toString("base64url").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10);
    } while (db.promoCodes[code]);

    db.promoCodes[code] = {
      code,
      grant: "lifetime",
      createdAt: Date.now(),
      createdBy: "admin",
      note,
      redeemed: false,
    };
    minted.push(code);
  }

  await writeDb(db);
  res.json({ success: true, codes: minted });
});

// List all promo codes and their redemption status (no pagination -- fine
// for the realistic volume of a self-hosted admin tool; revisit if this
// ever needs to scale past a few thousand codes).
app.get("/api/admin/promo-codes", adminGuardLimiter, adminGuard, async (_req: any, res: any) => {
  const db = await readDb();
  const codes = Object.values(db.promoCodes || {}).sort((a, b) => b.createdAt - a.createdAt);
  res.json({ codes });
});

// Revoke an unredeemed code so it can no longer be used. No-op (still
// succeeds) if the code is already redeemed or revoked, or doesn't exist --
// the end state the caller wants ("this code doesn't work") is already true.
app.post("/api/admin/promo-codes/:code/revoke", adminGuardLimiter, adminGuard, async (req: any, res: any) => {
  const db = await readDb();
  const promo = db.promoCodes?.[req.params.code];
  if (promo && !promo.redeemed) {
    promo.revoked = true;
    await writeDb(db);
  }
  res.json({ success: true });
});

// Create checkout session
app.post("/api/checkout", authMiddleware, async (req: any, res: any) => {
  const db = await readDb();
  const user = db.users[req.user.uid];
  const accessToken = process.env.POLAR_ACCESS_TOKEN;

  if (!accessToken) {
    return res.status(500).json({ error: "Polar Access Token is not configured." });
  }

  try {
    const { priceId } = req.body;
    const email = user.email;

    const checkout = await (polar.checkouts as any).create({
      productId: priceId,
      customerEmail: email,
      customerName: `${user.firstName} ${user.lastName}`.trim(),
      customFieldData: { uid: user.uid },
    });

    res.json({ url: checkout.url });
  } catch (err: any) {
    console.error("Polar Checkout Error:", err);
    res.status(500).json({ error: err.message });
  }
});

// Create customer portal session
app.post("/api/portal", authMiddleware, async (req: any, res: any) => {
  const accessToken = process.env.POLAR_ACCESS_TOKEN;
  if (!accessToken) return res.status(500).json({ error: "Polar not configured" });

  try {
    const db = await readDb();
    const user = db.users[req.user.uid];
    
    if (!user.polarCustomerId) {
        return res.status(400).json({ error: "No active billing profile found." });
    }

    const session = await polar.customerSessions.create({
      customerId: user.polarCustomerId,
    });

    res.json({ url: session.customerPortalUrl });
  } catch (err: any) {
    console.error("Polar Portal Error:", err);
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// REPORT EXPORT (PDF)
// ---------------------------------------------------------------------------
// Generates a client-ready PDF report from room/speaker/receiver data the
// client sends directly in the request, mirroring the pattern used by
// /api/solver/wave rather than reading from the (unstructured) persisted
// user.projectData blob. No plan-gating here yet — this is intentionally
// left open pending the pricing/tier decision discussed separately; add a
// isPro-style check here (see /api/solver/wave for the pattern) once the
// Professional tier is actually introduced.
// NOTE on architecture (item 16 in the security brief): a fully auditable
// design would have the server own the simulation result end-to-end (client
// requests a run -> server stores the result under a simulationId -> report
// references that stored result only). That's a real data-model change
// (persisted simulation records) beyond what this pass makes, per the
// "don't turn this into an endless redesign" instruction and to avoid an
// unverified schema change. What IS fixed here: (1) invalid input is
// rejected with 400 instead of silently replaced with a plausible-looking
// default (the `Number(x) || 10` pattern this used to use), and (2) the
// report is tagged with a server-computed integrity hash over its inputs,
// signed with a server-only secret, so a client-fabricated/edited report
// can at least be detected as such later (the hash won't verify) even
// though the server doesn't yet independently re-run the simulation.
function parseFiniteInRange(value: any, min: number, max: number, label: string): number {
  const n = Number(value);
  if (!Number.isFinite(n)) throw new Error(`${label} must be a finite number.`);
  if (n < min || n > max) throw new Error(`${label} must be between ${min} and ${max}.`);
  return n;
}

app.post("/api/report/export", express.json({ limit: '10mb' }), authMiddleware, async (req: any, res: any) => {
  try {
    const { projectName, roomName, room, speakers, receivers, solverResult, assumedSnrDb } = req.body;

    if (!room || !Array.isArray(room.poly) || !room.poly.length) {
      return res.status(400).json({ error: "Room geometry (poly, L, W, H, materials) is required to generate a report." });
    }

    let L: number, W: number, H: number, parsedSnr: number | undefined;
    try {
      L = parseFiniteInRange(room.L, 0.1, 100, "Room length (L)");
      W = parseFiniteInRange(room.W, 0.1, 100, "Room width (W)");
      H = parseFiniteInRange(room.H, 0.1, 30, "Room height (H)");
      if (assumedSnrDb != null) {
        parsedSnr = parseFiniteInRange(assumedSnrDb, -20, 120, "Assumed SNR");
      }
    } catch (validationErr: any) {
      return res.status(400).json({ error: validationErr.message });
    }

    const reportRoom = {
      poly: room.poly,
      L, W, H,
      wallMaterial: room.wallMaterial || 'drywall',
      wallSegMats: Array.isArray(room.wallSegMats) ? room.wallSegMats : [],
      floorMaterial: room.floorMaterial || 'wood_floor',
      ceilMaterial: room.ceilMaterial || 'drywall_ceil',
    };
    const reportSpeakers = Array.isArray(speakers) ? speakers : [];
    const reportReceivers = Array.isArray(receivers) ? receivers : [];
    const generatedAt = new Date().toISOString();

    // Integrity hash: HMAC over the exact inputs used to generate this PDF,
    // keyed with a server-only secret (falls back to SESSION_SECRET if a
    // dedicated one isn't set — both are server-only env vars, never sent
    // to the client). Anyone re-deriving this value would need that secret,
    // so a client can't forge a hash that matches edited data.
    const integritySecret = process.env.REPORT_INTEGRITY_SECRET || process.env.SESSION_SECRET || "";
    const hashPayload = JSON.stringify({ reportRoom, reportSpeakers, reportReceivers, solverResult: solverResult || null, parsedSnr, generatedAt, uid: req.user.uid });
    const simulationHash = integritySecret
      ? crypto.createHmac("sha256", integritySecret).update(hashPayload).digest("hex").slice(0, 32)
      : null;

    const doc = generateProjectReport({
      projectName: String(projectName || 'Untitled Project'),
      roomName: String(roomName || 'Untitled Room'),
      room: reportRoom,
      speakers: reportSpeakers,
      receivers: reportReceivers,
      solverResult: solverResult || null,
      assumedSnrDb: parsedSnr,
      generatedForEmail: req.user.email,
      generatedAt,
      simulationHash: simulationHash || undefined,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${(projectName || 'cavity-report').replace(/[^a-z0-9\-_]/gi, '_')}.pdf"`);
    doc.pipe(res);
  } catch (err: any) {
    console.error("Report Export Error:", err);
    res.status(500).json({ error: err.message || "Failed to generate report." });
  }
});

// ---------------------------------------------------------------------------
// PRO-GRADE WAVE SOLVER (FDTD) API
// ---------------------------------------------------------------------------
app.post("/api/solver/wave", express.json(), authMiddleware, solverGuard, async (req: any, res: any) => {
  const { elements, steps, L, W, H, wallMaterial, floorMaterial, ceilMaterial, source, receiver } = req.body;

  // Server-side tier enforcement is authoritative. Free accounts are capped at
  // 1M elements; premium/lifetime accounts at 50M. These are hard server caps,
  // independent of any client-side budget hint.
  const isPro = req.user.plan === 'premium' || req.user.plan === 'lifetime';
  const hardCap = isPro ? 50000000 : 1000000;
  
  const roomL = Number(L);
  const roomW = Number(W);
  const roomH = Number(H);
  if (![roomL, roomW, roomH].every(Number.isFinite) || roomL <= 0 || roomW <= 0 || roomH <= 0 || roomL > 100 || roomW > 100 || roomH > 30) {
    return res.status(400).json({ error: "Room dimensions must be finite positive values within safe limits (L/W <= 100 m, H <= 30 m)." });
  }

  const accuracyMode = String(req.body.accuracyMode || 'balanced');
  const ppwMap: Record<string, number> = { fast: 5, balanced: 9, high: 13 };
  if (!(accuracyMode in ppwMap)) {
    return res.status(400).json({ error: "accuracyMode must be fast, balanced, or high." });
  }
  const pointsPerWavelength = ppwMap[accuracyMode];

  const targetFmax = req.body.fmax == null ? 500 : Number(req.body.fmax);
  if (!Number.isFinite(targetFmax) || targetFmax <= 0 || targetFmax > 24000) {
    return res.status(400).json({ error: "fmax must be a finite frequency between 1 Hz and 24 kHz." });
  }

  const rawSteps = req.body.steps == null ? 40 : Number(req.body.steps);
  if (!Number.isFinite(rawSteps) || !Number.isInteger(rawSteps) || rawSteps < 1 || rawSteps > 200) {
    return res.status(400).json({ error: "steps must be an integer between 1 and 200." });
  }
  const numStepsRequested = rawSteps;
  const speedOfSound = 343;
  
  const requiredDx = speedOfSound / (pointsPerWavelength * targetFmax);
  const requiredNx = Math.max(4, Math.ceil(roomL / requiredDx));
  const requiredNy = Math.max(4, Math.ceil(roomH / requiredDx));
  const requiredNz = Math.max(4, Math.ceil(roomW / requiredDx));
  const requiredElements = requiredNx * requiredNy * requiredNz;

  if (requiredElements > hardCap && !req.body.confirmReducedResolution) {
      const supportedElements = hardCap;
      const actualFmax = speedOfSound / (pointsPerWavelength * Math.cbrt((roomL * roomW * roomH) / supportedElements));
      
      return res.status(422).json({
          requiresConfirmation: true,
          message: `Requested ${targetFmax} Hz simulation at ${accuracyMode.toUpperCase()} accuracy requires ${requiredElements.toLocaleString()} elements, which exceeds your tier's safe limit of ${hardCap.toLocaleString()}.

Current configuration safely supports up to ~${Math.round(actualFmax)} Hz.

Continue with reduced resolution?`,
          requestedFmax: targetFmax,
          supportedFmax: actualFmax,
          requestedResolution: requiredDx,
          supportedResolution: Math.cbrt((roomL * roomW * roomH) / supportedElements),
          estimatedMemoryMb: Math.round(supportedElements * 4 * 3 / 1024 / 1024),
      });
  }
  
  let dx = requiredDx;
  if (requiredElements > hardCap) {
    const rawCellVolume = (roomL * roomH * roomW) / hardCap;
    dx = Math.cbrt(rawCellVolume);
  }
  dx = Math.max(dx, 0.02); // absolute 2 cm cell floor

  let nx = Math.max(4, Math.round(roomL / dx));
  let ny = Math.max(4, Math.round(roomH / dx));
  let nz = Math.max(4, Math.round(roomW / dx));
  let N = nx * ny * nz;

  // Rounding can push the actual grid slightly above the element budget.
  // Increase the cell size until the FINAL allocated grid is within the cap.
  if (N > hardCap) {
    dx = Math.max(dx, Math.cbrt((roomL * roomW * roomH) / hardCap));
    nx = Math.max(4, Math.floor(roomL / dx));
    ny = Math.max(4, Math.floor(roomH / dx));
    nz = Math.max(4, Math.floor(roomW / dx));
    N = nx * ny * nz;
  }
  if (N > hardCap) {
    return res.status(422).json({ error: "The final FDTD grid exceeds the server safety limit." });
  }

  // Report capability from the ACTUAL final grid spacing, not a theoretical
  // element-volume estimate that can differ after rounding/clamping.
  const actualFmax = speedOfSound / (pointsPerWavelength * dx);
  const numSteps = numStepsRequested;
  const reducedResolution = actualFmax + 1e-9 < targetFmax;
  const nxy = nx * ny;

  // Per-surface absorption -> per-axis boundary damping. Higher absorption
  // = more energy lost when the wave reflects off that surface, instead of
  // one flat damping constant applied everywhere.
  //
  // Single-value-per-material here is a simplification: real absorption is
  // frequency-dependent (see src/lib/absorption.ts for the full per-octave-
  // band table, which is the shared source of truth this map is derived
  // from). Time-domain FDTD boundary damping needs one broadband coefficient
  // per step, so this uses each material's 500 Hz value — the standard
  // reference frequency for a material's general absorptive character —
  // rather than maintaining a second, independently-tuned set of numbers.
  // If you're changing absorption values, change them in absorption.ts and
  // regenerate this block; don't hand-edit these numbers separately.
  const wallAbs = getAbsorptionAt500Hz(wallMaterial);
  const floorAbs = getAbsorptionAt500Hz(floorMaterial);
  const ceilAbs = getAbsorptionAt500Hz(ceilMaterial);
  // Reflection coefficient per boundary: sqrt(1 - absorption) is the usual
  // pressure-reflection approximation from the energy absorption coefficient.
  const wallRefl = Math.sqrt(Math.max(1 - wallAbs, 0));
  const floorRefl = Math.sqrt(Math.max(1 - floorAbs, 0));
  const ceilRefl = Math.sqrt(Math.max(1 - ceilAbs, 0));

  // Convert the normalized (0..1) source/listener coordinates the 3D view
  // uses into real grid indices, instead of always firing the impulse from
  // dead-center of the volume.
  const clamp01 = (v: number) => Math.min(0.98, Math.max(0.02, v));
  const srcX = clamp01(source?.x ?? 0.5), srcZ = clamp01(source?.y ?? 0.5);
  const srcIx = Math.round(srcX * (nx - 1));
  const srcIy = Math.round((source?.z != null ? clamp01(source.z / roomH) : 0.7) * (ny - 1));
  const srcIz = Math.round(srcZ * (nz - 1));
  const srcIdx = srcIy * nxy + srcIz * nx + srcIx;

  const recX = clamp01(receiver?.x ?? 0.25), recZ = clamp01(receiver?.y ?? 0.5);
  const recIx = Math.round(recX * (nx - 1));
  const recIy = Math.round((receiver?.z != null ? clamp01(receiver.z / roomH) : 0.5) * (ny - 1));
  const recIz = Math.round(recZ * (nz - 1));
  const recIdx = recIy * nxy + recIz * nx + recIx;

  // STAGE 14: Stability & Numerical Validation (Geometry & Positions)
  // Moved inside the try block below (this used to throw() before the try
  // started, which meant these validation errors were unhandled — Express
  // would surface a raw unhandled-exception 500 with no JSON body / stack
  // trace exposure instead of the clean `{ error: ... }` response the catch
  // block below is meant to produce for every other failure in this route).
  try {
    if (isNaN(N) || !isFinite(N) || N <= 0) throw new Error("Invalid geometry calculations resulted in NaN/Infinity elements.");
    if (srcIx < 0 || srcIx >= nx || srcIy < 0 || srcIy >= ny || srcIz < 0 || srcIz >= nz) {
      throw new Error("Invalid source position: placed outside the computational boundary.");
    }
    if (recIx < 0 || recIx >= nx || recIy < 0 || recIy >= ny || recIz < 0 || recIz >= nz) {
      throw new Error("Invalid receiver position: placed outside the computational boundary.");
    }

    console.log(`[WAVE SOLVER] Room ${roomL}x${roomW}x${roomH}m -> FDTD grid ${nx}x${ny}x${nz} (${N.toLocaleString()} elements, dx=${dx.toFixed(3)}m). Steps: ${numSteps}. Tier: ${isPro ? 'pro' : 'free'}.`);

    const startTime = Date.now();

    const p_prev = new Float32Array(N);
    const p = new Float32Array(N);
    const p_next = new Float32Array(N);

    // Initial condition: impulse at the room's actual source position.
    p[Math.max(0, Math.min(N - 1, srcIdx))] = 1.0;

    const Courant = 0.1; // Stability coefficient for this scheme (Courant^2 = (c*dt/dx)^2, well inside the 3D CFL limit of 1/3)
    // dt must be derived FROM Courant, not independently set to dx/c: the
    // update equation below implements p_next = 2p - p_prev + Courant*laplacian,
    // which is only the correct discretization of the wave equation
    // (d^2p/dt^2 = c^2 * laplacian(p)) if Courant == (c*dt/dx)^2. Reporting
    // dt = dx/c (implying Courant=1.0, three times past the actual stability
    // limit) while the loop below actually runs at Courant=0.1 previously
    // made every downstream "seconds" value (RT60-from-decay, trace
    // duration) wrong by a factor of 1/sqrt(0.1) =~ 3.16x -- fixed by
    // deriving dt from the Courant number the physics loop actually uses.
    const dt = (dx * Math.sqrt(Courant)) / 343;
    const receiverTrace: number[] = [];

    for (let t = 0; t < numSteps; t++) {
      for (let iy = 1; iy < ny - 1; iy++) {
        for (let iz = 1; iz < nz - 1; iz++) {
          const rowBase = iy * nxy + iz * nx;
          for (let ix = 1; ix < nx - 1; ix++) {
            const i = rowBase + ix;
            p_next[i] = (2 * p[i]) - p_prev[i] + Courant * (
              p[i - 1] + p[i + 1] +
              p[i - nx] + p[i + nx] +
              p[i - nxy] + p[i + nxy] -
              (6 * p[i])
            );
          }
        }
      }

      // Boundary reflection: attenuate the outermost shell by each real
      // surface's reflection coefficient (floor = y0, ceiling = yTop,
      // walls = the four x/z faces) instead of one global damping constant.
      for (let iz = 0; iz < nz; iz++) {
        for (let ix = 0; ix < nx; ix++) {
          p_next[0 * nxy + iz * nx + ix] *= floorRefl;
          p_next[(ny - 1) * nxy + iz * nx + ix] *= ceilRefl;
        }
      }
      for (let iy = 0; iy < ny; iy++) {
        for (let ix = 0; ix < nx; ix++) {
          p_next[iy * nxy + 0 * nx + ix] *= wallRefl;
          p_next[iy * nxy + (nz - 1) * nx + ix] *= wallRefl;
        }
        for (let iz = 0; iz < nz; iz++) {
          p_next[iy * nxy + iz * nx + 0] *= wallRefl;
          p_next[iy * nxy + iz * nx + (nx - 1)] *= wallRefl;
        }
      }

      receiverTrace.push(Math.abs(p_next[Math.max(0, Math.min(N - 1, recIdx))]));

      p_prev.set(p);
      p.set(p_next);
    }

    // Estimate RT60 from the actual simulated decay at the receiver (time for
    // the envelope to fall 60dB, extrapolated from however much decay the
    // step budget captured) as a sanity cross-check against the Sabine
    // estimate used elsewhere in the app.
    //
    // IMPORTANT: search for the -30dB point starting from the peak index,
    // not from index 0. Searching from the start is wrong — the receiver is
    // silent before the direct sound even arrives (especially when source
    // and receiver aren't co-located), and that pre-arrival silence is
    // already below the -30dB threshold, so a naive findIndex from 0 would
    // immediately "detect decay" during a period where sound hasn't arrived
    // yet, producing a bogus near-zero RT60 instead of a real one.
    const peakIdx = receiverTrace.indexOf(Math.max(...receiverTrace, 0));
    const peak = receiverTrace[peakIdx] || 1e-9;
    const decayIdxRelative = receiverTrace.slice(peakIdx).findIndex(v => v < peak * Math.pow(10, -30 / 20));
    let simulatedRt60: number | null = null;
    if (decayIdxRelative > 0) {
      simulatedRt60 = (decayIdxRelative * dt) * 2; // extrapolate -30dB point to -60dB
    }
    // This quick-preview run is far too short (numSteps <= 40, ~1-1.5ms of
    // simulated time) to ever actually reach a real -30dB decay in a
    // typical room (RT60 is usually 300-2000ms) — decayIdxRelative will
    // almost always be -1 here (no decay observed), which is the CORRECT,
    // honest outcome given the step budget. Do not be surprised that
    // simulatedRt60 is usually null; that's not a bug, it's the actual
    // limitation being surfaced instead of hidden. Use
    // /api/solver/impulse-response (below) for a run that's actually long
    // enough to produce a meaningful decay-based RT60/C50/C80/Ts.

    const volume = roomL * roomW * roomH;
    const wallArea = 2 * (roomL * roomH) + 2 * (roomW * roomH);
    const floorArea = roomL * roomW;
    const ceilArea = roomL * roomW;
    const totalSabins = (wallArea * wallAbs) + (floorArea * floorAbs) + (ceilArea * ceilAbs);
    const sabineRt60 = (0.161 * volume) / Math.max(totalSabins, 0.01);

    const endTime = Date.now();
    const durationMs = endTime - startTime;

    res.json({
      success: true,
      meshSize: N,
      gridDims: [nx, ny, nz],
      actualFmax: actualFmax,
      targetFmax: targetFmax,
      reducedResolution,
      requestedElements: requiredElements,
      cellSizeM: dx,
      steps: numSteps,
      durationMs,
      rt60: sabineRt60,
      simulatedRt60,
      tier: isPro ? 'pro' : 'free',
      // Real per-step receiver pressure trace, exposed so the client can
      // derive genuine C50/C80/D50/Ts/STI instead of placeholder numbers.
      // dtEstimate lets the client convert sample index -> seconds.
      receiverTrace: Array.from(receiverTrace),
      dtEstimate: dt,
      message: `Computed ${numSteps} time steps over a ${nx}x${ny}x${nz} grid (${N.toLocaleString()} elements) matching your ${roomL}x${roomW}x${roomH}m room in ${durationMs}ms.`
    });

  } catch (err: any) {
    console.error("Wave Solver Error:", err);
    res.status(500).json({ error: err.message || "Engine memory limit exceeded." });
  }
});

// ---------------------------------------------------------------------------
// IMPULSE RESPONSE / DECAY-METRIC SOLVER
// ---------------------------------------------------------------------------
// The endpoint above is a quick preview run: it prioritizes a fine spatial
// grid (up to 30M elements) but, as a direct consequence of that fine grid,
// can only afford a handful of time steps (numSteps <= 40) before a single
// HTTP request would take too long — which means it only ever simulates
// roughly 1-1.5ms of real time. That's nowhere near enough for RT60
// (typically 300-2000ms), C50/C80 (need >= 80ms of IR), or Ts to mean
// anything; it was being computed from a trace that hadn't even let sound
// leave the source region yet.
//
// RT60/C50/C80/D50/Ts are TEMPORAL decay metrics — they don't need a fine
// spatial mesh to be physically valid, they need enough SIMULATED TIME.
// This endpoint deliberately trades spatial resolution for step count: a
// small, coarse grid (a few thousand to tens of thousands of elements,
// regardless of the visual-quality tier) that can run thousands of cheap
// steps instead of dozens of expensive ones, reaching real reverberation
// timescales.
//
// Step count is derived from this room's OWN Sabine RT60 estimate (using
// the same absorption data as everywhere else in the app) so short/dead
// rooms don't waste time simulating far past their decay, and
// long/reverberant rooms get enough steps to actually capture their tail.
// Hard-capped regardless, since this is still a synchronous request with no
// progress reporting — if that cap is hit before 2x the estimated RT60 is
// reached, the response says so explicitly rather than silently truncating.
app.post("/api/solver/impulse-response", express.json(), authMiddleware, solverGuard, async (req: any, res: any) => {
  const { L, W, H, wallMaterial, floorMaterial, ceilMaterial, source, receiver } = req.body;

  const roomL = Number(L) > 0 ? Number(L) : 10;
  const roomW = Number(W) > 0 ? Number(W) : 8;
  const roomH = Number(H) > 0 ? Number(H) : 3;

  const wallAbs = getAbsorptionAt500Hz(wallMaterial);
  const floorAbs = getAbsorptionAt500Hz(floorMaterial);
  const ceilAbs = getAbsorptionAt500Hz(ceilMaterial);

  // Estimate this room's RT60 up front (same Sabine formula used elsewhere)
  // purely to size the run — how many steps are actually needed to reach
  // ~2x the expected decay time, so short/absorptive rooms don't run
  // needlessly long and reverberant rooms get a real tail.
  const volume = roomL * roomW * roomH;
  const wallArea = 2 * (roomL * roomH) + 2 * (roomW * roomH);
  const floorArea = roomL * roomW;
  const ceilArea = roomL * roomW;
  const totalSabins = (wallArea * wallAbs) + (floorArea * floorAbs) + (ceilArea * ceilAbs);
  const estimatedRt60 = (0.161 * volume) / Math.max(totalSabins, 0.01);
  const targetDurationSec = Math.min(estimatedRt60 * 2, 3); // cap target at 3s even for very live rooms

  // Deliberately coarse, fixed-small grid — independent of plan tier, since
  // decay-metric accuracy here depends on step count, not mesh fineness.
  // ~15,000 elements keeps each step cheap enough to run thousands of them
  // synchronously. This is a genuine, documented engineering trade-off
  // (coarse mesh, long duration) for decay analysis, not a shortcut to look
  // more finished than it is.
  const targetElements = 15000;
  // For RT60 we just use a target elements approach because fmax is not provided by the UI for this background task.
  const rawCellVolume = volume / targetElements;
  const dx = Math.max(Math.cbrt(rawCellVolume), 0.05); // coarser floor (5cm) than the preview solver
  const nx = Math.max(4, Math.round(roomL / dx));
  const ny = Math.max(4, Math.round(roomH / dx));
  const nz = Math.max(4, Math.round(roomW / dx));
  const N = nx * ny * nz;
  const nxy = nx * ny;

  // dt must match the Courant coefficient the update loop below actually
  // uses (0.1), not an independent dx/c estimate -- see the /api/solver/wave
  // endpoint above for the full derivation of why Courant^2 = (c*dt/dx)^2 is
  // required for these two numbers to describe the same physics.
  const COURANT = 0.1;
  const dt = (dx * Math.sqrt(COURANT)) / 343;
  const stepsForTarget = Math.ceil(targetDurationSec / dt);
  // Hard cap on steps regardless of target, to bound worst-case request
  // time since this is still synchronous with no progress reporting.
  // NOTE: this cap was not empirically benchmarked in this environment (no
  // ability to run Node here) — treat it as a starting point and tune
  // based on real request latency once deployed.
  const MAX_STEPS = 6000;
  const numSteps = Math.min(stepsForTarget, MAX_STEPS);
  const reachedTarget = stepsForTarget <= MAX_STEPS;

  const wallRefl = Math.sqrt(Math.max(1 - wallAbs, 0));
  const floorRefl = Math.sqrt(Math.max(1 - floorAbs, 0));
  const ceilRefl = Math.sqrt(Math.max(1 - ceilAbs, 0));

  const clamp01 = (v: number) => Math.min(0.98, Math.max(0.02, v));
  const srcX = clamp01(source?.x ?? 0.5), srcZ = clamp01(source?.y ?? 0.5);
  const srcIx = Math.round(srcX * (nx - 1));
  const srcIy = Math.round((source?.z != null ? clamp01(source.z / roomH) : 0.7) * (ny - 1));
  const srcIz = Math.round(srcZ * (nz - 1));
  const srcIdx = srcIy * nxy + srcIz * nx + srcIx;

  const recX = clamp01(receiver?.x ?? 0.25), recZ = clamp01(receiver?.y ?? 0.5);
  const recIx = Math.round(recX * (nx - 1));
  const recIy = Math.round((receiver?.z != null ? clamp01(receiver.z / roomH) : 0.5) * (ny - 1));
  const recIz = Math.round(recZ * (nz - 1));
  const recIdx = recIy * nxy + recIz * nx + recIx;

  // STAGE 14: Stability & Numerical Validation (Geometry & Positions)
  // Moved inside the try block below — see /api/solver/wave above for why
  // throwing before the try starts breaks the route's error handling.
  try {
    if (isNaN(N) || !isFinite(N) || N <= 0) throw new Error("Invalid geometry calculations resulted in NaN/Infinity elements.");
    if (srcIx < 0 || srcIx >= nx || srcIy < 0 || srcIy >= ny || srcIz < 0 || srcIz >= nz) {
      throw new Error("Invalid source position: placed outside the computational boundary.");
    }
    if (recIx < 0 || recIx >= nx || recIy < 0 || recIy >= ny || recIz < 0 || recIz >= nz) {
      throw new Error("Invalid receiver position: placed outside the computational boundary.");
    }

    console.log(`[IMPULSE RESPONSE SOLVER] Room ${roomL}x${roomW}x${roomH}m -> coarse grid ${nx}x${ny}x${nz} (${N.toLocaleString()} elements, dx=${dx.toFixed(3)}m). Steps: ${numSteps}/${stepsForTarget} (target ${targetDurationSec.toFixed(2)}s).`);

    const startTime = Date.now();
    const p_prev = new Float32Array(N);
    const p = new Float32Array(N);
    const p_next = new Float32Array(N);
    p[Math.max(0, Math.min(N - 1, srcIdx))] = 1.0;

    const Courant = COURANT; // must match the COURANT used to derive dt above, or dt mislabels the trace's real time axis
    const receiverTrace: number[] = [];

    for (let t = 0; t < numSteps; t++) {
      for (let iy = 1; iy < ny - 1; iy++) {
        for (let iz = 1; iz < nz - 1; iz++) {
          const rowBase = iy * nxy + iz * nx;
          for (let ix = 1; ix < nx - 1; ix++) {
            const i = rowBase + ix;
            p_next[i] = (2 * p[i]) - p_prev[i] + Courant * (
              p[i - 1] + p[i + 1] +
              p[i - nx] + p[i + nx] +
              p[i - nxy] + p[i + nxy] -
              (6 * p[i])
            );
          }
        }
      }

      for (let iz = 0; iz < nz; iz++) {
        for (let ix = 0; ix < nx; ix++) {
          p_next[0 * nxy + iz * nx + ix] *= floorRefl;
          p_next[(ny - 1) * nxy + iz * nx + ix] *= ceilRefl;
        }
      }
      for (let iy = 0; iy < ny; iy++) {
        for (let ix = 0; ix < nx; ix++) {
          p_next[iy * nxy + 0 * nx + ix] *= wallRefl;
          p_next[iy * nxy + (nz - 1) * nx + ix] *= wallRefl;
        }
        for (let iz = 0; iz < nz; iz++) {
          p_next[iy * nxy + iz * nx + 0] *= wallRefl;
          p_next[iy * nxy + iz * nx + (nx - 1)] *= wallRefl;
        }
      }

      receiverTrace.push(Math.abs(p_next[Math.max(0, Math.min(N - 1, recIdx))]));

      p_prev.set(p);
      p.set(p_next);
    }

    const peakIdx = receiverTrace.indexOf(Math.max(...receiverTrace, 0));
    const peak = receiverTrace[peakIdx] || 1e-9;
    const decayIdxRelative = receiverTrace.slice(peakIdx).findIndex(v => v < peak * Math.pow(10, -30 / 20));
    let simulatedRt60: number | null = null;
    if (decayIdxRelative > 0) {
      simulatedRt60 = (decayIdxRelative * dt) * 2;
    }

    const actualDurationSec = numSteps * dt;
    const sabineRt60 = estimatedRt60;
    const durationMs = Date.now() - startTime;

    res.json({
      success: true,
      meshSize: N,
      gridDims: [nx, ny, nz],
      cellSizeM: dx,
      steps: numSteps,
      requestedSteps: stepsForTarget,
      reachedTarget,
      actualDurationSec,
      targetDurationSec,
      computeTimeMs: durationMs,
      rt60: sabineRt60,
      simulatedRt60,
      receiverTrace: Array.from(receiverTrace),
      dtEstimate: dt,
      warning: reachedTarget
        ? null
        : `Simulation was capped at ${numSteps} steps (${actualDurationSec.toFixed(2)}s simulated) before reaching the ${targetDurationSec.toFixed(2)}s target for this room's estimated decay time. RT60/C50/C80/Ts derived from this trace may understate the room's true reverberance.`,
      message: `Computed ${numSteps} time steps (${actualDurationSec.toFixed(2)}s simulated, coarse ${nx}x${ny}x${nz} grid) in ${durationMs}ms.`
    });
  } catch (err: any) {
    console.error("Impulse Response Solver Error:", err);
    res.status(500).json({ error: err.message || "Impulse response computation failed." });
  }
});

async function startServer() {
  // The DB (server/db.ts) is a single JSON file on local disk. That's fine
  // on a host with a real persistent filesystem, but on most container/
  // serverless platforms (e.g. a fresh container per deploy, or per
  // invocation) the local disk does NOT survive a restart or redeploy --
  // every signup, project, and promo code minted since the last deploy
  // would silently vanish, with no error at the time it happens. This can't
  // be detected reliably from inside the process, so this is a loud
  // reminder rather than a hard failure: read it once at boot, verify your
  // hosting platform actually persists ./data across restarts (a mounted
  // volume, not the default ephemeral container disk) before relying on
  // this in production.
  if (process.env.NODE_ENV === "production") {
    console.warn(
      "[startup] Using a local JSON file as the database (server/db.ts). " +
      "Confirm your hosting platform mounts ./data on PERSISTENT storage -- " +
      "on ephemeral/serverless platforms this data is lost on every restart or redeploy."
    );
  }

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => res.sendFile(path.join(distPath, 'index.html')));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
