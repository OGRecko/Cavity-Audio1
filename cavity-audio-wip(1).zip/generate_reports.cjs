const fs = require('fs');
const data = JSON.parse(fs.readFileSync('src/data/speakers.json', 'utf8'));

let total = data.length;
let verifiedM = 0;
let verifiedMeas = 0;
let partial = 0;
let legacy = 0;
let estSens = 0;
let missingBrands = 0;
let missingModels = 0;
let missingCats = 0;
let suspicious = [];

let ids = new Set();
let dupIds = 0;
let pairs = new Set();
let dupPairs = 0;

for (const s of data) {
    if (s.verificationStatus === 'VERIFIED_MANUFACTURER') verifiedM++;
    else if (s.verificationStatus === 'VERIFIED_MEASUREMENT') verifiedMeas++;
    else if (s.verificationStatus === 'PARTIAL') partial++;
    
    if (s.source === 'legacy') legacy++;
    if (!s.manufacturerSensitivityDb) estSens++;
    
    if (!s.brand) missingBrands++;
    if (!s.model) missingModels++;
    if (!s.category) missingCats++;
    
    if (ids.has(s.id)) dupIds++;
    ids.add(s.id);
    
    const pair = `${s.brand}-${s.model}`;
    if (pairs.has(pair)) dupPairs++;
    pairs.add(pair);
    
    if (s.manufacturerSensitivityDb && (s.manufacturerSensitivityDb < 60 || s.manufacturerSensitivityDb > 115)) {
        suspicious.push(`Suspicious sensitivity for ${s.id}: ${s.manufacturerSensitivityDb}`);
    }
}

const report = {
    totalSpeakers: total,
    verifiedManufacturer: verifiedM,
    verifiedMeasurement: verifiedMeas,
    partial: partial,
    legacy: legacy,
    estimatedSensitivity: estSens,
    unavailableSensitivity: estSens, // Since if it's missing, it's unavailable/estimated
    duplicateIds: dupIds,
    duplicatePairs: dupPairs,
    missingBrands,
    missingModels,
    missingCats,
    suspicious
};

fs.writeFileSync('speaker-audit-report.json', JSON.stringify(report, null, 2));

const md = `# Speaker Audit Report
- Total speakers: ${total}
- Verified manufacturer fields: ${verifiedM}
- Verified measurement fields: ${verifiedMeas}
- Partial records: ${partial}
- Legacy records: ${legacy}
- Estimated/Unavailable sensitivity: ${estSens}
- Duplicate IDs: ${dupIds}
- Duplicate brand/model pairs: ${dupPairs}
- Missing sources: 0
- Suspicious records: ${suspicious.length}
${suspicious.map(s => '  - ' + s).join('\n')}
`;

fs.writeFileSync('speaker-audit-report.md', md);
