const fs = require('fs');
const data = JSON.parse(fs.readFileSync('src/data/speakers.json'));

let suspicious = [];

for (const s of data) {
    if (!s.id) suspicious.push(`${s.id}: Missing ID`);
    if (!s.brand) suspicious.push(`${s.id}: Missing brand`);
    if (!s.model) suspicious.push(`${s.id}: Missing model`);
    if (!s.category) suspicious.push(`${s.id}: Missing category`);
    
    if (s.freqLow_hz !== undefined && s.freqHigh_hz !== undefined) {
        if (s.freqLow_hz <= 0) suspicious.push(`${s.id}: freqLow_hz <= 0`);
        if (s.freqHigh_hz <= 0) suspicious.push(`${s.id}: freqHigh_hz <= 0`);
        if (s.freqLow_hz >= s.freqHigh_hz) suspicious.push(`${s.id}: freqLow_hz >= freqHigh_hz`);
    }

    if (s.power_w !== undefined && s.power_w < 0) suspicious.push(`${s.id}: power_w < 0`);
    if (s.impedance_ohm !== undefined && s.impedance_ohm <= 0) suspicious.push(`${s.id}: impedance_ohm <= 0`);
    if (s.woofer_in !== undefined && s.woofer_in <= 0 && s.category !== 'line-array' && !s.panel) suspicious.push(`${s.id}: woofer_in <= 0 and not a panel/line array`);
    if (s.driverCount !== undefined && s.driverCount < 1) suspicious.push(`${s.id}: driverCount < 1`);

    if (s.manufacturerSensitivityDb !== undefined && s.manufacturerSensitivityDb !== null) {
        if (typeof s.manufacturerSensitivityDb !== 'number') suspicious.push(`${s.id}: manufacturerSensitivityDb is not a number`);
        if (s.manufacturerSensitivityDb < 60 || s.manufacturerSensitivityDb > 115) suspicious.push(`${s.id}: unusual manufacturerSensitivityDb: ${s.manufacturerSensitivityDb}`);
    }

    if (s.resonantFreq_hz !== undefined && s.resonantFreq_hz <= 0) suspicious.push(`${s.id}: resonantFreq_hz <= 0`);
    
    if (s.dimensions !== undefined && s.dimensions.width !== undefined && s.dimensions.width <= 0) suspicious.push(`${s.id}: dimensions.width <= 0`);
    if (s.dimensions !== undefined && s.dimensions.height !== undefined && s.dimensions.height <= 0) suspicious.push(`${s.id}: dimensions.height <= 0`);
    if (s.dimensions !== undefined && s.dimensions.depth !== undefined && s.dimensions.depth <= 0) suspicious.push(`${s.id}: dimensions.depth <= 0`);
    if (s.weight_kg !== undefined && s.weight_kg <= 0) suspicious.push(`${s.id}: weight_kg <= 0`);
}

console.log(`Found ${suspicious.length} suspicious records.`);
if (suspicious.length > 0) {
    console.log(suspicious.join('\n'));
}
