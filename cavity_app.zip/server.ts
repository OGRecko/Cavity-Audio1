import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import crypto from "crypto";
import nodemailer from "nodemailer";
import cookieParser from "cookie-parser";
import { readDb, writeDb, UserRecord } from "./server/db";
import { getAbsorption } from "./src/lib/absorption";
import { generateProjectReport } from "./server/reportGenerator";

// Broadband (500 Hz) absorption lookup for the FDTD solver's per-step
// boundary damping, derived from the shared per-octave-band table in
// src/lib/absorption.ts rather than a second hand-maintained map.
function getAbsorptionAt500Hz(materialId: string): number {
  return getAbsorption(materialId).hz500;
}
import {
  hashPassword,
  verifyPassword,
  generateCode,
  hashCode,
  createSessionToken,
  verifySessionToken,
  SESSION_COOKIE_NAME,
  SESSION_COOKIE_MAX_AGE,
} from "./server/authUtils";

const app = express();
const PORT = 3000;

app.use(cookieParser());

// ---------------------------------------------------------------------------
// Email helpers (SMTP via nodemailer — works with any provider, no Firebase)
// ---------------------------------------------------------------------------

const mailTransporter = process.env.SMTP_HOST
  ? nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: Number(process.env.SMTP_PORT) === 465,
      tls: {
        ciphers: 'SSLv3'
      },
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
    })
  : null;

async function sendVerificationEmail(email: string, firstName: string, code: string): Promise<boolean> {
  const subject = "Your Cavity verification code";
  const text = `Hi ${firstName},\n\nYour Cavity verification code is: ${code}\n\nThis code expires in 15 minutes. If you didn't request this, you can ignore this email.`;
  const html = `<p>Hi ${firstName},</p><p>Your Cavity verification code is:</p><p style="font-size:28px;font-weight:bold;letter-spacing:4px;">${code}</p><p>This code expires in 15 minutes. If you didn't request this, you can ignore this email.</p>`;

  try {
    if (!mailTransporter) {
      // No SMTP configured (e.g. local dev) — log instead of throwing so the flow is still testable.
      console.warn(`[dev] SMTP not configured. Verification code for ${email}: ${code}`);
      return false; // Indicates we should auto-verify
    }

    await mailTransporter.sendMail({
      from: process.env.SMTP_FROM || "Cavity <no-reply@cavity.app>",
      to: email,
      subject,
      text,
      html,
    });
    return true; // Sent successfully
  } catch (err) {
    console.warn(`[dev] SMTP error when sending verification code: ${err}`);
    return false; // Failed to send, should auto-verify to avoid getting stuck
  }
}

async function sendPasswordResetEmail(email: string, firstName: string, code: string): Promise<boolean> {
  const subject = "Reset your Cavity password";
  const text = `Hi ${firstName},\n\nYour Cavity password reset code is: ${code}\n\nThis code expires in 15 minutes. If you didn't request this, you can safely ignore this email — your password will not be changed.`;
  const html = `<p>Hi ${firstName},</p><p>Your Cavity password reset code is:</p><p style="font-size:28px;font-weight:bold;letter-spacing:4px;">${code}</p><p>This code expires in 15 minutes. If you didn't request this, you can safely ignore this email — your password will not be changed.</p>`;

  try {
    if (!mailTransporter) {
      console.warn(`[dev] SMTP not configured. Password reset code for ${email}: ${code}`);
      return false;
    }

    await mailTransporter.sendMail({
      from: process.env.SMTP_FROM || "Cavity <no-reply@cavity.app>",
      to: email,
      subject,
      text,
      html,
    });
    return true;
  } catch (err) {
    console.warn(`[dev] SMTP error when sending password reset code: ${err}`);
    return false;
  }
}

const USERNAME_RE = /^[a-zA-Z0-9_]{6,20}$/;
const CODE_TTL_MS = 15 * 60 * 1000; // 15 minutes
const RESEND_COOLDOWN_MS = 60 * 1000; // 1 minute
const TRIAL_MS = 15 * 24 * 60 * 60 * 1000; // 15 days

function sanitizeUser(user: UserRecord) {
  return {
    uid: user.uid,
    firstName: user.firstName,
    lastName: user.lastName,
    username: user.username,
    email: user.email,
    emailVerified: user.emailVerified,
  };
}

function setSessionCookie(res: any, uid: string, rememberMe: boolean = true) {
  const token = createSessionToken(uid);
  // This app serves its frontend and API from the same Express process/origin
  // (see the static-file + catch-all route at the bottom of this file), so
  // there's no cross-site request that legitimately needs this cookie sent —
  // "lax" (sent on top-level navigation, withheld on cross-site XHR/fetch)
  // is the correct, narrower default here. "none" was carried over from an
  // earlier split-origin assumption that no longer applies; it wasn't
  // exploitable (there's no CORS allowlist granting a foreign origin access
  // to read the response either way), but it was wider than this deployment
  // needs, and would become a real gap the moment anyone adds a permissive
  // CORS middleware later without revisiting this. `secure` still requires
  // HTTPS in production; only relaxed for local HTTP dev.
  const options: any = {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
  };
  if (rememberMe) {
    options.maxAge = SESSION_COOKIE_MAX_AGE;
  }
  res.cookie(SESSION_COOKIE_NAME, token, options);
}

// Requires a valid session cookie. Attaches the full user record to req.user.
async function authMiddleware(req: any, res: any, next: any) {
  const uid = verifySessionToken(req.cookies?.[SESSION_COOKIE_NAME]);
  if (!uid) {
    return res.status(401).json({ error: "Not logged in." });
  }
  const db = readDb();
  const user = db.users[uid];
  if (!user) {
    res.clearCookie(SESSION_COOKIE_NAME);
    return res.status(401).json({ error: "Not logged in." });
  }
  req.user = user;
  next();
}

// ---------------------------------------------------------------------------
// Heavy-compute guard for the FDTD solver endpoints
// ---------------------------------------------------------------------------
// Node runs JavaScript on a single thread — while one of these endpoints'
// large synchronous nested loops is executing, it blocks the ENTIRE event
// loop, stalling every other request (including other users' logins,
// project saves, everything) until it finishes. Without any protection, a
// single user spamming the "compute" button, or several users triggering
// it at once, can make the whole server unresponsive.
//
// This is a simple, in-memory, single-process guard: per-user cooldown
// (reject a new request if their last one hasn't been outside the cooldown
// window) plus a global concurrency cap (reject if too many heavy
// computations are already in flight across all users). It is NOT a
// substitute for a real job queue or moving this work to worker threads —
// see the note below — but it prevents the most obvious abuse/pile-up
// cases cheaply, with no new dependency.
//
// LIMITATION: this state lives in a single Node process's memory. It does
// NOT coordinate across multiple server instances (e.g. behind a load
// balancer) — each instance would enforce its own limits independently.
// If this app ever runs more than one server process, replace this with a
// shared store (Redis, etc.) or move the actual computation to a proper
// background job queue.
const SOLVER_COOLDOWN_MS = 3000; // minimum time between one user's solver requests
const MAX_CONCURRENT_SOLVER_JOBS = 2; // global cap across all users, on this process
const lastSolverRequestAt = new Map<string, number>();
let activeSolverJobs = 0;

function solverGuard(req: any, res: any, next: any) {
  const uid = req.user?.uid;
  const now = Date.now();

  if (activeSolverJobs >= MAX_CONCURRENT_SOLVER_JOBS) {
    return res.status(429).json({ error: "The server is already computing another simulation. Please try again in a moment." });
  }
  const last = uid ? lastSolverRequestAt.get(uid) : undefined;
  if (last && now - last < SOLVER_COOLDOWN_MS) {
    return res.status(429).json({ error: `Please wait ${Math.ceil((SOLVER_COOLDOWN_MS - (now - last)) / 1000)}s before running another simulation.` });
  }
  if (uid) lastSolverRequestAt.set(uid, now);

  activeSolverJobs++;
  // Decrement once the response is actually sent, whether it succeeded,
  // errored, or the client disconnected — 'finish' and 'close' cover all
  // of those cases so activeSolverJobs can never get stuck incremented.
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
    activeSolverJobs = Math.max(0, activeSolverJobs - 1);
  };
  res.on('finish', release);
  res.on('close', release);

  next();
}

import { Polar } from '@polar-sh/sdk';

// Polar integration
const polar = new Polar({
  accessToken: process.env.POLAR_ACCESS_TOKEN,
});

// Maps a Polar product_id from a webhook event to this app's internal plan
// tier. Previously this only checked against the Premium product IDs and
// treated everything else as "standard" by default -- an assumption, not a
// check, which meant a misconfigured or unrecognized product_id (including
// a genuine third tier added later) would silently get bucketed as
// "standard" with no visibility into that happening. Now Standard product
// IDs are checked explicitly too, and a product_id matching neither tier is
// logged rather than silently guessed at, so a configuration problem shows
// up in the logs instead of quietly mis-granting access.
function resolvePlanFromProductId(pId: string | undefined): 'premium' | 'standard' {
  if (pId === process.env.VITE_POLAR_PREMIUM_MONTHLY_PRODUCT_ID || pId === process.env.VITE_POLAR_PREMIUM_ANNUAL_PRODUCT_ID) {
    return 'premium';
  }
  if (pId === process.env.VITE_POLAR_STANDARD_MONTHLY_PRODUCT_ID || pId === process.env.VITE_POLAR_STANDARD_ANNUAL_PRODUCT_ID) {
    return 'standard';
  }
  console.warn(`[Polar webhook] Unrecognized product_id "${pId}" — defaulting to 'standard'. Check VITE_POLAR_*_PRODUCT_ID env vars match your actual Polar product IDs.`);
  return 'standard';
}

app.post("/api/webhooks/polar", express.raw({ type: '*/*' }), async (req: any, res: any) => {
  const secret = process.env.POLAR_WEBHOOK_SECRET;
  if (!secret) {
    return res.status(500).json({ error: "Webhook secret not configured" });
  }

  // Verify the Standard Webhooks signature Polar sends (webhook-id,
  // webhook-timestamp, webhook-signature headers; HMAC-SHA256 over
  // "{id}.{timestamp}.{raw body}") before trusting ANYTHING in the payload.
  // This previously only checked that a secret was configured and then
  // processed req.body directly with no verification at all -- meaning
  // anyone who knew (or guessed) a user's uid could POST a fake
  // "subscription.created" event and grant themselves premium for free.
  // Verification must run against the exact raw request bytes, not
  // re-serialized JSON (a re-stringified object is not guaranteed to be
  // byte-identical to what Polar signed), which is why this route now uses
  // express.raw() instead of express.json() -- express.json() discards the
  // raw body after parsing.
  //
  // IMPORTANT: the `@polar-sh/sdk/webhooks` import path and `validateEvent`
  // name below are based on published third-party integration guides
  // (Polar follows the Standard Webhooks spec), NOT independently confirmed
  // against the installed package version in this environment -- this repo
  // has no network access to install/inspect node_modules here. CONFIRM
  // this import actually resolves and validateEvent behaves as described
  // (reject on bad/missing signature, return the parsed event on success)
  // against your installed @polar-sh/sdk version before relying on this in
  // production; if the SDK's actual export differs, replace this block with
  // a hand-rolled Standard Webhooks HMAC-SHA256 check over
  // `${webhook-id}.${webhook-timestamp}.${rawBody}` using crypto.timingSafeEqual
  // (see server/authUtils.ts for the timing-safe comparison pattern already
  // used elsewhere in this codebase). Either way, never remove this
  // verification step -- the endpoint fails closed (403) if it throws,
  // which is the safe default while that's being confirmed.
  let event: any;
  try {
    const { validateEvent } = await import('@polar-sh/sdk/webhooks');
    event = validateEvent(req.body, req.headers, secret);
  } catch (err: any) {
    console.error("Polar webhook signature verification failed:", err?.message || err);
    return res.status(403).json({ error: "Invalid webhook signature" });
  }

  const payload = event;
  const eventName = payload.type;
  const data = payload.data;
  
  // Custom metadata we pass during checkout
  const userId = data.custom_field_data?.uid;

  try {
    const db = readDb();
    const user = userId ? db.users[userId] : null;

    if (user && eventName === "subscription.created") {
      user.subscriptionStatus = "active";
      user.polarCustomerId = data.customer_id;
      user.plan = resolvePlanFromProductId(data.product_id);
      writeDb(db);
    } else if (user && eventName === "subscription.updated") {
       user.subscriptionStatus = data.status === "active" ? "active" : "canceled";
       user.plan = resolvePlanFromProductId(data.product_id);
       writeDb(db);
    } else if (user && (eventName === "subscription.canceled" || eventName === "subscription.revoked")) {
      user.subscriptionStatus = "canceled";
      writeDb(db);
    }
  } catch (err) {
    console.error("Error processing Polar webhook:", err);
  }

  res.json({ received: true });
});

// JSON middleware for other routes
app.use(express.json());

// ---------------------------------------------------------------------------
// Sign up: create the account, reserve the username, email a verification code
// ---------------------------------------------------------------------------
app.post("/api/auth/signup", async (req: any, res: any) => {
  try {
    let { firstName, lastName, username, email, password } = req.body || {};

    firstName = String(firstName || "").trim();
    lastName = String(lastName || "").trim();
    username = String(username || "").trim();
    email = String(email || "").trim().toLowerCase();

    if (!firstName || !lastName) {
      return res.status(400).json({ error: "First and last name are required." });
    }
    if (!USERNAME_RE.test(username)) {
      return res.status(400).json({ error: "Username must be 6-20 characters: letters, numbers, or underscores." });
    }
    if (!email || !email.includes("@")) {
      return res.status(400).json({ error: "A valid email address is required." });
    }
    if (!password || String(password).length < 6) {
      return res.status(400).json({ error: "Password must be at least 6 characters." });
    }

    const usernameLower = username.toLowerCase();
    const db = readDb();

    if (db.usernames[usernameLower]) {
      return res.status(409).json({ error: "That username is already taken." });
    }
    if (db.emails[email]) {
      return res.status(409).json({ error: "An account with that email already exists." });
    }

    const uid = crypto.randomUUID();
    const now = Date.now();
    const user: UserRecord = {
      uid,
      firstName,
      lastName,
      username,
      usernameLower,
      email,
      emailLower: email,
      passwordHash: hashPassword(password),
      emailVerified: false,
      createdAt: now,
      subscriptionStatus: "none",
      trialStartsAt: 0,
      trialEndsAt: 0,
    };

    const code = generateCode();
    if (!db.pendingSignups) db.pendingSignups = {};
    db.pendingSignups[email] = {
      user,
      codeRecord: {
        codeHash: hashCode(code),
        attempts: 0,
        expiresAt: now + CODE_TTL_MS,
        lastSentAt: now,
      }
    };
    writeDb(db);

    const emailSent = await sendVerificationEmail(email, firstName, code);

    if (!emailSent) {
      // Re-read the DB here rather than reusing the `db` object captured
      // before the `await` above: any request that ran while this one was
      // waiting on the SMTP call could have written its own changes in the
      // meantime, and writeDb() overwrites the whole file -- reusing the
      // stale in-memory snapshot would silently clobber that concurrent
      // write. This file-based DB has no interleaving race WITHIN a
      // synchronous read-modify-write span (see db.ts's comment), but an
      // `await` in the middle of a handler breaks that guarantee, so any
      // write after one must start from a fresh read.
      console.log(`[dev] Auto-verifying ${email} because SMTP is not configured`);
      const freshDb = readDb();
      const pending = freshDb.pendingSignups?.[email];
      // Only proceed if our pending signup is still there (not raced away
      // by a concurrent request, e.g. a duplicate signup or cleanup).
      if (pending) {
        user.emailVerified = true;
        freshDb.users[user.uid] = user;
        freshDb.usernames[user.usernameLower] = user.uid;
        freshDb.emails[user.emailLower] = user.uid;
        delete freshDb.pendingSignups![email];
        writeDb(freshDb);
      }
      
      // Use the same cookie helper (and therefore the same sameSite/secure
      // flags) as every other session-issuing path in this file, rather than
      // a bespoke res.cookie() call here that could silently drift out of
      // sync with setSessionCookie() and break cross-origin auth in this one
      // dev-auto-verify branch.
      setSessionCookie(res, user.uid);
      return res.json({ autoVerified: true, user: sanitizeUser(user) });
    }

    res.json({ pendingEmail: email });
  } catch (err: any) {
    console.error("Signup error:", err);
    res.status(500).json({ error: err.message || "Signup failed." });
  }
});

// ---------------------------------------------------------------------------
// Log in with either email or username, plus password
// ---------------------------------------------------------------------------
app.post("/api/auth/login", async (req: any, res: any) => {
  try {
    let { identifier, password, rememberMe } = req.body || {};
    identifier = String(identifier || "").trim();
    password = String(password || "");

    if (!identifier || !password) {
      return res.status(400).json({ error: "Enter your email/username and password." });
    }

    const db = readDb();
    const uid = identifier.includes("@")
      ? db.emails[identifier.toLowerCase()]
      : db.usernames[identifier.toLowerCase()];

    const user = uid ? db.users[uid] : null;
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return res.status(401).json({ error: "Incorrect email/username or password." });
    }

    setSessionCookie(res, user.uid, rememberMe !== false);
    res.json({ user: sanitizeUser(user) });
  } catch (err: any) {
    console.error("Login error:", err);
    res.status(500).json({ error: err.message || "Login failed." });
  }
});

// ---------------------------------------------------------------------------
// Start Trial
// ---------------------------------------------------------------------------
app.post("/api/auth/start-trial", authMiddleware, (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];
  if (user.subscriptionStatus !== "none" && user.subscriptionStatus !== "trialing") {
    return res.status(400).json({ error: "Trial already used or active subscription." });
  }
  const now = Date.now();
  user.subscriptionStatus = "trialing";
  user.trialStartsAt = now;
  user.trialEndsAt = now + TRIAL_MS;
  writeDb(db);
  res.json({ success: true, user: sanitizeUser(user) });
});

// ---------------------------------------------------------------------------
// Auto-save Project
// ---------------------------------------------------------------------------
app.get("/api/project", authMiddleware, (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];
  res.json({ projectData: user.projectData || null });
});

app.post("/api/project", authMiddleware, express.json({limit: '10mb'}), (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];
  user.projectData = req.body.projectData;
  writeDb(db);
  res.json({ success: true });
});

// ---------------------------------------------------------------------------
// MULTI-PROJECT WORKSPACE
// ---------------------------------------------------------------------------
// Additive on top of the legacy single-project endpoints above, which are
// left untouched. `user.projects` is undefined for any user who hasn't
// created a project through this new flow yet — every handler below treats
// that as "no projects" rather than throwing.

app.get("/api/projects", authMiddleware, (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];
  const projects = Object.values(user.projects || {})
    .filter((p: any) => !p.archived)
    .sort((a: any, b: any) => b.updatedAt - a.updatedAt)
    .map((p: any) => ({ id: p.id, name: p.name, createdAt: p.createdAt, updatedAt: p.updatedAt }));
  res.json({ projects, activeProjectId: user.activeProjectId || null });
});

app.post("/api/projects", authMiddleware, express.json({ limit: '10mb' }), (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];
  const name = String(req.body.name || 'Untitled Project').slice(0, 200);
  const id = crypto.randomUUID();
  const now = Date.now();

  if (!user.projects) user.projects = {};
  user.projects[id] = {
    id,
    name,
    createdAt: now,
    updatedAt: now,
    data: req.body.data ?? null,
  };
  user.activeProjectId = id;
  writeDb(db);
  res.json({ success: true, project: user.projects[id] });
});

app.get("/api/projects/:id", authMiddleware, (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];
  const project = user.projects?.[req.params.id];
  if (!project || project.archived) return res.status(404).json({ error: "Project not found." });
  res.json({ project });
});

app.put("/api/projects/:id", authMiddleware, express.json({ limit: '10mb' }), (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];
  const project = user.projects?.[req.params.id];
  if (!project || project.archived) return res.status(404).json({ error: "Project not found." });

  if (req.body.name != null) project.name = String(req.body.name).slice(0, 200);
  if (req.body.data !== undefined) project.data = req.body.data;
  project.updatedAt = Date.now();
  writeDb(db);
  res.json({ success: true, project });
});

app.post("/api/projects/:id/archive", authMiddleware, (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];
  const project = user.projects?.[req.params.id];
  if (!project) return res.status(404).json({ error: "Project not found." });

  // Soft delete: archive rather than remove, so a mistaken delete is
  // recoverable and we never silently destroy a client's project data.
  project.archived = true;
  project.updatedAt = Date.now();
  if (user.activeProjectId === req.params.id) {
    const remaining = Object.values(user.projects || {}).filter((p: any) => !p.archived && p.id !== req.params.id);
    user.activeProjectId = remaining.length > 0 ? (remaining[0] as any).id : undefined;
  }
  writeDb(db);
  res.json({ success: true });
});

app.post("/api/projects/:id/activate", authMiddleware, (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];
  const project = user.projects?.[req.params.id];
  if (!project || project.archived) return res.status(404).json({ error: "Project not found." });
  user.activeProjectId = req.params.id;
  writeDb(db);
  res.json({ success: true });
});

// Hard delete: permanently removes the project record (unlike /archive,
// which just hides it). Meant for archived projects the user wants gone
// for good, but works on any project id the user owns.
app.delete("/api/projects/:id", authMiddleware, (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];
  const project = user.projects?.[req.params.id];
  if (!project) return res.status(404).json({ error: "Project not found." });

  delete user.projects![req.params.id];
  if (user.activeProjectId === req.params.id) {
    const remaining = Object.values(user.projects || {}).filter((p: any) => !p.archived);
    user.activeProjectId = remaining.length > 0 ? (remaining[0] as any).id : undefined;
  }
  writeDb(db);
  res.json({ success: true });
});

// One-time, idempotent migration: copy the legacy single `projectData` blob
// into the new `projects` map as a real project, so existing users' current
// work is preserved rather than orphaned when they start using multiple
// projects. The client should call this once (e.g. on first visit to a
// "Projects" screen) rather than the server doing it automatically on every
// request. Safe to call more than once — it no-ops if the user already has
// any projects or has no legacy data to migrate.
app.post("/api/projects/migrate-legacy", authMiddleware, (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];

  if (user.projects && Object.keys(user.projects).length > 0) {
    return res.json({ migrated: false, reason: "User already has projects." });
  }
  if (!user.projectData) {
    return res.json({ migrated: false, reason: "No legacy project data to migrate." });
  }

  const id = crypto.randomUUID();
  const now = Date.now();
  user.projects = {
    [id]: {
      id,
      name: 'My Project',
      createdAt: now,
      updatedAt: now,
      data: user.projectData,
    },
  };
  user.activeProjectId = id;
  writeDb(db);
  res.json({ migrated: true, project: user.projects[id] });
});

// ---------------------------------------------------------------------------
// Google Sign In
// ---------------------------------------------------------------------------
app.post("/api/auth/google", async (req: any, res: any) => {
  try {
    const { idToken, accessToken } = req.body;
    if (!idToken && !accessToken) return res.status(400).json({ error: "Missing token" });

    const clientId = process.env.VITE_GOOGLE_CLIENT_ID;
    
    let tokenInfo: any = {};
    if (accessToken) {
      const verifyRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      tokenInfo = await verifyRes.json().catch(() => ({ error: "invalid_response" }));
    } else {
      const verifyRes = await fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + idToken);
      tokenInfo = await verifyRes.json().catch(() => ({ error: "invalid_response" }));
      // The tokeninfo endpoint verifies the token's signature and expiry for
      // us, but NOT which app it was issued for — that's on us to check, or
      // any valid Google ID token from any app would let someone log in as
      // that token's email. accessToken userinfo doesn't have this problem
      // since possessing a working access token already proves it was
      // issued to whichever app requested it.
      if (clientId && tokenInfo.aud !== clientId) {
        return res.status(401).json({ error: "Invalid Google token" });
      }
    }
    
    if (tokenInfo.error || !tokenInfo.email || tokenInfo.email_verified === "false" || tokenInfo.email_verified === false) {
      return res.status(401).json({ error: "Invalid Google token" });
    }
    
    const email = tokenInfo.email.toLowerCase();
    const googleUid = tokenInfo.sub; // Google's unique ID for the user
    
    const db = readDb();
    let uid = db.emails[email];
    let user;
    
    if (uid) {
      // Existing user
      user = db.users[uid];
      user.emailVerified = true;
    } else {
      // New user
      uid = crypto.randomUUID();
      const now = Date.now();
      
      const firstName = tokenInfo.given_name || "Google";
      const lastName = tokenInfo.family_name || "User";
      let baseUsername = (firstName + lastName).replace(/[^a-zA-Z0-9_]/g, "").substring(0, 15) || "user";
      if (baseUsername.length < 6) baseUsername += "123456";
      let username = baseUsername;
      let counter = 1;
      while (db.usernames[username.toLowerCase()]) {
        username = baseUsername + counter;
        counter++;
      }
      
      user = {
        uid,
        firstName,
        lastName,
        username,
        usernameLower: username.toLowerCase(),
        email,
        emailLower: email,
        passwordHash: "", // No password for Google users
        emailVerified: true,
        createdAt: now,
        subscriptionStatus: "none",
        trialStartsAt: 0,
        trialEndsAt: 0,
      };
      
      db.users[uid] = user;
      db.usernames[user.usernameLower] = uid;
      db.emails[email] = uid;
    }
    
    writeDb(db);
    setSessionCookie(res, uid);
    res.json({ user: sanitizeUser(user) });
  } catch (err: any) {
    console.error("Google Login error:", err);
    res.status(500).json({ error: err.message || "Login failed." });
  }
});

app.post("/api/auth/logout", (req: any, res: any) => {
  res.clearCookie(SESSION_COOKIE_NAME);
  res.json({ success: true });
});

// ---------------------------------------------------------------------------
// Verify the emailed code and activate the account (requires being logged in)
// ---------------------------------------------------------------------------
app.post("/api/auth/verify-code", async (req: any, res: any) => {
  try {
    const { code, email } = req.body || {};
    if (!code) return res.status(400).json({ error: "Enter the code from your email." });

    const uid = verifySessionToken(req.cookies?.[SESSION_COOKIE_NAME]);
    const db = readDb();
    
    // Check pending signups if not logged in or explicitly passed email
    if (email && db.pendingSignups && db.pendingSignups[email.toLowerCase()]) {
      const pending = db.pendingSignups[email.toLowerCase()];
      const record = pending.codeRecord;
      if (record.expiresAt < Date.now()) return res.status(400).json({ error: "That code has expired. Request a new one." });
      if (record.attempts >= 5) return res.status(429).json({ error: "Too many incorrect attempts. Request a new code." });
      if (hashCode(String(code).trim()) !== record.codeHash) {
        record.attempts += 1;
        writeDb(db);
        return res.status(400).json({ error: "Incorrect code. Please try again." });
      }
      
      // Success! Move to users
      const user = pending.user;
      user.emailVerified = true;
      db.users[user.uid] = user;
      db.usernames[user.usernameLower] = user.uid;
      db.emails[user.emailLower] = user.uid;
      delete db.pendingSignups[email.toLowerCase()];
      writeDb(db);
      
      setSessionCookie(res, user.uid);
      return res.json({ user: sanitizeUser(user) });
    }

    // Otherwise check logged-in unverified user
    if (!uid) return res.status(401).json({ error: "No pending verification found." });
    
    const record = db.verificationCodes[uid];
    if (!record) return res.status(400).json({ error: "No pending verification for this account. Request a new code." });
    if (record.expiresAt < Date.now()) return res.status(400).json({ error: "That code has expired. Request a new one." });
    if (record.attempts >= 5) return res.status(429).json({ error: "Too many incorrect attempts. Request a new code." });
    if (hashCode(String(code).trim()) !== record.codeHash) {
      record.attempts += 1;
      writeDb(db);
      return res.status(400).json({ error: "Incorrect code. Please try again." });
    }

    db.users[uid].emailVerified = true;
    delete db.verificationCodes[uid];
    writeDb(db);
    return res.json({ user: sanitizeUser(db.users[uid]) });
  } catch (err: any) {
    console.error("Verify code error:", err);
    res.status(500).json({ error: err.message || "Verification failed." });
  }
});

// ---------------------------------------------------------------------------
// Resend a fresh verification code
// ---------------------------------------------------------------------------
app.post("/api/auth/resend-code", async (req: any, res: any) => {
  try {
    const { email } = req.body || {};
    const uid = verifySessionToken(req.cookies?.[SESSION_COOKIE_NAME]);
    const db = readDb();
    
    let user;
    let record;
    let pendingEmail = false;

    if (email && db.pendingSignups && db.pendingSignups[email.toLowerCase()]) {
      user = db.pendingSignups[email.toLowerCase()].user;
      record = db.pendingSignups[email.toLowerCase()].codeRecord;
      pendingEmail = true;
    } else if (uid) {
      user = db.users[uid];
      if (!user) return res.status(404).json({ error: "User not found." });
      if (user.emailVerified) return res.json({ success: true, alreadyVerified: true });
      record = db.verificationCodes[uid];
    } else {
      return res.status(404).json({ error: "No pending verification found." });
    }

    if (record && Date.now() - record.lastSentAt < RESEND_COOLDOWN_MS) {
      return res.status(429).json({ error: "Please wait 60 seconds before requesting another code." });
    }

    const code = generateCode();
    const newRecord = {
      codeHash: hashCode(code),
      attempts: 0,
      expiresAt: Date.now() + CODE_TTL_MS,
      lastSentAt: Date.now(),
    };

    if (pendingEmail && email && db.pendingSignups?.[email.toLowerCase()]) {
      db.pendingSignups[email.toLowerCase()].codeRecord = newRecord;
    } else if (uid) {
      db.verificationCodes[uid] = newRecord;
    }
    
    writeDb(db);

    const emailSent = await sendVerificationEmail(user.email, user.firstName, code);
    if (!emailSent) {
      return res.status(500).json({ error: "Failed to send verification email. Please check SMTP settings." });
    }

    res.json({ success: true });
  } catch (err: any) {
    console.error("Resend code error:", err);
    res.status(500).json({ error: err.message || "Could not resend code." });
  }
});

// ---------------------------------------------------------------------------
// Password reset: request a code (works whether logged in or not — the
// email address is the identifier, matching how signup/verify already
// work). Always responds success even for unknown emails, so this can't be
// used to enumerate which addresses have accounts.
// ---------------------------------------------------------------------------
app.post("/api/auth/forgot-password", express.json(), async (req: any, res: any) => {
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    if (!email) return res.status(400).json({ error: "Enter your email address." });

    const db = readDb();
    const uid = db.emails[email];
    const user = uid ? db.users[uid] : null;

    // Don't reveal whether the account exists — always return success, but
    // only actually send an email (and create a reset record) if it does.
    if (!user) {
      return res.json({ success: true });
    }

    if (!db.passwordResets) db.passwordResets = {};
    const existing = db.passwordResets[user.uid];
    if (existing && Date.now() - existing.lastSentAt < RESEND_COOLDOWN_MS) {
      return res.status(429).json({ error: "Please wait 60 seconds before requesting another code." });
    }

    const code = generateCode();
    db.passwordResets[user.uid] = {
      codeHash: hashCode(code),
      attempts: 0,
      expiresAt: Date.now() + CODE_TTL_MS,
      lastSentAt: Date.now(),
    };
    writeDb(db);

    const emailSent = await sendPasswordResetEmail(user.email, user.firstName, code);
    // Mirrors sendVerificationEmail's dev fallback: if SMTP isn't
    // configured, log the code instead of failing the request outright so
    // the flow is still testable locally.
    if (!emailSent && mailTransporter) {
      return res.status(500).json({ error: "Failed to send reset email. Please check SMTP settings." });
    }

    res.json({ success: true });
  } catch (err: any) {
    console.error("Forgot password error:", err);
    res.status(500).json({ error: err.message || "Could not start password reset." });
  }
});

// Verify the reset code and set a new password in one step.
app.post("/api/auth/reset-password", express.json(), async (req: any, res: any) => {
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const code = String(req.body?.code || "").trim();
    const newPassword = String(req.body?.newPassword || "");

    if (!email || !code) return res.status(400).json({ error: "Enter your email and the code from your email." });
    if (newPassword.length < 6) return res.status(400).json({ error: "Password must be at least 6 characters." });

    const db = readDb();
    const uid = db.emails[email];
    const user = uid ? db.users[uid] : null;
    const record = uid ? db.passwordResets?.[uid] : null;

    if (!user || !record) {
      return res.status(400).json({ error: "Invalid or expired reset code. Request a new one." });
    }
    if (record.expiresAt < Date.now()) {
      return res.status(400).json({ error: "That code has expired. Request a new one." });
    }
    if (record.attempts >= 5) {
      return res.status(429).json({ error: "Too many incorrect attempts. Request a new code." });
    }
    if (hashCode(code) !== record.codeHash) {
      record.attempts += 1;
      writeDb(db);
      return res.status(400).json({ error: "Incorrect code. Please try again." });
    }

    user.passwordHash = hashPassword(newPassword);
    delete db.passwordResets![uid!];
    writeDb(db);

    // Log the user in immediately, same as the other post-verification flows.
    setSessionCookie(res, user.uid);
    res.json({ success: true, user: sanitizeUser(user) });
  } catch (err: any) {
    console.error("Reset password error:", err);
    res.status(500).json({ error: err.message || "Could not reset password." });
  }
});

// Get the current session's user + subscription status
app.get("/api/me", authMiddleware, async (req: any, res: any) => {
  const user = req.user as UserRecord;
  res.json({
    user: sanitizeUser(user),
    subscriptionStatus: user.subscriptionStatus,
    trialStartsAt: user.trialStartsAt,
    trialEndsAt: user.trialEndsAt,
    plan: user.plan,
  });
});

// Redeem custom promo code (bypasses Lemon Squeezy for lifetime access)
app.post("/api/redeem", authMiddleware, async (req: any, res: any) => {
  try {
    const { code: rawCode } = req.body;
    const code = String(rawCode || "").trim();
    const db = readDb();
    const user = db.users[req.user.uid];

    if (code === 'Monthly10' || code === 'Yearly10') {
      return res.status(400).json({ error: "Please enter this code directly on the Lemon Squeezy checkout page." });
    }

    // Per-recipient single-use codes minted via /api/admin/promo-codes,
    // replacing the old hardcoded 'FFGFREE' shared string (which, being a
    // literal in source, had no real secrecy and granted lifetime access to
    // anyone who ever saw this file). A code here is looked up by its exact
    // value, checked for prior redemption/revocation, then marked redeemed
    // -- so a single leaked code only ever grants one account, and any
    // unredeemed code can be revoked individually without affecting others.
    const promo = db.promoCodes?.[code];
    if (!promo || promo.revoked) {
      return res.status(400).json({ error: "Invalid or expired promo code." });
    }
    if (promo.redeemed) {
      return res.status(400).json({ error: "This promo code has already been used." });
    }

    // Set lifetime access
    const futureDate = new Date();
    futureDate.setFullYear(futureDate.getFullYear() + 100);

    user.subscriptionStatus = "active";
    user.plan = "lifetime";
    user.trialEndsAt = futureDate.getTime();

    promo.redeemed = true;
    promo.redeemedBy = user.uid;
    promo.redeemedAt = Date.now();

    writeDb(db);

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// PROMO CODE ADMINISTRATION (mint/list/revoke single-use lifetime codes)
// ---------------------------------------------------------------------------
// Gated by a standalone ADMIN_SECRET env var (a bearer-style shared secret
// for whoever operates this deployment), not by any user account/role --
// there's no admin-user concept elsewhere in this codebase, and adding one
// just for this would be a bigger change than the promo-code problem calls
// for. If ADMIN_SECRET isn't set, these routes refuse everything (fail
// closed) rather than falling back to "no auth required".
function adminGuard(req: any, res: any, next: any) {
  const configured = process.env.ADMIN_SECRET;
  if (!configured) {
    return res.status(500).json({ error: "Admin endpoints are not configured (ADMIN_SECRET is unset)." });
  }
  const provided = req.header("x-admin-secret");
  if (!provided || provided !== configured) {
    return res.status(401).json({ error: "Unauthorized." });
  }
  next();
}

// Mint one or more new single-use lifetime promo codes.
// Body: { count?: number (default 1, max 200), note?: string }
app.post("/api/admin/promo-codes", express.json(), adminGuard, (req: any, res: any) => {
  const count = Math.min(Math.max(Number(req.body?.count) || 1, 1), 200);
  const note = req.body?.note ? String(req.body.note).slice(0, 200) : undefined;

  const db = readDb();
  if (!db.promoCodes) db.promoCodes = {};

  const minted: string[] = [];
  for (let i = 0; i < count; i++) {
    // Readable-but-unguessable: an 8-char base32-ish code from random bytes,
    // checked against existing codes (and this batch) to rule out collision.
    let code: string;
    do {
      code = crypto.randomBytes(6).toString("base64url").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10);
    } while (db.promoCodes[code]);

    db.promoCodes[code] = {
      code,
      grant: "lifetime",
      createdAt: Date.now(),
      createdBy: "admin",
      note,
      redeemed: false,
    };
    minted.push(code);
  }

  writeDb(db);
  res.json({ success: true, codes: minted });
});

// List all promo codes and their redemption status (no pagination -- fine
// for the realistic volume of a self-hosted admin tool; revisit if this
// ever needs to scale past a few thousand codes).
app.get("/api/admin/promo-codes", adminGuard, (_req: any, res: any) => {
  const db = readDb();
  const codes = Object.values(db.promoCodes || {}).sort((a, b) => b.createdAt - a.createdAt);
  res.json({ codes });
});

// Revoke an unredeemed code so it can no longer be used. No-op (still
// succeeds) if the code is already redeemed or revoked, or doesn't exist --
// the end state the caller wants ("this code doesn't work") is already true.
app.post("/api/admin/promo-codes/:code/revoke", adminGuard, (req: any, res: any) => {
  const db = readDb();
  const promo = db.promoCodes?.[req.params.code];
  if (promo && !promo.redeemed) {
    promo.revoked = true;
    writeDb(db);
  }
  res.json({ success: true });
});

// Create checkout session
app.post("/api/checkout", authMiddleware, async (req: any, res: any) => {
  const db = readDb();
  const user = db.users[req.user.uid];
  const accessToken = process.env.POLAR_ACCESS_TOKEN;

  if (!accessToken) {
    return res.status(500).json({ error: "Polar Access Token is not configured." });
  }

  try {
    const { priceId } = req.body;
    const email = user.email;

    const checkout = await (polar.checkouts as any).create({
      productId: priceId,
      customerEmail: email,
      customerName: `${user.firstName} ${user.lastName}`.trim(),
      customFieldData: { uid: user.uid },
    });

    res.json({ url: checkout.url });
  } catch (err: any) {
    console.error("Polar Checkout Error:", err);
    res.status(500).json({ error: err.message });
  }
});

// Create customer portal session
app.post("/api/portal", authMiddleware, async (req: any, res: any) => {
  const accessToken = process.env.POLAR_ACCESS_TOKEN;
  if (!accessToken) return res.status(500).json({ error: "Polar not configured" });

  try {
    const db = readDb();
    const user = db.users[req.user.uid];
    
    if (!user.polarCustomerId) {
        return res.status(400).json({ error: "No active billing profile found." });
    }

    const session = await polar.customerSessions.create({
      customerId: user.polarCustomerId,
    });

    res.json({ url: session.customerPortalUrl });
  } catch (err: any) {
    console.error("Polar Portal Error:", err);
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// REPORT EXPORT (PDF)
// ---------------------------------------------------------------------------
// Generates a client-ready PDF report from room/speaker/receiver data the
// client sends directly in the request, mirroring the pattern used by
// /api/solver/wave rather than reading from the (unstructured) persisted
// user.projectData blob. No plan-gating here yet — this is intentionally
// left open pending the pricing/tier decision discussed separately; add a
// isPro-style check here (see /api/solver/wave for the pattern) once the
// Professional tier is actually introduced.
app.post("/api/report/export", express.json({ limit: '10mb' }), authMiddleware, async (req: any, res: any) => {
  try {
    const { projectName, roomName, room, speakers, receivers, solverResult, assumedSnrDb } = req.body;

    if (!room || !Array.isArray(room.poly) || !room.poly.length) {
      return res.status(400).json({ error: "Room geometry (poly, L, W, H, materials) is required to generate a report." });
    }

    const doc = generateProjectReport({
      projectName: String(projectName || 'Untitled Project'),
      roomName: String(roomName || 'Untitled Room'),
      room: {
        poly: room.poly,
        L: Number(room.L) || 10,
        W: Number(room.W) || 8,
        H: Number(room.H) || 3,
        wallMaterial: room.wallMaterial || 'drywall',
        wallSegMats: Array.isArray(room.wallSegMats) ? room.wallSegMats : [],
        floorMaterial: room.floorMaterial || 'wood_floor',
        ceilMaterial: room.ceilMaterial || 'drywall_ceil',
      },
      speakers: Array.isArray(speakers) ? speakers : [],
      receivers: Array.isArray(receivers) ? receivers : [],
      solverResult: solverResult || null,
      assumedSnrDb: assumedSnrDb != null ? Number(assumedSnrDb) : undefined,
      generatedForEmail: req.user.email,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${(projectName || 'cavity-report').replace(/[^a-z0-9\-_]/gi, '_')}.pdf"`);
    doc.pipe(res);
  } catch (err: any) {
    console.error("Report Export Error:", err);
    res.status(500).json({ error: err.message || "Failed to generate report." });
  }
});

// ---------------------------------------------------------------------------
// PRO-GRADE WAVE SOLVER (FDTD) API
// ---------------------------------------------------------------------------
app.post("/api/solver/wave", express.json(), authMiddleware, solverGuard, async (req: any, res: any) => {
  const { elements, steps, L, W, H, wallMaterial, floorMaterial, ceilMaterial, source, receiver } = req.body;

  // Server-side tier enforcement: free accounts are capped at ~250k elements
  // regardless of what the client asked for; only premium/lifetime can reach
  // the full 30M budget the paywall advertises.
  const isPro = req.user.plan === 'premium' || req.user.plan === 'lifetime';
  const hardCap = isPro ? 30000000 : 250000;
  const requested = Number(elements) || hardCap;
  const targetElements = Math.min(requested, hardCap);
  const numSteps = Math.min(Number(steps) || 20, 40);

  // Real room dimensions (meters), defaulting to the app's default room if
  // the client didn't send any (e.g. a stale/older client).
  const roomL = Number(L) > 0 ? Number(L) : 10;
  const roomW = Number(W) > 0 ? Number(W) : 8;
  const roomH = Number(H) > 0 ? Number(H) : 3;

  // Build a grid whose aspect ratio matches the real room instead of a
  // generic cube: pick a uniform cell size `dx` such that
  // nx*ny*nz <= targetElements, with nx:ny:nz proportional to L:H:W.
  const rawCellVolume = (roomL * roomH * roomW) / targetElements;
  const dx = Math.max(Math.cbrt(rawCellVolume), 0.02); // floor at 2cm cells
  const nx = Math.max(4, Math.round(roomL / dx));
  const ny = Math.max(4, Math.round(roomH / dx));
  const nz = Math.max(4, Math.round(roomW / dx));
  const N = nx * ny * nz;
  const nxy = nx * ny;

  // Per-surface absorption -> per-axis boundary damping. Higher absorption
  // = more energy lost when the wave reflects off that surface, instead of
  // one flat damping constant applied everywhere.
  //
  // Single-value-per-material here is a simplification: real absorption is
  // frequency-dependent (see src/lib/absorption.ts for the full per-octave-
  // band table, which is the shared source of truth this map is derived
  // from). Time-domain FDTD boundary damping needs one broadband coefficient
  // per step, so this uses each material's 500 Hz value — the standard
  // reference frequency for a material's general absorptive character —
  // rather than maintaining a second, independently-tuned set of numbers.
  // If you're changing absorption values, change them in absorption.ts and
  // regenerate this block; don't hand-edit these numbers separately.
  const wallAbs = getAbsorptionAt500Hz(wallMaterial);
  const floorAbs = getAbsorptionAt500Hz(floorMaterial);
  const ceilAbs = getAbsorptionAt500Hz(ceilMaterial);
  // Reflection coefficient per boundary: sqrt(1 - absorption) is the usual
  // pressure-reflection approximation from the energy absorption coefficient.
  const wallRefl = Math.sqrt(Math.max(1 - wallAbs, 0));
  const floorRefl = Math.sqrt(Math.max(1 - floorAbs, 0));
  const ceilRefl = Math.sqrt(Math.max(1 - ceilAbs, 0));

  // Convert the normalized (0..1) source/listener coordinates the 3D view
  // uses into real grid indices, instead of always firing the impulse from
  // dead-center of the volume.
  const clamp01 = (v: number) => Math.min(0.98, Math.max(0.02, v));
  const srcX = clamp01(source?.x ?? 0.5), srcZ = clamp01(source?.y ?? 0.5);
  const srcIx = Math.round(srcX * (nx - 1));
  const srcIy = Math.round((source?.z != null ? clamp01(source.z / roomH) : 0.7) * (ny - 1));
  const srcIz = Math.round(srcZ * (nz - 1));
  const srcIdx = srcIy * nxy + srcIz * nx + srcIx;

  const recX = clamp01(receiver?.x ?? 0.25), recZ = clamp01(receiver?.y ?? 0.5);
  const recIx = Math.round(recX * (nx - 1));
  const recIy = Math.round((receiver?.z != null ? clamp01(receiver.z / roomH) : 0.5) * (ny - 1));
  const recIz = Math.round(recZ * (nz - 1));
  const recIdx = recIy * nxy + recIz * nx + recIx;

  console.log(`[WAVE SOLVER] Room ${roomL}x${roomW}x${roomH}m -> FDTD grid ${nx}x${ny}x${nz} (${N.toLocaleString()} elements, dx=${dx.toFixed(3)}m). Steps: ${numSteps}. Tier: ${isPro ? 'pro' : 'free'}.`);

  try {
    const startTime = Date.now();

    const p_prev = new Float32Array(N);
    const p = new Float32Array(N);
    const p_next = new Float32Array(N);

    // Initial condition: impulse at the room's actual source position.
    p[Math.max(0, Math.min(N - 1, srcIdx))] = 1.0;

    const Courant = 0.1; // Stability coefficient for this scheme (Courant^2 = (c*dt/dx)^2, well inside the 3D CFL limit of 1/3)
    // dt must be derived FROM Courant, not independently set to dx/c: the
    // update equation below implements p_next = 2p - p_prev + Courant*laplacian,
    // which is only the correct discretization of the wave equation
    // (d^2p/dt^2 = c^2 * laplacian(p)) if Courant == (c*dt/dx)^2. Reporting
    // dt = dx/c (implying Courant=1.0, three times past the actual stability
    // limit) while the loop below actually runs at Courant=0.1 previously
    // made every downstream "seconds" value (RT60-from-decay, trace
    // duration) wrong by a factor of 1/sqrt(0.1) =~ 3.16x -- fixed by
    // deriving dt from the Courant number the physics loop actually uses.
    const dt = (dx * Math.sqrt(Courant)) / 343;
    const receiverTrace: number[] = [];

    for (let t = 0; t < numSteps; t++) {
      for (let iy = 1; iy < ny - 1; iy++) {
        for (let iz = 1; iz < nz - 1; iz++) {
          const rowBase = iy * nxy + iz * nx;
          for (let ix = 1; ix < nx - 1; ix++) {
            const i = rowBase + ix;
            p_next[i] = (2 * p[i]) - p_prev[i] + Courant * (
              p[i - 1] + p[i + 1] +
              p[i - nx] + p[i + nx] +
              p[i - nxy] + p[i + nxy] -
              (6 * p[i])
            );
          }
        }
      }

      // Boundary reflection: attenuate the outermost shell by each real
      // surface's reflection coefficient (floor = y0, ceiling = yTop,
      // walls = the four x/z faces) instead of one global damping constant.
      for (let iz = 0; iz < nz; iz++) {
        for (let ix = 0; ix < nx; ix++) {
          p_next[0 * nxy + iz * nx + ix] *= floorRefl;
          p_next[(ny - 1) * nxy + iz * nx + ix] *= ceilRefl;
        }
      }
      for (let iy = 0; iy < ny; iy++) {
        for (let ix = 0; ix < nx; ix++) {
          p_next[iy * nxy + 0 * nx + ix] *= wallRefl;
          p_next[iy * nxy + (nz - 1) * nx + ix] *= wallRefl;
        }
        for (let iz = 0; iz < nz; iz++) {
          p_next[iy * nxy + iz * nx + 0] *= wallRefl;
          p_next[iy * nxy + iz * nx + (nx - 1)] *= wallRefl;
        }
      }

      receiverTrace.push(Math.abs(p_next[Math.max(0, Math.min(N - 1, recIdx))]));

      p_prev.set(p);
      p.set(p_next);
    }

    // Estimate RT60 from the actual simulated decay at the receiver (time for
    // the envelope to fall 60dB, extrapolated from however much decay the
    // step budget captured) as a sanity cross-check against the Sabine
    // estimate used elsewhere in the app.
    //
    // IMPORTANT: search for the -30dB point starting from the peak index,
    // not from index 0. Searching from the start is wrong — the receiver is
    // silent before the direct sound even arrives (especially when source
    // and receiver aren't co-located), and that pre-arrival silence is
    // already below the -30dB threshold, so a naive findIndex from 0 would
    // immediately "detect decay" during a period where sound hasn't arrived
    // yet, producing a bogus near-zero RT60 instead of a real one.
    const peakIdx = receiverTrace.indexOf(Math.max(...receiverTrace, 0));
    const peak = receiverTrace[peakIdx] || 1e-9;
    const decayIdxRelative = receiverTrace.slice(peakIdx).findIndex(v => v < peak * Math.pow(10, -30 / 20));
    let simulatedRt60: number | null = null;
    if (decayIdxRelative > 0) {
      simulatedRt60 = (decayIdxRelative * dt) * 2; // extrapolate -30dB point to -60dB
    }
    // This quick-preview run is far too short (numSteps <= 40, ~1-1.5ms of
    // simulated time) to ever actually reach a real -30dB decay in a
    // typical room (RT60 is usually 300-2000ms) — decayIdxRelative will
    // almost always be -1 here (no decay observed), which is the CORRECT,
    // honest outcome given the step budget. Do not be surprised that
    // simulatedRt60 is usually null; that's not a bug, it's the actual
    // limitation being surfaced instead of hidden. Use
    // /api/solver/impulse-response (below) for a run that's actually long
    // enough to produce a meaningful decay-based RT60/C50/C80/Ts.

    const volume = roomL * roomW * roomH;
    const wallArea = 2 * (roomL * roomH) + 2 * (roomW * roomH);
    const floorArea = roomL * roomW;
    const ceilArea = roomL * roomW;
    const totalSabins = (wallArea * wallAbs) + (floorArea * floorAbs) + (ceilArea * ceilAbs);
    const sabineRt60 = (0.161 * volume) / Math.max(totalSabins, 0.01);

    const endTime = Date.now();
    const durationMs = endTime - startTime;

    res.json({
      success: true,
      meshSize: N,
      gridDims: [nx, ny, nz],
      cellSizeM: dx,
      steps: numSteps,
      durationMs,
      rt60: sabineRt60,
      simulatedRt60,
      tier: isPro ? 'pro' : 'free',
      // Real per-step receiver pressure trace, exposed so the client can
      // derive genuine C50/C80/D50/Ts/STI instead of placeholder numbers.
      // dtEstimate lets the client convert sample index -> seconds.
      receiverTrace: Array.from(receiverTrace),
      dtEstimate: dt,
      message: `Computed ${numSteps} time steps over a ${nx}x${ny}x${nz} grid (${N.toLocaleString()} elements) matching your ${roomL}x${roomW}x${roomH}m room in ${durationMs}ms.`
    });

  } catch (err: any) {
    console.error("Wave Solver Error:", err);
    res.status(500).json({ error: err.message || "Engine memory limit exceeded." });
  }
});

// ---------------------------------------------------------------------------
// IMPULSE RESPONSE / DECAY-METRIC SOLVER
// ---------------------------------------------------------------------------
// The endpoint above is a quick preview run: it prioritizes a fine spatial
// grid (up to 30M elements) but, as a direct consequence of that fine grid,
// can only afford a handful of time steps (numSteps <= 40) before a single
// HTTP request would take too long — which means it only ever simulates
// roughly 1-1.5ms of real time. That's nowhere near enough for RT60
// (typically 300-2000ms), C50/C80 (need >= 80ms of IR), or Ts to mean
// anything; it was being computed from a trace that hadn't even let sound
// leave the source region yet.
//
// RT60/C50/C80/D50/Ts are TEMPORAL decay metrics — they don't need a fine
// spatial mesh to be physically valid, they need enough SIMULATED TIME.
// This endpoint deliberately trades spatial resolution for step count: a
// small, coarse grid (a few thousand to tens of thousands of elements,
// regardless of the visual-quality tier) that can run thousands of cheap
// steps instead of dozens of expensive ones, reaching real reverberation
// timescales.
//
// Step count is derived from this room's OWN Sabine RT60 estimate (using
// the same absorption data as everywhere else in the app) so short/dead
// rooms don't waste time simulating far past their decay, and
// long/reverberant rooms get enough steps to actually capture their tail.
// Hard-capped regardless, since this is still a synchronous request with no
// progress reporting — if that cap is hit before 2x the estimated RT60 is
// reached, the response says so explicitly rather than silently truncating.
app.post("/api/solver/impulse-response", express.json(), authMiddleware, solverGuard, async (req: any, res: any) => {
  const { L, W, H, wallMaterial, floorMaterial, ceilMaterial, source, receiver } = req.body;

  const roomL = Number(L) > 0 ? Number(L) : 10;
  const roomW = Number(W) > 0 ? Number(W) : 8;
  const roomH = Number(H) > 0 ? Number(H) : 3;

  const wallAbs = getAbsorptionAt500Hz(wallMaterial);
  const floorAbs = getAbsorptionAt500Hz(floorMaterial);
  const ceilAbs = getAbsorptionAt500Hz(ceilMaterial);

  // Estimate this room's RT60 up front (same Sabine formula used elsewhere)
  // purely to size the run — how many steps are actually needed to reach
  // ~2x the expected decay time, so short/absorptive rooms don't run
  // needlessly long and reverberant rooms get a real tail.
  const volume = roomL * roomW * roomH;
  const wallArea = 2 * (roomL * roomH) + 2 * (roomW * roomH);
  const floorArea = roomL * roomW;
  const ceilArea = roomL * roomW;
  const totalSabins = (wallArea * wallAbs) + (floorArea * floorAbs) + (ceilArea * ceilAbs);
  const estimatedRt60 = (0.161 * volume) / Math.max(totalSabins, 0.01);
  const targetDurationSec = Math.min(estimatedRt60 * 2, 3); // cap target at 3s even for very live rooms

  // Deliberately coarse, fixed-small grid — independent of plan tier, since
  // decay-metric accuracy here depends on step count, not mesh fineness.
  // ~15,000 elements keeps each step cheap enough to run thousands of them
  // synchronously. This is a genuine, documented engineering trade-off
  // (coarse mesh, long duration) for decay analysis, not a shortcut to look
  // more finished than it is.
  const targetElements = 15000;
  const rawCellVolume = volume / targetElements;
  const dx = Math.max(Math.cbrt(rawCellVolume), 0.05); // coarser floor (5cm) than the preview solver
  const nx = Math.max(4, Math.round(roomL / dx));
  const ny = Math.max(4, Math.round(roomH / dx));
  const nz = Math.max(4, Math.round(roomW / dx));
  const N = nx * ny * nz;
  const nxy = nx * ny;

  // dt must match the Courant coefficient the update loop below actually
  // uses (0.1), not an independent dx/c estimate -- see the /api/solver/wave
  // endpoint above for the full derivation of why Courant^2 = (c*dt/dx)^2 is
  // required for these two numbers to describe the same physics.
  const COURANT = 0.1;
  const dt = (dx * Math.sqrt(COURANT)) / 343;
  const stepsForTarget = Math.ceil(targetDurationSec / dt);
  // Hard cap on steps regardless of target, to bound worst-case request
  // time since this is still synchronous with no progress reporting.
  // NOTE: this cap was not empirically benchmarked in this environment (no
  // ability to run Node here) — treat it as a starting point and tune
  // based on real request latency once deployed.
  const MAX_STEPS = 6000;
  const numSteps = Math.min(stepsForTarget, MAX_STEPS);
  const reachedTarget = stepsForTarget <= MAX_STEPS;

  const wallRefl = Math.sqrt(Math.max(1 - wallAbs, 0));
  const floorRefl = Math.sqrt(Math.max(1 - floorAbs, 0));
  const ceilRefl = Math.sqrt(Math.max(1 - ceilAbs, 0));

  const clamp01 = (v: number) => Math.min(0.98, Math.max(0.02, v));
  const srcX = clamp01(source?.x ?? 0.5), srcZ = clamp01(source?.y ?? 0.5);
  const srcIx = Math.round(srcX * (nx - 1));
  const srcIy = Math.round((source?.z != null ? clamp01(source.z / roomH) : 0.7) * (ny - 1));
  const srcIz = Math.round(srcZ * (nz - 1));
  const srcIdx = srcIy * nxy + srcIz * nx + srcIx;

  const recX = clamp01(receiver?.x ?? 0.25), recZ = clamp01(receiver?.y ?? 0.5);
  const recIx = Math.round(recX * (nx - 1));
  const recIy = Math.round((receiver?.z != null ? clamp01(receiver.z / roomH) : 0.5) * (ny - 1));
  const recIz = Math.round(recZ * (nz - 1));
  const recIdx = recIy * nxy + recIz * nx + recIx;

  console.log(`[IMPULSE RESPONSE SOLVER] Room ${roomL}x${roomW}x${roomH}m -> coarse grid ${nx}x${ny}x${nz} (${N.toLocaleString()} elements, dx=${dx.toFixed(3)}m). Steps: ${numSteps}/${stepsForTarget} (target ${targetDurationSec.toFixed(2)}s).`);

  try {
    const startTime = Date.now();
    const p_prev = new Float32Array(N);
    const p = new Float32Array(N);
    const p_next = new Float32Array(N);
    p[Math.max(0, Math.min(N - 1, srcIdx))] = 1.0;

    const Courant = COURANT; // must match the COURANT used to derive dt above, or dt mislabels the trace's real time axis
    const receiverTrace: number[] = [];

    for (let t = 0; t < numSteps; t++) {
      for (let iy = 1; iy < ny - 1; iy++) {
        for (let iz = 1; iz < nz - 1; iz++) {
          const rowBase = iy * nxy + iz * nx;
          for (let ix = 1; ix < nx - 1; ix++) {
            const i = rowBase + ix;
            p_next[i] = (2 * p[i]) - p_prev[i] + Courant * (
              p[i - 1] + p[i + 1] +
              p[i - nx] + p[i + nx] +
              p[i - nxy] + p[i + nxy] -
              (6 * p[i])
            );
          }
        }
      }

      for (let iz = 0; iz < nz; iz++) {
        for (let ix = 0; ix < nx; ix++) {
          p_next[0 * nxy + iz * nx + ix] *= floorRefl;
          p_next[(ny - 1) * nxy + iz * nx + ix] *= ceilRefl;
        }
      }
      for (let iy = 0; iy < ny; iy++) {
        for (let ix = 0; ix < nx; ix++) {
          p_next[iy * nxy + 0 * nx + ix] *= wallRefl;
          p_next[iy * nxy + (nz - 1) * nx + ix] *= wallRefl;
        }
        for (let iz = 0; iz < nz; iz++) {
          p_next[iy * nxy + iz * nx + 0] *= wallRefl;
          p_next[iy * nxy + iz * nx + (nx - 1)] *= wallRefl;
        }
      }

      receiverTrace.push(Math.abs(p_next[Math.max(0, Math.min(N - 1, recIdx))]));

      p_prev.set(p);
      p.set(p_next);
    }

    const peakIdx = receiverTrace.indexOf(Math.max(...receiverTrace, 0));
    const peak = receiverTrace[peakIdx] || 1e-9;
    const decayIdxRelative = receiverTrace.slice(peakIdx).findIndex(v => v < peak * Math.pow(10, -30 / 20));
    let simulatedRt60: number | null = null;
    if (decayIdxRelative > 0) {
      simulatedRt60 = (decayIdxRelative * dt) * 2;
    }

    const actualDurationSec = numSteps * dt;
    const sabineRt60 = estimatedRt60;
    const durationMs = Date.now() - startTime;

    res.json({
      success: true,
      meshSize: N,
      gridDims: [nx, ny, nz],
      cellSizeM: dx,
      steps: numSteps,
      requestedSteps: stepsForTarget,
      reachedTarget,
      actualDurationSec,
      targetDurationSec,
      computeTimeMs: durationMs,
      rt60: sabineRt60,
      simulatedRt60,
      receiverTrace: Array.from(receiverTrace),
      dtEstimate: dt,
      warning: reachedTarget
        ? null
        : `Simulation was capped at ${numSteps} steps (${actualDurationSec.toFixed(2)}s simulated) before reaching the ${targetDurationSec.toFixed(2)}s target for this room's estimated decay time. RT60/C50/C80/Ts derived from this trace may understate the room's true reverberance.`,
      message: `Computed ${numSteps} time steps (${actualDurationSec.toFixed(2)}s simulated, coarse ${nx}x${ny}x${nz} grid) in ${durationMs}ms.`
    });
  } catch (err: any) {
    console.error("Impulse Response Solver Error:", err);
    res.status(500).json({ error: err.message || "Impulse response computation failed." });
  }
});

async function startServer() {
  // The DB (server/db.ts) is a single JSON file on local disk. That's fine
  // on a host with a real persistent filesystem, but on most container/
  // serverless platforms (e.g. a fresh container per deploy, or per
  // invocation) the local disk does NOT survive a restart or redeploy --
  // every signup, project, and promo code minted since the last deploy
  // would silently vanish, with no error at the time it happens. This can't
  // be detected reliably from inside the process, so this is a loud
  // reminder rather than a hard failure: read it once at boot, verify your
  // hosting platform actually persists ./data across restarts (a mounted
  // volume, not the default ephemeral container disk) before relying on
  // this in production.
  if (process.env.NODE_ENV === "production") {
    console.warn(
      "[startup] Using a local JSON file as the database (server/db.ts). " +
      "Confirm your hosting platform mounts ./data on PERSISTENT storage -- " +
      "on ephemeral/serverless platforms this data is lost on every restart or redeploy."
    );
  }

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => res.sendFile(path.join(distPath, 'index.html')));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
