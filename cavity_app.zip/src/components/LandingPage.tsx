import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Headphones, Activity, Cpu, Layers, Play, ChevronRight, Waves } from 'lucide-react';
import { useAuthStore } from '../store/useAuthStore';
import { useStore } from '../store/useStore';
import { AuthModal } from './AuthModal';
import { motion } from 'motion/react';

export default function LandingPage() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { theme } = useStore();
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleGetStarted = () => {
    if (user) {
      navigate('/app');
    } else {
      setShowAuthModal(true);
    }
  };

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-[#0a0a0c] text-[#e7e7e5]' : 'bg-[#fafafa] text-[#111827]'} font-sans overflow-x-hidden selection:bg-[#43d9b8]/30`}>
      {/* Navigation */}
      <nav className={`w-full px-6 py-5 flex items-center justify-between border-b ${theme === 'dark' ? 'border-[#2a2c30]/50 bg-[#0a0a0c]/80' : 'border-gray-200/50 bg-[#fafafa]/80'} backdrop-blur-md sticky top-0 z-50`}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-[#43d9b8]/10 flex items-center justify-center border border-[#43d9b8]/30">
            <Activity className="text-[#43d9b8]" size={18} />
          </div>
          <span className="font-bold text-xl tracking-tight">Auralizer</span>
        </div>
        <div className="flex items-center gap-4">
          {!user ? (
            <>
              <button 
                onClick={() => setShowAuthModal(true)}
                className={`font-semibold text-sm ${theme === 'dark' ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-black'} transition-colors`}
              >
                Log In
              </button>
              <button 
                onClick={handleGetStarted}
                className="px-5 py-2.5 rounded-lg bg-white text-black font-bold text-sm hover:scale-105 transition-all shadow-[0_0_15px_rgba(255,255,255,0.1)] border border-gray-200"
              >
                Sign Up
              </button>
            </>
          ) : (
            <button 
              onClick={() => navigate('/app')}
              className="px-5 py-2.5 rounded-lg bg-[#43d9b8] text-black font-bold text-sm hover:scale-105 transition-all shadow-lg shadow-[#43d9b8]/20"
            >
              Open Workspace
            </button>
          )}
        </div>
      </nav>

      {/* Hero Section - Centered & Minimalist */}
      <section className="relative px-6 pt-32 pb-40 md:pt-48 md:pb-56 max-w-7xl mx-auto flex flex-col items-center text-center">
        {/* Subtle Ambient Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-[800px] aspect-square bg-gradient-to-tr from-[#43d9b8]/15 via-blue-500/10 to-purple-500/15 blur-[120px] rounded-full -z-10 pointer-events-none" />

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#43d9b8]/10 text-[#43d9b8] font-bold text-xs uppercase tracking-wider mb-8 border border-[#43d9b8]/30 backdrop-blur-md"
        >
          <Cpu size={14} /> God-Tier GPU Acoustics
        </motion.div>
        
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-6xl md:text-8xl font-extrabold tracking-tight mb-8 leading-[1.05] max-w-5xl"
        >
          Hear the mansion <br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#43d9b8] via-[#60a5fa] to-[#8a2be2]">before it's built.</span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className={`text-xl md:text-2xl max-w-3xl mb-12 leading-relaxed ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}
        >
          Enterprise-grade 3D acoustic simulation in your browser. Design grand spaces, assign high-end materials, and map sound propagation in real-time.
        </motion.p>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-5"
        >
          <button 
            onClick={handleGetStarted}
            className="px-10 py-5 rounded-2xl bg-[#43d9b8] text-black font-extrabold text-lg hover:scale-105 transition-all shadow-[0_0_40px_rgba(67,217,184,0.3)] flex items-center justify-center gap-3"
          >
            <Play fill="currentColor" size={20} />
            {user ? 'Enter Simulator' : 'Start Designing'}
          </button>
          {!user && (
            <button 
              onClick={() => setShowAuthModal(true)}
              className={`px-10 py-5 rounded-2xl font-bold text-lg hover:scale-105 transition-all flex items-center justify-center gap-2 ${theme === 'dark' ? 'bg-[#1a1b1e] text-white border border-[#2a2c30] hover:bg-[#2a2c30]' : 'bg-white text-black border border-gray-200 hover:bg-gray-50 shadow-sm'}`}
            >
              Log In <ChevronRight size={20} />
            </button>
          )}
        </motion.div>
      </section>

      {/* Features Grid */}
      <section className={`py-32 border-t relative overflow-hidden ${theme === 'dark' ? 'bg-[#0a0a0c] border-[#2a2c30]' : 'bg-[#fafafa] border-gray-200'}`}>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center mb-24">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">Design like an architect.<br/>Listen like an engineer.</h2>
            <p className={`text-xl max-w-2xl mx-auto ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>Everything you need to perfectly tune a room's acoustics, running flawlessly without a single download.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Layers size={28} className="text-[#43d9b8]" />}
              title="Mansion & Studio Drafting"
              description="Draw massive floorplans instantly. Map out grand halls, recording studios, and modern glass homes with pixel-perfect precision."
              theme={theme}
            />
            <FeatureCard 
              icon={<Headphones size={28} className="text-[#43d9b8]" />}
              title="Immersive Auralization"
              description="Place sound emitters and receivers in 3D space. Plug in your microphone or play a track to hear exactly how the room echoes."
              theme={theme}
            />
            <FeatureCard 
              icon={<Cpu size={28} className="text-[#43d9b8]" />}
              title="God Tier GPU Solver"
              description="Harness your local graphics card. Our C-based GLSL engine computes millions of mesh elements 4000x faster than cloud servers."
              theme={theme}
            />
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className={`py-12 border-t text-center text-sm ${theme === 'dark' ? 'border-[#2a2c30] text-gray-600' : 'border-gray-200 text-gray-400'}`}>
        <p>&copy; {new Date().getFullYear()} Auralizer. All rights reserved.</p>
      </footer>

      {/* Auth Modal Mounting */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
    </div>
  );
}

function FeatureCard({ icon, title, description, theme }: { icon: React.ReactNode, title: string, description: string, theme: string }) {
  return (
    <div className={`p-10 rounded-3xl border ${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30]' : 'bg-white border-gray-200'} transition-all hover:-translate-y-2 hover:shadow-[0_20px_40px_rgba(0,0,0,0.1)] group`}>
      <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-8 ${theme === 'dark' ? 'bg-[#0a0a0c] border border-[#2a2c30]' : 'bg-gray-50 border border-gray-100 shadow-sm'} group-hover:scale-110 transition-transform`}>
        {icon}
      </div>
      <h3 className="text-2xl font-bold mb-4 tracking-tight">{title}</h3>
      <p className={`leading-relaxed text-lg ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
        {description}
      </p>
    </div>
  );
}
