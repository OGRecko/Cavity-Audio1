import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useStore } from '../store/useStore';
import { useAuthStore } from '../store/useAuthStore';
import { Settings, Layers, Speaker, User, X, Activity, Headphones, Eye, Search, ChevronDown } from 'lucide-react';
import { MATERIALS } from '../lib/materials';
import { SPEAKERS } from '../lib/speakers';
import { audioEngine } from '../lib/audioEngine';
import LeftSidebar from './LeftSidebar';
import SpeakerPicker from './SpeakerPicker';

function SearchableSpeakerSelect({ source }: { source: any }) {
  const { theme, updateSource } = useStore();
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredSpeakers = useMemo(() => {
    const q = search.toLowerCase();
    return SPEAKERS.filter(spk => `${spk.brand} ${spk.model}`.toLowerCase().includes(q));
  }, [search]);

  return (
    <div className="relative" ref={ref}>
      <div 
        className={`flex items-center justify-between cursor-pointer border text-xs p-1.5 rounded outline-none w-full ${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30] text-[#e7e7e5]' : 'bg-[#ffffff] border-[#e5e7eb] text-black'}`}
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="truncate pr-2">{source.brand} {source.model}</span>
        <ChevronDown size={14} className="shrink-0 opacity-50" />
      </div>

      {isOpen && (
        <div className={`absolute z-50 w-full mt-1 border rounded shadow-lg overflow-hidden ${theme === 'dark' ? 'bg-[#1a1b1e] border-[#2a2c30]' : 'bg-[#ffffff] border-[#e5e7eb]'}`}>
          <div className="p-2 border-b border-inherit">
            <div className={`flex items-center px-2 py-1 rounded bg-opacity-50 ${theme === 'dark' ? 'bg-[#141517]' : 'bg-[#f0f2f5]'}`}>
              <Search size={12} className="opacity-50 mr-2" />
              <input 
                type="text"
                autoFocus
                className="w-full bg-transparent text-xs outline-none"
                placeholder="Search speakers..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
          <div className="max-h-48 overflow-y-auto">
            {filteredSpeakers.map(spk => (
              <div 
                key={spk.id}
                className={`px-3 py-1.5 text-xs cursor-pointer truncate ${theme === 'dark' ? 'hover:bg-[#202226]' : 'hover:bg-[#f3f4f6]'}`}
                onClick={() => {
                  updateSource(source.id, { brand: spk.brand, model: spk.model, type: spk.type, sens: spk.sens });
                  setIsOpen(false);
                  setSearch('');
                }}
              >
                {spk.brand} {spk.model}
              </div>
            ))}
            {filteredSpeakers.length === 0 && (
              <div className="px-3 py-2 text-xs opacity-50">No results found</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function RightSidebar() {
  const { subscriptionData } = useAuthStore();
  const { isPlaying } = useStore();
  const [activeTab, setActiveTab] = useState('settings');

  const [solverStatus, setSolverStatus] = useState<string>('Idle');
  const [irStatus, setIrStatus] = useState<string>('idle'); // 'idle' | 'computing' | 'done' | 'error'
  const [irWarning, setIrWarning] = useState<string | null>(null);

  const runImpulseResponse = async () => {
    setIrStatus('computing');
    setIrWarning(null);
    try {
      const state = useStore.getState();
      const activeSource = state.sources.find(s => !s.muted) || state.sources[0];
      const activeReceiver = state.receivers.find(r => r.id === state.activeReceiverId) || state.receivers[0];

      // Deliberately separate from the quick preview solver above: this
      // trades spatial resolution for enough simulated TIME to produce a
      // real decay curve (RT60/C50/C80/D50/Ts), which the quick preview
      // (fine grid, ~1ms of simulated time) cannot do. See server.ts's
      // /api/solver/impulse-response for the full reasoning.
      const res = await fetch('/api/solver/impulse-response', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          L: state.L, W: state.W, H: state.H,
          wallMaterial: state.wallMaterial,
          floorMaterial: state.floorMaterial,
          ceilMaterial: state.ceilMaterial,
          source: activeSource ? { x: activeSource.x, y: activeSource.y, z: activeSource.z } : null,
          receiver: activeReceiver ? { x: activeReceiver.x, y: activeReceiver.y, z: activeReceiver.z } : null,
        })
      });
      const data = await res.json();
      if (data.success) {
        useStore.getState().setLastImpulseResponseResult(data);
        setIrWarning(data.warning || null);
        setIrStatus('done');
      } else if (res.status === 429) {
        setIrWarning(data.error || 'Server busy — please wait a moment and try again.');
        setIrStatus('error');
      } else {
        setIrStatus('error');
      }
    } catch (e) {
      console.error(e);
      setIrStatus('error');
    }
  };

  const [exportStatus, setExportStatus] = useState<'idle' | 'exporting' | 'error'>('idle');
  const [exportError, setExportError] = useState<string | null>(null);
  const lastIrResultForExport = useStore((s: any) => s.lastImpulseResponseResult);

  const exportReport = async () => {
    setExportStatus('exporting');
    setExportError(null);
    try {
      const state = useStore.getState();
      const receiver = state.receivers.find(r => r.id === state.activeReceiverId) || state.receivers[0];

      const res = await fetch('/api/report/export', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectName: state.projectName,
          roomName: state.roomName,
          room: {
            poly: state.poly,
            L: state.L, W: state.W, H: state.H,
            wallMaterial: state.wallMaterial,
            wallSegMats: state.wallSegMats,
            floorMaterial: state.floorMaterial,
            ceilMaterial: state.ceilMaterial,
          },
          speakers: state.sources.map(s => ({ brand: s.brand, model: s.model, type: s.type, x: s.x, y: s.y })),
          receivers: state.receivers.map(r => ({ name: r.name, x: r.x, y: r.y })),
          // Only include the long-duration impulse response result (not
          // the quick preview) — see server/reportGenerator.ts's comment on
          // why mixing the two would produce a meaningless simulatedRt60
          // and could give a false STI reading.
          solverResult: lastIrResultForExport ? {
            rt60: lastIrResultForExport.rt60,
            simulatedRt60: lastIrResultForExport.simulatedRt60,
            gridDims: lastIrResultForExport.gridDims,
            tier: lastIrResultForExport.tier,
            receiverTrace: lastIrResultForExport.receiverTrace,
            dtEstimate: lastIrResultForExport.dtEstimate,
          } : null,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Export failed (${res.status})`);
      }

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${(state.projectName || 'cavity-report').replace(/[^a-z0-9\-_]/gi, '_')}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setExportStatus('idle');
    } catch (e: any) {
      console.error(e);
      setExportError(e.message || 'Failed to generate report.');
      setExportStatus('error');
    }
  };

  useEffect(() => {
    if (isPlaying) {
      setSolverStatus('Computing 3D Wave...');
      
      const runSolvers = async () => {
        try {
          const state = useStore.getState();
          const isPro = subscriptionData?.plan === 'premium' || subscriptionData?.plan === 'lifetime';
          // Free tier is capped at ~250k elements, Pro gets the full 30M budget
          // (matches what the paywall actually promises) — the server clamps
          // this again server-side so a tampered request can't bypass the tier.
          const elementBudget = isPro ? 30000000 : 250000;

          const activeSource = state.sources.find(s => !s.muted) || state.sources[0];
          const activeReceiver = state.receivers.find(r => r.id === state.activeReceiverId) || state.receivers[0];

          // Run CPU solver on the room the person actually built: real
          // dimensions, real wall/floor/ceiling materials, and the real
          // source/listener positions they placed — not a generic floating cube.
          const res = await fetch('/api/solver/wave', {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              elements: elementBudget,
              steps: isPro ? 20 : 5,
              L: state.L, W: state.W, H: state.H,
              wallMaterial: state.wallMaterial,
              floorMaterial: state.floorMaterial,
              ceilMaterial: state.ceilMaterial,
              source: activeSource ? { x: activeSource.x, y: activeSource.y, z: activeSource.z } : null,
              receiver: activeReceiver ? { x: activeReceiver.x, y: activeReceiver.y, z: activeReceiver.z } : null,
            })
          });
          const data = await res.json();

          if (data.success) {
            const rt60Text = typeof data.rt60 === 'number' ? ` | RT60 ${data.rt60.toFixed(2)}s` : '';
            setSolverStatus(`Computed ${data.meshSize.toLocaleString()} elements (${data.gridDims?.join('x')})${rt60Text}`);
            // Store the full result so LeftSidebar can derive real
            // IR/EDC/C50/C80/D50/Ts from the actual receiver trace instead
            // of showing placeholder data.
            useStore.getState().setLastSolverResult(data);
          } else if (res.status === 429) {
            setSolverStatus(data.error || 'Server busy — please wait a moment and try again.');
          } else {
            setSolverStatus('Computation Failed');
          }
        } catch (e) {
          setSolverStatus('Network Error');
        }
      };
      
      runSolvers();
    } else {
      setSolverStatus('Idle');
    }
  }, [isPlaying, subscriptionData]);

  const [micStatus, setMicStatusState] = useState(audioEngine.micStatus);
  const { 
    view, setView, theme,
    sources, receivers, addSource, removeSource, addReceiver, removeReceiver, updateSource,
    wallMaterial, setWallMaterial, floorMaterial, setFloorMaterial, ceilMaterial, setCeilMaterial,
    selectedWallSeg, wallSegMats, setWallSegMat,
    wallOpenings, setWallOpening,
    L, W, H, setL, setW, setH, setPoly,
    audioSourceType, setAudioSourceType, transitionFreqMode, setTransitionFreqMode,
    availableMics, setAvailableMics, selectedMicId, setSelectedMicId
  } = useStore();

  const [gapRange, setGapRange] = useState<{start: number, end: number}>({ start: 0.3, end: 0.7 });

  // Local text state for the dimension inputs so the user can type freely
  // (e.g. clear the field, type "3.") without the store's min-clamp fighting
  // every keystroke. Only commits to the store (and clamps) on blur/Enter.
  const [dimDraft, setDimDraft] = useState<{ L: string; W: string; H: string }>({
    L: String(L), W: String(W), H: String(H),
  });
  useEffect(() => {
    setDimDraft({ L: String(L), W: String(W), H: String(H) });
  }, [L, W, H]);

  const commitDim = (axis: 'L' | 'W' | 'H', raw: string) => {
    const n = parseFloat(raw);
    if (!isNaN(n) && n > 0) {
      if (axis === 'L') setL(n);
      else if (axis === 'W') setW(n);
      else setH(n);
    } else {
      // Invalid entry: revert the draft to the current committed value
      // rather than silently accepting garbage into the store.
      setDimDraft(d => ({ ...d, [axis]: String(axis === 'L' ? L : axis === 'W' ? W : H) }));
    }
  };

  const fetchMics = async () => {
    if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const mics = devices.filter(d => d.kind === 'audioinput');
      setAvailableMics(mics);
      // If we don't have a selected mic, or the selected one isn't in the list anymore
      if (mics.length > 0) {
        useStore.setState(state => {
          if (!state.selectedMicId || !mics.find(m => m.deviceId === state.selectedMicId)) {
            return { selectedMicId: mics[0].deviceId };
          }
          return {};
        });
      }
    }
  };

  useEffect(() => {
    fetchMics();
    if (navigator.mediaDevices && navigator.mediaDevices.addEventListener) {
      navigator.mediaDevices.addEventListener('devicechange', fetchMics);
    }
    return () => {
      if (navigator.mediaDevices && navigator.mediaDevices.removeEventListener) {
        navigator.mediaDevices.removeEventListener('devicechange', fetchMics);
      }
    };
  }, [setAvailableMics]);

  useEffect(() => {
    audioEngine.onMicStatusChange = (status) => {
      setMicStatusState(status);
      if (status === 'active') {
        fetchMics(); // Labels might be populated now
      }
      // Keep the dropdown honest: if the mic request failed, don't leave it
      // showing "Microphone" while Song mode is actually what's playing.
      if (status === 'denied' || status === 'unsupported') {
        setAudioSourceType('song');
      }
    };
    return () => { audioEngine.onMicStatusChange = null; };
  }, [setAudioSourceType]);

  useEffect(() => {
    if (selectedWallSeg !== null) {
      setActiveTab('materials');
    }
  }, [selectedWallSeg]);

  const renderTabIcon = (id: string, icon: any, label: string) => (
    <div 
      className={`flex-1 flex flex-col items-center justify-center p-3 cursor-pointer border-b-2 text-[10px] uppercase font-bold tracking-wider transition-colors
        ${activeTab === id ? `border-[#43d9b8] ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'}` : `border-transparent ${theme === 'dark' ? 'text-[#83868c] hover:text-[#e7e7e5]' : 'text-[#6b7280] hover:text-black'}`}`}
      onClick={() => setActiveTab(id)}
    >
      {React.createElement(icon, { size: 20, className: `mb-2 ${activeTab === id ? 'text-[#43d9b8]' : ''}` })}
      {label}
    </div>
  );

  return (
    <div className={`w-[360px] ${theme === 'dark' ? 'bg-[#1a1b1e] border-[#2a2c30]' : 'bg-[#ffffff] border-[#e5e7eb]'} border-l flex flex-col h-full shrink-0`}>
      {view !== 'results' ? (
        <>
          <div className={`flex border-b ${theme === 'dark' ? 'border-[#2a2c30]' : 'border-[#e5e7eb]'}`}>
            {renderTabIcon('materials', Layers, 'Materials')}
            {renderTabIcon('sources', Speaker, 'Sources')}
            {renderTabIcon('speakerLibrary', Headphones, 'Speakers')}
            {renderTabIcon('receivers', User, 'Receivers')}
            {renderTabIcon('settings', Settings, 'Settings')}
          </div>

          <div className="flex-1 p-5 overflow-y-auto">
            {activeTab === 'materials' && (
          <div>
            <h3 className={`text-xs font-bold ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'} mb-4 uppercase tracking-wider`}>Room Dimensions</h3>
            <div className="grid grid-cols-3 gap-3 mb-6">
              {([
                { axis: 'L' as const, label: 'Length (m)' },
                { axis: 'W' as const, label: 'Width (m)' },
                { axis: 'H' as const, label: 'Height (m)' },
              ]).map(({ axis, label }) => (
                <div key={axis}>
                  <div className={`text-[10px] mb-1 uppercase tracking-wider ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>{label}</div>
                  <input
                    type="number"
                    step="0.1"
                    min="0.1"
                    className={`${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30] text-[#e7e7e5]' : 'bg-[#f9fafb] border-[#e5e7eb] text-black'} border text-xs p-1.5 rounded outline-none w-full`}
                    value={dimDraft[axis]}
                    onChange={(e) => setDimDraft(d => ({ ...d, [axis]: e.target.value }))}
                    onBlur={(e) => commitDim(axis, e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }}
                  />
                </div>
              ))}
            </div>

            <div className={`text-[10px] mb-2 uppercase tracking-wider ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>Starter Shape</div>
            <div className="flex flex-wrap gap-2 mb-6">
              {([
                { label: 'Square', poly: [{x: 0.1, y: 0.1}, {x: 0.9, y: 0.1}, {x: 0.9, y: 0.9}, {x: 0.1, y: 0.9}] },
                { label: 'L-Shape', poly: [{x: 0.3, y: 0.1}, {x: 0.7, y: 0.1}, {x: 0.7, y: 0.5}, {x: 0.9, y: 0.5}, {x: 0.9, y: 0.9}, {x: 0.3, y: 0.9}] },
                { label: 'Cross', poly: [{x: 0.4, y: 0.1}, {x: 0.6, y: 0.1}, {x: 0.6, y: 0.4}, {x: 0.9, y: 0.4}, {x: 0.9, y: 0.6}, {x: 0.6, y: 0.6}, {x: 0.6, y: 0.9}, {x: 0.4, y: 0.9}, {x: 0.4, y: 0.6}, {x: 0.1, y: 0.6}, {x: 0.1, y: 0.4}, {x: 0.4, y: 0.4}] },
                { label: 'U-Shape', poly: [{x: 0.2, y: 0.2}, {x: 0.4, y: 0.2}, {x: 0.4, y: 0.6}, {x: 0.6, y: 0.6}, {x: 0.6, y: 0.2}, {x: 0.8, y: 0.2}, {x: 0.8, y: 0.8}, {x: 0.2, y: 0.8}] },
                { label: 'H-Shape', poly: [{x: 0.2, y: 0.1}, {x: 0.4, y: 0.1}, {x: 0.4, y: 0.4}, {x: 0.6, y: 0.4}, {x: 0.6, y: 0.1}, {x: 0.8, y: 0.1}, {x: 0.8, y: 0.9}, {x: 0.6, y: 0.9}, {x: 0.6, y: 0.6}, {x: 0.4, y: 0.6}, {x: 0.4, y: 0.9}, {x: 0.2, y: 0.9}] },
              ]).map(shape => (
                <button
                  key={shape.label}
                  onClick={() => setPoly(shape.poly)}
                  className="flex-1 min-w-[70px] py-1 px-2 border border-[#43d9b8] text-[#43d9b8] rounded text-xs hover:bg-[#43d9b8] hover:text-black"
                >
                  {shape.label}
                </button>
              ))}
            </div>

            <h3 className={`text-xs font-bold ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'} mb-4 uppercase tracking-wider`}>Global Materials</h3>

            <div className="grid grid-cols-[auto_1fr_auto] gap-x-3 gap-y-4 items-center mb-6">
              <div className={`font-bold flex items-center ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'}`}><span className="text-[8px] mr-1">▶</span> A-WALL</div>
              <div className="flex items-center">
                 <select 
                    className={`${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30] text-[#e7e7e5]' : 'bg-[#f9fafb] border-[#e5e7eb] text-black'} border text-xs p-1 rounded outline-none w-full appearance-none`}
                    value={wallMaterial}
                    onChange={(e) => setWallMaterial(e.target.value)}
                 >
                    {MATERIALS.walls.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                 </select>
              </div>
              <div className={`font-mono text-xs ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'} text-right`}>0.15</div>
              
              <div className={`font-bold flex items-center ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'}`}><span className="text-[8px] mr-1">▶</span> A-FLOR</div>
              <div className="flex items-center">
                 <select 
                    className={`${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30] text-[#e7e7e5]' : 'bg-[#f9fafb] border-[#e5e7eb] text-black'} border text-xs p-1 rounded outline-none w-full appearance-none`}
                    value={floorMaterial}
                    onChange={(e) => setFloorMaterial(e.target.value)}
                 >
                    {MATERIALS.floor.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                 </select>
              </div>
              <div className={`font-mono text-xs ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'} text-right`}>0.15</div>
              
              <div className={`font-bold flex items-center ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'}`}><span className="text-[8px] mr-1">▶</span> A-CLNG</div>
              <div className="flex items-center">
                 <select 
                    className={`${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30] text-[#e7e7e5]' : 'bg-[#f9fafb] border-[#e5e7eb] text-black'} border text-xs p-1 rounded outline-none w-full appearance-none`}
                    value={ceilMaterial}
                    onChange={(e) => setCeilMaterial(e.target.value)}
                 >
                    {MATERIALS.ceiling.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                 </select>
              </div>
              <div className={`font-mono text-xs ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'} text-right`}>0.15</div>
            </div>

            {selectedWallSeg !== null && (
              <div className={`${theme === 'dark' ? 'bg-[#202226]' : 'bg-[#ffffff]'} p-4 rounded border border-[#43d9b8]`}>
                <h4 className="text-xs font-bold text-[#43d9b8] mb-3">Wall {selectedWallSeg + 1} Override</h4>
                <div className="flex items-center space-x-2">
                   <select 
                      className={`${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30] text-[#e7e7e5]' : 'bg-[#ffffff] border-[#e5e7eb] text-black'} border text-xs p-2 rounded outline-none flex-1 appearance-none`}
                      value={wallSegMats[selectedWallSeg] || ''}
                      onChange={(e) => setWallSegMat(selectedWallSeg, e.target.value || null)}
                      disabled={wallOpenings[selectedWallSeg] === 'full'}
                   >
                      <option value="">-- Use Global Wall Material --</option>
                      {MATERIALS.walls.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                   </select>
                </div>

                <div className={`mt-4 pt-4 border-t ${theme === 'dark' ? 'border-[#2a2c30]' : 'border-[#e5e7eb]'}`}>
                  <h5 className={`text-[10px] font-bold uppercase tracking-wider mb-3 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>Wall Opening</h5>

                  {wallOpenings[selectedWallSeg] === 'full' ? (
                    <div>
                      <p className="text-[10px] text-red-400 mb-3">This wall is fully removed (open).</p>
                      <button
                        onClick={() => setWallOpening(selectedWallSeg, null)}
                        className="w-full text-xs font-bold py-2 rounded border border-[#43d9b8] text-[#43d9b8] hover:bg-[#43d9b8] hover:text-black transition-colors"
                      >
                        Restore Wall
                      </button>
                    </div>
                  ) : wallOpenings[selectedWallSeg] && typeof wallOpenings[selectedWallSeg] === 'object' ? (
                    <div>
                      {(() => {
                        const o = wallOpenings[selectedWallSeg] as { start: number; end: number };
                        return (
                          <p className="text-[10px] text-red-400 mb-3">
                            Section removed ({Math.round(o.start * 100)}%–{Math.round(o.end * 100)}% of wall length).
                          </p>
                        );
                      })()}
                      <div className="flex gap-2">
                        <button
                          onClick={() => setWallOpening(selectedWallSeg, null)}
                          className="flex-1 text-xs font-bold py-2 rounded border border-[#43d9b8] text-[#43d9b8] hover:bg-[#43d9b8] hover:text-black transition-colors"
                        >
                          Restore Wall
                        </button>
                        <button
                          onClick={() => setWallOpening(selectedWallSeg, 'full')}
                          className="flex-1 text-xs font-bold py-2 rounded border border-red-400 text-red-400 hover:bg-red-400 hover:text-black transition-colors"
                        >
                          Delete Entire Wall
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <p className={`text-[10px] mb-3 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
                        Cut a doorway/window out of part of this wall, or remove it entirely.
                      </p>
                      <div className="mb-4 space-y-3">
                        <div>
                          <div className={`flex justify-between text-[10px] mb-1 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
                            <span>Gap Start</span>
                            <span>{Math.round(gapRange.start * 100)}%</span>
                          </div>
                          <input
                            type="range" min="0" max="0.95" step="0.05"
                            value={gapRange.start}
                            onChange={(e) => {
                              const start = parseFloat(e.target.value);
                              setGapRange(g => ({ start, end: Math.max(start + 0.05, g.end) }));
                            }}
                            className="w-full accent-[#43d9b8]"
                          />
                        </div>
                        <div>
                          <div className={`flex justify-between text-[10px] mb-1 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>
                            <span>Gap End</span>
                            <span>{Math.round(gapRange.end * 100)}%</span>
                          </div>
                          <input
                            type="range" min="0.05" max="1" step="0.05"
                            value={gapRange.end}
                            onChange={(e) => {
                              const end = parseFloat(e.target.value);
                              setGapRange(g => ({ start: Math.min(g.start, end - 0.05), end }));
                            }}
                            className="w-full accent-[#43d9b8]"
                          />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setWallOpening(selectedWallSeg, { start: gapRange.start, end: gapRange.end })}
                          className="flex-1 text-xs font-bold py-2 rounded border border-[#43d9b8] text-[#43d9b8] hover:bg-[#43d9b8] hover:text-black transition-colors"
                        >
                          Delete Section
                        </button>
                        <button
                          onClick={() => setWallOpening(selectedWallSeg, 'full')}
                          className="flex-1 text-xs font-bold py-2 rounded border border-red-400 text-red-400 hover:bg-red-400 hover:text-black transition-colors"
                        >
                          Delete Entire Wall
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {selectedWallSeg === null && (
               <p className={`text-[10px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>Click on a specific wall in the 3D view to override its material, or delete part of it (doorway/window) or the entire wall.</p>
            )}
          </div>
        )}

        {activeTab === 'sources' && (
          <div>
            {sources.length === 0 ? (
              <p className={`text-[12px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} mb-4`}>No sources added.</p>
            ) : (
              sources.map((s, i) => (
                <div key={s.id} className={`flex flex-col justify-between items-stretch ${theme === 'dark' ? 'bg-[#202226] border-[#2a2c30]' : 'bg-[#ffffff] border-[#e5e7eb]'} p-3 rounded mb-2 border shadow-sm`}>
                  <div className="flex justify-between items-center mb-2">
                    <span className={`text-sm font-semibold truncate ${theme === 'dark' ? 'text-white' : 'text-black'}`}>
                      <span className="w-4 h-4 rounded-full bg-[#43d9b8] inline-flex items-center justify-center mr-2 text-[#0d0e0f] text-[9px] font-bold">{i + 1}</span>
                      Source {i + 1}
                    </span>
                    <button onClick={(e) => { e.stopPropagation(); removeSource(s.id); }} className="text-red-400 hover:text-red-300 cursor-pointer z-50 p-1"><X size={16} /></button>
                  </div>
                  <SearchableSpeakerSelect source={s} />
                  <span className={`text-[10px] mt-2 ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'}`}>{s.type}</span>
                </div>
              ))
            )}
            
            <button 
              onClick={() => {
                // SPEAKERS is a static bundled dataset (356 entries as of
                // this build), so SPEAKERS[0] is realistically always
                // present -- but guard anyway rather than assume: a future
                // data regression here would otherwise throw on every click
                // of this button instead of failing visibly/gracefully.
                const spk = SPEAKERS[0];
                if (!spk) return;
                addSource({
                  id: Math.random().toString(),
                  brand: spk.brand,
                  model: spk.model,
                  type: spk.type,
                  sens: spk.sens,
                  x: Math.random() * 0.5 + 0.25,
                  y: Math.random() * 0.5 + 0.25,
                  gainDb: 0,
                  muted: false
                });
              }}
              className={`w-full mt-4 ${theme === 'dark' ? 'bg-[#202226] border-[#43d9b8]' : 'bg-[#f9fafb] border-[#43d9b8]'} border border-dashed text-[#43d9b8] p-2 rounded text-xs hover:bg-[#43d9b8] hover:text-black transition-colors`}
            >
              + Add Sound Source
            </button>

            <p className={`text-[10px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} mt-2 text-center`}>Drag sources in the 3D view to move them.</p>
          </div>
        )}

        {activeTab === 'speakerLibrary' && (
          <div>
            <h3 className={`text-xs font-bold ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'} mb-4 uppercase tracking-wider`}>Speaker Library</h3>
            <p className={`text-[10px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} mb-4`}>
              Browse specs-verified speakers and audition their derived DSP character. Selecting one applies it as the Audio Source's speaker model.
            </p>
            <SpeakerPicker
              onSelect={(spk: any) => {
                const sources = useStore.getState().sources;
                const target = sources[0];
                if (target) {
                  updateSource(target.id, { brand: spk.brand, model: spk.model, type: spk.category, sens: spk.sensitivity_db ?? 90 });
                }
              }}
            />
          </div>
        )}

        {activeTab === 'receivers' && (
          <div>
            {receivers.map((r, i) => (
              <div key={r.id} className={`flex justify-between items-center ${theme === 'dark' ? 'bg-[#202226] border-[#2a2c30]' : 'bg-[#ffffff] border-[#e5e7eb]'} p-3 rounded mb-2 border shadow-sm`}>
                <span className={`text-sm ${theme === 'dark' ? 'text-white' : 'text-black'}`}>
                   <span className="w-4 h-4 rounded-full bg-[#4fa8d9] inline-flex items-center justify-center mr-2 text-white text-[9px] font-bold">{i + 1}</span>
                   {r.name}
                </span>
                <button onClick={(e) => { e.stopPropagation(); removeReceiver(r.id); }} className="text-red-400 hover:text-red-300 cursor-pointer z-50 p-1"><X size={16} /></button>
              </div>
            ))}
            
            <button 
              onClick={() => useStore.getState().setAddingReceiver(true)}
              className={`w-full mt-4 ${theme === 'dark' ? 'bg-[#202226] border-[#2a2c30] text-[#83868c]' : 'bg-[#f9fafb] border-[#e5e7eb] text-[#6b7280]'} border border-dashed p-2 rounded text-xs hover:border-[#43d9b8] hover:text-[#43d9b8] transition-colors`}>
              {useStore.getState().addingReceiver ? 'Click in 3D View to Place...' : '+ Add Receiver'}
            </button>
            <p className={`text-[10px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} mt-2 text-center`}>Drag receivers to move them. Click one to select it.</p>
          </div>
        )}

        {activeTab === 'settings' && (
          <div>
            <div className={`flex space-x-6 mb-8 border-b ${theme === 'dark' ? 'border-[#2a2c30]' : 'border-[#e5e7eb]'} pb-6`}>
              {['Survey', 'Default', 'Advanced'].map(mode => (
                <label key={mode} onClick={() => setTransitionFreqMode(mode)} className={`flex items-center text-xs cursor-pointer ${transitionFreqMode === mode ? 'text-[#43d9b8]' : (theme === 'dark' ? 'text-[#83868c] hover:text-white' : 'text-[#6b7280] hover:text-black')}`}>
                  <div className={`w-3 h-3 rounded-full border mr-2 flex items-center justify-center ${transitionFreqMode === mode ? 'border-[#43d9b8]' : (theme === 'dark' ? 'border-[#83868c]' : 'border-[#6b7280]')}`}>
                    {transitionFreqMode === mode && <div className="w-1.5 h-1.5 rounded-full bg-[#43d9b8]"></div>}
                  </div>
                  {mode}
                </label>
              ))}
            </div>
            
            <div className="mb-8">
              <h3 className={`text-xs font-bold ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'} mb-4 uppercase tracking-wider`}>Audio Source Mode</h3>
              <select 
                className={`w-full ${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30] text-[#e7e7e5]' : 'bg-[#f9fafb] border-[#e5e7eb] text-black'} border text-xs p-2 rounded outline-none`}
                value={audioSourceType}
                onChange={(e) => setAudioSourceType(e.target.value)}
              >
                <option value="song">Song (Full Band, ~30s Loop)</option>
                <option value="music">Music (Synth Chords)</option>
                <option value="bass">Bass</option>
                <option value="piano">Piano</option>
                <option value="violin">Violin</option>
                <option value="guitar">Electric Guitar</option>
                <option value="cello">Cello</option>
                <option value="flute">Flute</option>
                <option value="organ">Organ</option>
                <option value="marimba">Marimba</option>
                <option value="synthlead">Synth Lead (Arp)</option>
                <option value="synthpad">Synth Pad (Ambient)</option>
                <option value="bells">Bells</option>
                <option value="drumbeat">Drum Beat</option>
                <option value="hiphopbeat">Hip-Hop Beat</option>
                <option value="oceanwaves">Ocean Waves</option>
                <option value="pulse">Pulse (Beeping)</option>
                <option value="noise_white">White Noise</option>
                <option value="noise_pink">Pink Noise</option>
                <option value="noise_brown">Brown Noise</option>
                <option value="mic">Microphone (Hear Yourself)</option>
              </select>
              <p className={`text-[10px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} mt-2`}>
                Changes the audio content playing from the Sound Sources. Note: To use Microphone, you must click Allow when your browser asks for permission, and use headphones to avoid feedback/echo.
              </p>
              
              {availableMics.length > 0 && (
                <div className="mt-6">
                  <h4 className={`text-[10px] font-bold ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'} mb-2 uppercase tracking-wider`}>Microphone Device</h4>
                  <select 
                    className={`w-full ${theme === 'dark' ? 'bg-[#141517] border-[#2a2c30] text-[#e7e7e5]' : 'bg-[#f9fafb] border-[#e5e7eb] text-black'} border text-xs p-2 rounded outline-none`}
                    value={selectedMicId}
                    onChange={(e) => {
                      setSelectedMicId(e.target.value);
                      const state = useStore.getState();
                      if (state.isPlaying) {
                        audioEngine.play(
                          state.sources, 
                          state.receivers.find(r => r.id === state.activeReceiverId) || state.receivers[0], 
                          state.L, state.W, state.audioSourceType, state.poly, state.wallSegMats, state.wallMaterial, state.wallOpenings,
                          state.H, state.floorMaterial, state.ceilMaterial
                        );
                      }
                    }}
                  >
                    {availableMics.map(mic => (
                      <option key={mic.deviceId} value={mic.deviceId}>
                        {mic.label || `Microphone ${mic.deviceId.slice(0, 5)}...`}
                      </option>
                    ))}
                  </select>
                  
                  {availableMics.every(m => !m.label) && (
                    <button
                      type="button"
                      onClick={() => {
                        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { alert('Microphone API is completely blocked by your browser in this environment. You may need to hard refresh the page (F5/Cmd+R) or open the app in a new tab.'); return; }
                        navigator.mediaDevices.getUserMedia({ audio: true })
                          .then(stream => {
                            stream.getTracks().forEach(t => t.stop());
                            fetchMics();
                          })
                          .catch(e => {
                            console.error("Mic permission error:", e);
                            alert("Microphone access failed: " + e.message + ". Please ensure your browser allows microphone access for this site.");
                          });
                      }}
                      className={`w-full mt-3 text-[10px] font-bold py-1.5 rounded border ${theme === 'dark' ? 'border-[#43d9b8] text-[#43d9b8] hover:bg-[#43d9b8] hover:text-black' : 'border-[#43d9b8] text-[#43d9b8] hover:bg-[#43d9b8] hover:text-white'} transition-colors`}
                    >
                      Reveal Microphone Names
                    </button>
                  )}
                </div>
              )}

              {audioSourceType === 'mic' && (
                <div className="mt-4">
                  <p className={`text-[10px] mb-2 font-semibold ${
                    micStatus === 'active' ? 'text-[#43d9b8]'
                    : micStatus === 'denied' || micStatus === 'unsupported' ? 'text-red-400'
                    : theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'
                  }`}>
                    {micStatus === 'requesting' && 'Requesting microphone access…'}
                    {micStatus === 'active' && 'Microphone active — press Play to hear yourself.'}
                    {micStatus === 'denied' && "Microphone access was denied or unavailable. Switched to Song mode — pick Microphone again to retry."}
                    {micStatus === 'unsupported' && 'Microphone capture needs HTTPS or localhost. Switched to Song mode.'}
                    {micStatus === 'idle' && 'Press Play to request microphone access.'}
                  </p>
                </div>
              )}
            </div>

            <div className="mb-8 border-t border-[#2a2c30] pt-6">
              <h3 className={`text-xs font-bold ${theme === 'dark' ? 'text-[#e7e7e5]' : 'text-black'} mb-4 uppercase tracking-wider`}>Advanced Physics</h3>
              <p className={`text-[10px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} mb-3`}>
                3D Wave Solver (FDTD) is fully integrated. Geometry and sound data are processed automatically during playback.
              </p>
              <div className={`w-full py-3 px-4 rounded-lg flex items-center justify-between ${theme === 'dark' ? 'bg-[#141517] border border-[#2a2c30]' : 'bg-gray-50 border border-gray-200'}`}>
                <div className="flex items-center gap-2">
                  <Activity size={16} className={isPlaying ? 'text-[#43d9b8] animate-pulse' : 'text-gray-500'} />
                  <span className={`text-xs font-semibold ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                    {solverStatus}
                  </span>
                </div>
                {(subscriptionData?.plan === 'premium' || subscriptionData?.plan === 'lifetime') ? (
                  <span className="text-[10px] font-bold text-[#8a2be2] bg-[#8a2be2]/10 px-2 py-1 rounded">HIGH-RES MESH</span>
                ) : (
                  <span className="text-[10px] font-bold text-gray-500 bg-gray-500/10 px-2 py-1 rounded">STANDARD MESH</span>
                )}
              </div>

              <div className="mt-4">
                <p className={`text-[10px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} mb-2`}>
                  The preview above runs a fast, high-resolution mesh for visualization but only simulates ~1ms of real time — not enough for RT60, C50, C80, or Ts to be meaningful. Compute a dedicated, longer-duration run (coarser mesh, thousands of time steps) to get real decay-based metrics for this room.
                </p>
                <button
                  onClick={runImpulseResponse}
                  disabled={irStatus === 'computing'}
                  className={`w-full py-2 px-3 rounded text-xs font-bold transition-colors ${irStatus === 'computing' ? 'bg-gray-500/20 text-gray-500 cursor-wait' : 'bg-[#43d9b8] text-black hover:bg-[#3bc2a4]'}`}
                >
                  {irStatus === 'computing' ? 'Computing Impulse Response… (this can take a while)' : 'Compute Real Impulse Response (RT60 / C50 / C80 / Ts)'}
                </button>
                {irStatus === 'done' && (
                  <p className={`text-[10px] mt-2 ${irWarning ? 'text-amber-500' : 'text-[#43d9b8]'}`}>
                    {irWarning || 'Done — real decay-based metrics are now available in the Results panel and report export.'}
                  </p>
                )}
                {irStatus === 'error' && (
                  <p className="text-[10px] mt-2 text-red-500">{irWarning || 'Failed to compute impulse response. Try again.'}</p>
                )}
              </div>

              <div className="mt-6 pt-4 border-t border-[#2a2c30]">
                <p className={`text-[10px] ${theme === 'dark' ? 'text-[#83868c]' : 'text-[#6b7280]'} mb-2`}>
                  {lastIrResultForExport
                    ? 'Generates a client-ready PDF with this room\'s real RT60, STI, and speaker/receiver layout.'
                    : 'Generates a PDF report using room-geometry RT60/STI estimates. Run "Compute Real Impulse Response" first for a report with a real, simulation-based STI instead of the formula estimate.'}
                </p>
                <button
                  onClick={exportReport}
                  disabled={exportStatus === 'exporting'}
                  className={`w-full py-2 px-3 rounded text-xs font-bold border transition-colors ${exportStatus === 'exporting' ? 'border-gray-500/30 text-gray-500 cursor-wait' : 'border-[#43d9b8] text-[#43d9b8] hover:bg-[#43d9b8] hover:text-black'}`}
                >
                  {exportStatus === 'exporting' ? 'Generating PDF…' : 'Export Report (PDF)'}
                </button>
                {exportStatus === 'error' && (
                  <p className="text-[10px] mt-2 text-red-500">{exportError || 'Failed to generate report.'}</p>
                )}
              </div>
            </div>
          </div>
        )}
          </div>
        </>
      ) : (
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
          <LeftSidebar />
        </div>
      )}

      <div className={`mt-auto border-t ${theme === 'dark' ? 'border-[#2a2c30] bg-[#1a1b1e]' : 'border-[#e5e7eb] bg-[#ffffff]'}`}>
        <div className={`flex items-center h-[60px] px-6 gap-2`}>
          <button 
            onClick={() => setView('editor')} 
            className={`flex items-center flex-1 justify-center text-[11px] font-bold transition-colors h-10 rounded ${
              view !== 'results' 
                ? 'bg-[#43d9b8] text-black shadow-lg shadow-[#43d9b8]/20' 
                : (theme === 'dark' ? 'text-[#83868c] hover:text-white hover:bg-white/5' : 'text-[#6b7280] hover:text-black hover:bg-black/5')
            }`}
          >
            <Headphones size={16} className="mr-2" /> Auralizer
          </button>
          
          <button 
            onClick={() => setView('results')} 
            className={`flex items-center flex-1 justify-center text-[11px] font-bold transition-colors h-10 rounded ${
              view === 'results' 
                ? 'bg-[#43d9b8] text-black shadow-lg shadow-[#43d9b8]/20' 
                : (theme === 'dark' ? 'text-[#83868c] hover:text-white hover:bg-white/5' : 'text-[#6b7280] hover:text-black hover:bg-black/5')
            }`}
          >
            <Activity size={16} className="mr-2" /> Results
          </button>
        </div>
      </div>
    </div>
  );
}
