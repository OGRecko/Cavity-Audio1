// Adapter over the merged speaker library (src/data/speakers.json).
//
// The merged file combines:
//  - 276 entries with full driver/frequency/power specs (source: "specs-verified"),
//    originally from the speaker-module addition, feeding speakerDSP.ts.
//  - 82 entries that only existed in the old, smaller curated list this file
//    used to contain directly (source: "legacy") — kept because they were not
//    present in the new list and we don't want to silently drop real,
//    previously-verified speakers. These lack driver/frequency/power specs;
//    speakerDSP.ts falls back to neutral defaults for them (see
//    normalizeSpeakerSpec in speakerDSP.ts) rather than inventing numbers.
//
// No entries are duplicated: brand+model pairs already present in the new
// list were not re-added from the legacy list.

import speakerData from '../data/speakers.json';
import type { SpeakerSpec } from './speakerDSP';

// Back-compat shape used by RightSidebar.tsx / useStore.ts, which only ever
// needed id/brand/model/year/type/sens/verified.
export interface SpeakerEntry {
  id: string;
  brand: string;
  model: string;
  year: number;
  type: string;
  sens: number;
  verified: boolean;
}

const CATEGORY_TO_TYPE: Record<string, string> = {
  'studio-monitor': 'Active Studio Monitor',
  'bookshelf': 'Passive Bookshelf',
  'floor-standing': 'Floorstanding',
  'pa': 'PA System',
  'ceiling': 'Ceiling Speaker',
  'in-wall': 'In-Wall',
  'subwoofer': 'Subwoofer',
  'portable': 'Portable',
  'soundbar': 'Soundbar',
  'car-audio': 'Car Audio',
  'guitar-cab': 'Guitar Cabinet',
  'smart-speaker': 'Smart Speaker',
};

// Rough sensitivity estimate for specs-verified entries that only carry
// power/impedance (no explicit sens figure) so the old UI's sens display
// still has a plausible number. Clearly an estimate, not a spec claim.
function estimateSens(power_w: number, category: string): number {
  const base = category === 'pa' ? 97 : category === 'subwoofer' ? 92 : 88;
  return base;
}

export const SPEAKER_SPECS = speakerData as unknown as (SpeakerSpec & {
  source: 'specs-verified' | 'legacy';
  sens_db?: number;
  verified?: boolean;
})[];

export const SPEAKERS: SpeakerEntry[] = SPEAKER_SPECS.map(s => ({
  id: s.id,
  brand: s.brand,
  model: s.model,
  year: s.year,
  type: CATEGORY_TO_TYPE[s.category] ?? s.category,
  sens: s.source === 'legacy' && typeof s.sens_db === 'number'
    ? s.sens_db
    : estimateSens(s.power_w, s.category),
  verified: s.source === 'legacy' ? Boolean(s.verified) : true,
}));

const BRANDS = Array.from(new Set(SPEAKERS.map(s => s.brand))).sort();
const TYPES = Array.from(new Set(SPEAKERS.map(s => s.type))).sort();

// O(1) lookup by id, computed once at module load rather than re-scanning
// the array on every lookup.
const SPEAKER_BY_ID = new Map(SPEAKER_SPECS.map(s => [s.id, s]));
export function getSpeakerById(id: string) {
  return SPEAKER_BY_ID.get(id);
}

export { BRANDS, TYPES };
