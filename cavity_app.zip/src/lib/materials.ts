export const MATERIALS = {
  walls: [
    { id: 'drywall', name: 'Gypsum Board / Drywall', tl: 35 },
    { id: 'brick', name: 'Exposed Brick', tl: 45 },
    { id: 'concrete', name: 'Concrete', tl: 55 },
    { id: 'cinder_block', name: 'Cinder Block', tl: 42 },
    { id: 'glass', name: 'Glass Window', tl: 25 },
    { id: 'glass_double', name: 'Double Glazed Glass', tl: 32 },
    { id: 'wood_panel', name: 'Wood Paneling', tl: 28 },
    { id: 'plywood_panel', name: 'Plywood Paneling', tl: 24 },
    { id: 'acoustic_panel', name: 'Acoustic Panel (1 inch)', tl: 15 },
    { id: 'acoustic_panel_thick', name: 'Acoustic Panel (2 inch)', tl: 20 },
    { id: 'curtain_wall', name: 'Heavy Curtains', tl: 8 },
    { id: 'tile_wall', name: 'Ceramic Tile', tl: 40 },
    { id: 'wallpaper', name: 'Wallpaper on Plaster', tl: 35 },
    { id: 'marble_wall', name: 'Marble / Stone', tl: 50 },
    { id: 'iso_wall', name: 'Sound Isolation Wall', tl: 65 }
  ],
  floor: [
    { id: 'wood_floor', name: 'Hardwood Floor', tl: 30 },
    { id: 'tile', name: 'Ceramic Tile', tl: 45 },
    { id: 'polished_concrete', name: 'Polished Concrete', tl: 55 },
    { id: 'vinyl', name: 'Vinyl / Linoleum', tl: 35 },
    { id: 'carpet_thin', name: 'Thin Carpet on Concrete', tl: 55 },
    { id: 'carpet_thick', name: 'Thick Carpet on Concrete', tl: 55 },
    { id: 'carpet_padded', name: 'Carpet on Padding', tl: 40 },
    { id: 'concrete_floor', name: 'Rough Concrete', tl: 55 },
    { id: 'raised_access', name: 'Raised Access Floor', tl: 35 },
    { id: 'cork', name: 'Cork Flooring', tl: 32 },
    { id: 'iso_floor', name: 'Floating Floor', tl: 60 }
  ],
  ceiling: [
    { id: 'drywall_ceil', name: 'Gypsum Board / Drywall', tl: 35 },
    { id: 'stonewool', name: 'Stonewool Acoustic Tiles', tl: 25 },
    { id: 'stonewool_thick', name: 'Thick Stonewool Tiles', tl: 28 },
    { id: 'acoustic_tile', name: 'Fiberglass Acoustic Tile', tl: 20 },
    { id: 'acoustic_cloud', name: 'Suspended Acoustic Clouds', tl: 15 },
    { id: 'exposed_concrete', name: 'Exposed Concrete Deck', tl: 55 },
    { id: 'exposed_deck', name: 'Exposed Metal Deck', tl: 30 },
    { id: 'wood_ceil', name: 'Wood Slat Ceiling', tl: 25 },
    { id: 'coffered_plaster', name: 'Coffered Plaster', tl: 40 },
    { id: 'perforated_metal', name: 'Perforated Metal Panels', tl: 15 },
    { id: 'iso_ceil', name: 'Isolated Ceiling', tl: 60 }
  ]
};

// Approximate Sabine absorption coefficients (0 = fully reflective, 1 = fully
// absorptive), roughly averaged across the speech/music range. These are what
// actually drive reverb time — `tl` above is transmission loss (how much
// sound escapes the room), which is a different property from how much sound
// bounces back inside it.
export const ABSORPTION: Record<string, number> = {
  // walls
  drywall: 0.05, brick: 0.03, concrete: 0.02, cinder_block: 0.04,
  glass: 0.03, glass_double: 0.03, wood_panel: 0.06, plywood_panel: 0.07,
  acoustic_panel: 0.7, acoustic_panel_thick: 0.85, curtain_wall: 0.5,
  tile_wall: 0.02, wallpaper: 0.04, marble_wall: 0.01, iso_wall: 0.1,
  // floor
  wood_floor: 0.1, tile: 0.02, polished_concrete: 0.015, vinyl: 0.03,
  carpet_thin: 0.15, carpet_thick: 0.35, carpet_padded: 0.45,
  concrete_floor: 0.015, raised_access: 0.05, cork: 0.15, iso_floor: 0.2,
  // ceiling
  drywall_ceil: 0.05, stonewool: 0.75, stonewool_thick: 0.85,
  acoustic_tile: 0.65, acoustic_cloud: 0.6, exposed_concrete: 0.02,
  exposed_deck: 0.05, wood_ceil: 0.1, coffered_plaster: 0.06,
  perforated_metal: 0.5, iso_ceil: 0.15,
};

export function getAbsorption(materialId: string | null | undefined, fallback = 0.1): number {
  if (!materialId) return fallback;
  return ABSORPTION[materialId] ?? fallback;
}

export const MAT_COLORS: Record<string, string> = {
  drywall: '#e0e0e0', brick: '#b25d46', concrete: '#959595', cinder_block: '#b0b5b9',
  glass: '#a8d5e2', glass_double: '#90c0d0', wood_panel: '#c19a6b', plywood_panel: '#d4b581',
  acoustic_panel: '#4a4a4a', acoustic_panel_thick: '#333333', curtain_wall: '#800020',
  tile_wall: '#f4f4f4', wallpaper: '#eaddcf', marble_wall: '#e2e4e1', iso_wall: '#d0d0d0',
  wood_floor: '#8b5a2b', tile: '#f5f5f0', polished_concrete: '#a0a0a0', vinyl: '#c0b4a6',
  carpet_thin: '#5c6b73', carpet_thick: '#3d4e56', carpet_padded: '#2c3e45',
  concrete_floor: '#888888', raised_access: '#b8b8b8', cork: '#d2b48c', iso_floor: '#808080',
  drywall_ceil: '#f0f0f0', stonewool: '#e0d8c0', stonewool_thick: '#d0c8b0',
  acoustic_tile: '#ffffff', acoustic_cloud: '#f8f8f8', exposed_concrete: '#999999',
  exposed_deck: '#70757a', wood_ceil: '#a07850', coffered_plaster: '#eae6df',
  perforated_metal: '#b5b8ba', iso_ceil: '#e8e8e8',
};
