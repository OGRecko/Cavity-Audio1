// Client for the app's own server-side, session-cookie-based auth system
// (server.ts's /api/auth/* endpoints + server/db.ts). This REPLACES a
// previous implementation that called Firebase Authentication/Firestore
// directly — that version never touched this server's session system at
// all, meaning a user signing in through it would have no valid session
// cookie for any authMiddleware-protected endpoint (projects, reports,
// solver runs). All the app's real trial/billing (Polar) logic is already
// keyed to this server's own UserRecord, so this is the system going
// forward; Firebase/Firestore are no longer used anywhere in the client.
//
// Every request includes credentials: 'include' so the session cookie the
// server sets is stored and sent on subsequent requests — matches the
// convention already used elsewhere in the app (see RightSidebar.tsx's
// solver fetch calls).

// Loads Google's Identity Services script once, lazily, and caches the
// promise so concurrent callers share the same load.
let gisLoadPromise: Promise<void> | null = null;
function loadGoogleIdentityServices(): Promise<void> {
  if (typeof window === 'undefined') return Promise.reject(new Error('Not in a browser.'));
  if ((window as any).google?.accounts?.id) return Promise.resolve();
  if (gisLoadPromise) return gisLoadPromise;

  gisLoadPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load Google Identity Services.'));
    document.head.appendChild(script);
  });
  return gisLoadPromise;
}

async function postJson(path: string, body?: object) {
  const res = await fetch(path, {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed (${res.status})`);
  }
  return data;
}

export const authClient = {
  signup: async (payload: { firstName: string; lastName: string; username: string; email: string; password: string }) => {
    // Server response shape: either { autoVerified: true, user } when SMTP
    // isn't configured (dev convenience — see server.ts), or
    // { pendingEmail } when a real verification email was sent.
    return postJson('/api/auth/signup', payload);
  },

  login: async (payload: { identifier: string; password: string; rememberMe?: boolean }) => {
    const data = await postJson('/api/auth/login', payload);
    return { user: data.user };
  },

  loginWithGoogle: async () => {
    const clientId = (import.meta as any).env?.VITE_GOOGLE_CLIENT_ID;
    if (!clientId) {
      throw new Error(
        'Google sign-in is not configured — set VITE_GOOGLE_CLIENT_ID in your .env to enable it.'
      );
    }

    await loadGoogleIdentityServices();
    const google = (window as any).google;

    const idToken: string = await new Promise((resolve, reject) => {
      google.accounts.id.initialize({
        client_id: clientId,
        callback: (response: any) => {
          if (response?.credential) resolve(response.credential);
          else reject(new Error('Google sign-in was cancelled or failed.'));
        },
      });
      // Prefer the One Tap prompt; if the browser/user blocks it (e.g. no
      // active Google session, or a previous dismissal), fall back to
      // rendering a temporary button and clicking it programmatically so
      // the account chooser still opens from this same user gesture.
      google.accounts.id.prompt((notification: any) => {
        if (notification.isNotDisplayed?.() || notification.isSkippedMoment?.()) {
          const container = document.createElement('div');
          container.style.position = 'fixed';
          container.style.top = '-1000px';
          document.body.appendChild(container);
          google.accounts.id.renderButton(container, { type: 'standard' });
          const btn = container.querySelector('div[role="button"]') as HTMLElement | null;
          btn?.click();
          setTimeout(() => container.remove(), 5000);
        }
      });
    });

    const data = await postJson('/api/auth/google', { idToken });
    return { user: data.user };
  },

  // code: the 6-character code the user typed in from their email.
  // email: required for the pending-signup path (verifying before the
  // account is fully created); omit when verifying an already-logged-in,
  // not-yet-verified user (the server falls back to the session cookie).
  verifyCode: async (code: string, email?: string) => {
    const data = await postJson('/api/auth/verify-code', { code, email });
    return { user: data.user };
  },

  resendCode: async (email?: string) => {
    return postJson('/api/auth/resend-code', { email });
  },

  forgotPassword: async (email: string) => {
    return postJson('/api/auth/forgot-password', { email });
  },

  resetPassword: async (email: string, code: string, newPassword: string) => {
    const data = await postJson('/api/auth/reset-password', { email, code, newPassword });
    return { user: data.user };
  },

  logout: async () => {
    return postJson('/api/auth/logout');
  },
};
