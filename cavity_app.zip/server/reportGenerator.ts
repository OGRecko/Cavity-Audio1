// Client-ready PDF report generation for a Cavity project.
//
// IMPORTANT — content honesty:
// - Only include data the project actually has. Don't fabricate speaker
//   specs, material names, or simulation results that weren't provided.
// - RT60/STI numbers are labeled with their calculation method and, for
//   STI, an explicit non-compliance disclaimer (see roomAcoustics.ts).
// - Never state or imply ISO 3382 compliance/certification. This report
//   references ISO 3382 as the standard reverberation-time measurement
//   convention RT60 figures are meant to be compared against — it does not
//   claim the app's calculation method is an ISO 3382-compliant
//   measurement (ISO 3382 describes measuring RT60 from a real room with
//   real instrumentation; this app computes a theoretical estimate from
//   modeled geometry and published material data instead).

import PDFDocument from 'pdfkit';
import {
  computeRT60,
  computeSTIProxy,
  BAND_LABELS,
  type RoomGeometryInput,
} from '../src/lib/roomAcoustics';
import { computeRealSTI } from '../src/lib/sti';

export interface ReportSpeaker {
  brand: string;
  model: string;
  type?: string;
  x: number;
  y: number;
}

export interface ReportReceiver {
  name: string;
  x: number;
  y: number;
}

export interface ReportInput {
  projectName: string;
  roomName: string;
  room: RoomGeometryInput;
  speakers: ReportSpeaker[];
  receivers: ReportReceiver[];
  // Optional: if the client already ran the dedicated, long-duration
  // impulse response solver (/api/solver/impulse-response — NOT the quick
  // preview /api/solver/wave, which only simulates ~1ms and cannot produce
  // a meaningful simulatedRt60), include that result here for the
  // "simulation results" section.
  solverResult?: {
    rt60?: number | null;
    simulatedRt60?: number | null;
    gridDims?: [number, number, number];
    tier?: string;
    // Present only when solverResult comes from the long-duration impulse
    // response endpoint (not the quick preview). When available, the
    // report uses these to compute a real MTF-based STI (see src/lib/sti.ts)
    // instead of the RT60-based proxy, so the report matches whatever the
    // in-app Results panel is showing for the same room.
    receiverTrace?: number[];
    dtEstimate?: number;
  } | null;
  // Assumed SNR for the STI proxy, since the app doesn't currently measure
  // real ambient noise. Defaulting to a reasonable "quiet room" assumption
  // and always labeling it as an assumption in the report, not a measurement.
  assumedSnrDb?: number;
  generatedForEmail?: string;
}

const CAVITY_TEAL = '#43d9b8';
const TEXT_DARK = '#1a1b1e';
const TEXT_MUTED = '#6b7280';

function drawHeader(doc: PDFKit.PDFDocument, title: string, subtitle: string) {
  doc.fontSize(20).fillColor(TEXT_DARK).font('Helvetica-Bold').text('Cavity', { continued: false });
  doc.fontSize(9).fillColor(TEXT_MUTED).font('Helvetica').text('Acoustic Simulation Report');
  doc.moveDown(0.8);
  doc.fontSize(16).fillColor(TEXT_DARK).font('Helvetica-Bold').text(title);
  doc.fontSize(10).fillColor(TEXT_MUTED).font('Helvetica').text(subtitle);
  doc.moveDown(1);
  doc.strokeColor('#e5e7eb').lineWidth(1)
    .moveTo(doc.page.margins.left, doc.y)
    .lineTo(doc.page.width - doc.page.margins.right, doc.y)
    .stroke();
  doc.moveDown(1);
}

function sectionTitle(doc: PDFKit.PDFDocument, text: string) {
  doc.moveDown(0.5);
  doc.fontSize(12).fillColor(TEXT_DARK).font('Helvetica-Bold').text(text.toUpperCase());
  doc.moveDown(0.3);
}

function labelValue(doc: PDFKit.PDFDocument, label: string, value: string) {
  doc.fontSize(9).font('Helvetica').fillColor(TEXT_MUTED).text(label, { continued: true });
  doc.font('Helvetica-Bold').fillColor(TEXT_DARK).text('  ' + value);
}

// Render a simple table: header row + data rows, fixed column widths.
function drawTable(doc: PDFKit.PDFDocument, headers: string[], rows: string[][], colWidths: number[]) {
  const startX = doc.page.margins.left;
  let y = doc.y;
  const rowHeight = 18;

  doc.font('Helvetica-Bold').fontSize(8).fillColor(TEXT_DARK);
  let x = startX;
  headers.forEach((h, i) => {
    doc.text(h, x, y, { width: colWidths[i], align: i === 0 ? 'left' : 'right' });
    x += colWidths[i];
  });
  y += rowHeight;
  doc.strokeColor('#e5e7eb').moveTo(startX, y - 4).lineTo(startX + colWidths.reduce((a, b) => a + b, 0), y - 4).stroke();

  doc.font('Helvetica').fontSize(8).fillColor(TEXT_DARK);
  rows.forEach(row => {
    x = startX;
    row.forEach((cell, i) => {
      doc.text(cell, x, y, { width: colWidths[i], align: i === 0 ? 'left' : 'right' });
      x += colWidths[i];
    });
    y += rowHeight;
  });

  doc.y = y + 8;
}

export function generateProjectReport(input: ReportInput): PDFKit.PDFDocument {
  const doc = new PDFDocument({ size: 'LETTER', margin: 50, bufferPages: true });

  const rt60 = computeRT60(input.room);
  const snr = input.assumedSnrDb ?? 25; // "quiet room" default assumption
  const midRt60 = rt60.eyring[BAND_LABELS[3]] ?? rt60.sabine[BAND_LABELS[3]] ?? 0.5; // 1000Hz
  const proxySti = computeSTIProxy(midRt60, snr);
  // Prefer the real MTF-based STI when a long-duration impulse response run
  // was supplied — same preference order as the in-app Results panel, so
  // the report and the UI never disagree about which number is "the" STI
  // for this project.
  const realStiResult = input.solverResult?.receiverTrace?.length
    ? computeRealSTI(input.solverResult.receiverTrace, input.solverResult.dtEstimate || 0.0001)
    : null;
  const sti = (realStiResult && realStiResult.sufficient) ? realStiResult : proxySti;
  const stiIsReal = realStiResult !== null && realStiResult.sufficient;

  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  // --- Page 1: Project overview ---
  drawHeader(doc, input.projectName || 'Untitled Project', `Room: ${input.roomName || 'Untitled Room'} · Generated ${dateStr}`);

  sectionTitle(doc, 'Room Geometry');
  labelValue(doc, 'Dimensions (L x W x H):', `${input.room.L.toFixed(2)} m x ${input.room.W.toFixed(2)} m x ${input.room.H.toFixed(2)} m`);
  labelValue(doc, 'Floor area:', `${rt60.floorArea.toFixed(1)} m^2`);
  labelValue(doc, 'Volume:', `${rt60.volume.toFixed(1)} m^3`);
  doc.moveDown(0.5);

  sectionTitle(doc, 'Materials');
  labelValue(doc, 'Default wall material:', input.room.wallMaterial);
  labelValue(doc, 'Floor material:', input.room.floorMaterial);
  labelValue(doc, 'Ceiling material:', input.room.ceilMaterial);
  const distinctWallMats = Array.from(new Set(input.room.wallSegMats.filter((m): m is string => !!m)));
  if (distinctWallMats.length > 0) {
    labelValue(doc, 'Per-segment wall overrides:', distinctWallMats.join(', '));
  }
  doc.moveDown(0.5);

  if (input.speakers.length > 0) {
    sectionTitle(doc, 'Speaker Configuration');
    drawTable(
      doc,
      ['Speaker', 'Type', 'Position (x, y)'],
      input.speakers.map(s => [`${s.brand} ${s.model}`, s.type || '—', `${s.x.toFixed(2)}, ${s.y.toFixed(2)}`]),
      [220, 150, 100]
    );
  }

  if (input.receivers.length > 0) {
    sectionTitle(doc, 'Listening Positions');
    drawTable(
      doc,
      ['Receiver', 'Position (x, y)'],
      input.receivers.map(r => [r.name, `${r.x.toFixed(2)}, ${r.y.toFixed(2)}`]),
      [220, 150]
    );
  }

  // --- Page 2: Acoustic results ---
  doc.addPage();
  sectionTitle(doc, 'Reverberation Time (RT60)');
  doc.fontSize(8).font('Helvetica').fillColor(TEXT_MUTED).text(
    `Calculated using the ${rt60.recommendedMethod === 'eyring' ? 'Eyring' : 'Sabine'} equation, the recommended method for this room's average absorption level. ` +
    'Both classical reverberation-time formulas are shown below for reference; per-band absorption coefficients are drawn from standard published architectural acoustics references, not lab measurements of the specific materials used. ' +
    'This is a theoretical estimate from modeled geometry, not an on-site ISO 3382 measurement of a built space.',
    { width: doc.page.width - doc.page.margins.left - doc.page.margins.right }
  );
  doc.moveDown(0.5);

  drawTable(
    doc,
    ['Band', 'Sabine RT60 (s)', 'Eyring RT60 (s)', 'Avg. α'],
    BAND_LABELS.map(label => [
      label,
      (rt60.sabine[label] ?? 0).toFixed(2),
      (rt60.eyring[label] ?? 0).toFixed(2),
      (rt60.avgAbsorption[label] ?? 0).toFixed(3),
    ]),
    [100, 140, 140, 90]
  );

  sectionTitle(doc, 'Speech Transmission Index (Estimate)');
  labelValue(doc, stiIsReal ? 'STI (from simulated impulse response):' : 'STI (RT60-based proxy estimate):', `${sti.value.toFixed(2)} — ${sti.qualityLabel}`);
  if (!stiIsReal) {
    labelValue(doc, 'Assumed signal-to-noise ratio:', `${snr} dB (assumption, not measured)`);
  }
  doc.moveDown(0.3);
  doc.fontSize(8).font('Helvetica-Oblique').fillColor(TEXT_MUTED).text(sti.disclaimer, {
    width: doc.page.width - doc.page.margins.left - doc.page.margins.right,
  });
  doc.moveDown(0.5);

  if (input.solverResult) {
    sectionTitle(doc, 'Wave Simulation (FDTD) Cross-Check');
    if (input.solverResult.rt60 != null) {
      labelValue(doc, 'Solver Sabine RT60 (broadband):', `${input.solverResult.rt60.toFixed(2)} s`);
    }
    if (input.solverResult.simulatedRt60 != null) {
      labelValue(doc, 'RT60 estimated from simulated decay:', `${input.solverResult.simulatedRt60.toFixed(2)} s`);
    }
    if (input.solverResult.gridDims) {
      labelValue(doc, 'Simulation grid:', input.solverResult.gridDims.join(' x '));
    }
    doc.moveDown(0.3);
    doc.fontSize(8).font('Helvetica-Oblique').fillColor(TEXT_MUTED).text(
      'The simulated-decay figure is a rough cross-check extrapolated from a short time-domain run (single broadband absorption value per surface), not an independent, fully-converged measurement.',
      { width: doc.page.width - doc.page.margins.left - doc.page.margins.right }
    );
  }

  // --- Methodology / references ---
  doc.moveDown(1);
  sectionTitle(doc, 'Methodology & References');
  doc.fontSize(8).font('Helvetica').fillColor(TEXT_MUTED).text(
    'Reverberation time is calculated using the Sabine (1898) and Eyring (1930) equations, standard methods in architectural acoustics. ' +
    'Material absorption coefficients are drawn from commonly published architectural acoustics references (ASTM C423-style octave-band data) rather than product-specific lab testing. ' +
    'ISO 3382 defines the standard convention for measuring and reporting reverberation time in a built space; the figures in this report are a theoretical estimate from modeled room geometry and reference material data, not an ISO 3382-compliant field measurement. ' +
    (stiIsReal
      ? 'The Speech Transmission Index figure was computed from this room\'s actual simulated impulse response using the modulation transfer function (indirect/Schroeder) method, but without the official IEC 60268-16 auditory masking correction, absolute threshold correction, or published band-importance weights — see the disclaimer above. It is not the certified IEC 60268-16 measurement and should not be used for compliance or certification purposes. '
      : 'The Speech Transmission Index figure is a published proxy estimate derived from RT60 and an assumed signal-to-noise ratio, not the full IEC 60268-16 modulation transfer function measurement, and should not be used for compliance or certification purposes. ') +
    'This report is intended to support early-stage design decisions and client communication, not to replace on-site acoustic measurement or a licensed acoustical consultant\'s sign-off where required.',
    { width: doc.page.width - doc.page.margins.left - doc.page.margins.right }
  );

  doc.moveDown(1);
  doc.fontSize(7).fillColor(TEXT_MUTED).text(`Generated by Cavity on ${dateStr}${input.generatedForEmail ? ' for ' + input.generatedForEmail : ''}.`);

  doc.end();
  return doc;
}
