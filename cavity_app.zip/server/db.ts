import fs from "fs";
import path from "path";

// A tiny file-based "database". No account, no external service, no billing plan
// required — it just reads/writes a JSON file on disk. Fine for small/self-hosted
// deployments; swap for a real database later if you outgrow it.

const DB_PATH = path.join(process.cwd(), "data", "db.json");

export interface ProjectRecord {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  archived?: boolean;
  // Opaque blob, same shape the client already sends to the legacy
  // single-project endpoints (poly, materials, sources, receivers,
  // simulations, room dimensions, etc). The server does not need to
  // understand its internal structure.
  data: any;
}

export interface UserRecord {
  uid: string;
  firstName: string;
  lastName: string;
  username: string;
  usernameLower: string;
  email: string;
  emailLower: string;
  passwordHash: string; // "salt:hash" (scrypt)
  emailVerified: boolean;
  createdAt: number;
  subscriptionStatus: string;
  plan?: string;
  trialStartsAt: number;
  trialEndsAt: number;
  lemonSqueezyCustomerId?: string;
  polarCustomerId?: string;
  // Legacy single-project slot. Kept exactly as-is, still read/written by
  // the original /api/project GET/POST endpoints, so existing users' data
  // and any client that hasn't updated keep working unchanged. New
  // multi-project work should read/write `projects` instead — this field
  // is not migrated into `projects` automatically for existing users (see
  // /api/projects/migrate-legacy, which the client calls explicitly and
  // idempotently once, rather than the server silently moving data on
  // every request).
  projectData?: any;
  // Multi-project workspace: id -> project. Optional/absent for users who
  // predate this feature or haven't migrated yet — always guard with
  // `user.projects || {}` rather than assuming it exists.
  projects?: Record<string, ProjectRecord>;
  activeProjectId?: string;
}

export interface VerificationRecord {
  codeHash: string;
  attempts: number;
  expiresAt: number;
  lastSentAt: number;
}

export interface PasswordResetRecord {
  codeHash: string;
  attempts: number;
  expiresAt: number;
  lastSentAt: number;
}

// A single-use promo code, minted individually (as opposed to the old
// hardcoded FFGFREE shared string). Redeeming sets redeemedBy/redeemedAt and
// the code becomes permanently unusable -- see /api/redeem and
// /api/admin/promo-codes in server.ts. Stored plaintext (not hashed) because,
// unlike passwords/reset codes, the code itself isn't a secret protecting an
// existing account -- it's a one-time grant token, and admins need to be
// able to look codes back up (e.g. to resend one, or see what's still
// unredeemed) without needing the original plaintext on hand.
export interface PromoCodeRecord {
  code: string;
  grant: "lifetime"; // room to extend later (e.g. "monthly") without a migration
  createdAt: number;
  createdBy: string; // uid of the admin who minted it
  note?: string; // optional label, e.g. "for @someuser on Discord"
  redeemed: boolean;
  redeemedBy?: string; // uid
  redeemedAt?: number;
  revoked?: boolean; // admin can revoke an unredeemed code before it's used
}

interface DbShape {
  users: Record<string, UserRecord>; // uid -> user
  usernames: Record<string, string>; // usernameLower -> uid
  emails: Record<string, string>; // emailLower -> uid
  verificationCodes: Record<string, VerificationRecord>; // uid -> code record
  pendingSignups?: Record<string, { user: UserRecord; codeRecord: VerificationRecord }>; // emailLower -> pending
  passwordResets?: Record<string, PasswordResetRecord>; // uid -> reset code record
  promoCodes?: Record<string, PromoCodeRecord>; // code -> record
}

function emptyDb(): DbShape {
  return { users: {}, usernames: {}, emails: {}, verificationCodes: {}, pendingSignups: {}, passwordResets: {}, promoCodes: {} };
}

function ensureFile() {
  if (!fs.existsSync(DB_PATH)) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(emptyDb(), null, 2));
  }
}

// All reads/writes are synchronous. Node is single-threaded and none of these calls
// await in between the read and the write within a single request handler, so there's
// no interleaving race — good enough for a small/self-hosted app.

export function readDb(): DbShape {
  ensureFile();
  const raw = fs.readFileSync(DB_PATH, "utf-8");
  try {
    return JSON.parse(raw) as DbShape;
  } catch {
    return emptyDb();
  }
}

export function writeDb(db: DbShape) {
  ensureFile();
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}
